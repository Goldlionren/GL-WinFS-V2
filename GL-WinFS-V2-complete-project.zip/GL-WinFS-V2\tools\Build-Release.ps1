#requires -Version 5.1
[CmdletBinding()]
param([string]$Project)
$ErrorActionPreference='Stop'
if(-not $Project){$Project=Split-Path -Parent $PSScriptRoot}
$Project=[IO.Path]::GetFullPath($Project).TrimEnd('\')
Import-Module (Join-Path $Project 'src\SOH.psm1') -Force -DisableNameChecking
$tests=Read-SOHJson (Join-Path $Project 'reports\test-results.json')
if($tests.Failed -ne 0 -or $tests.Edition -ne 'Desktop' -or $tests.PowerShell -notlike '5.1.*'){throw 'Passing Windows PowerShell 5.1 test-results required before packaging.'}
$releaseRoot=Join-Path $Project 'release';[void][IO.Directory]::CreateDirectory($releaseRoot)
$buildId=[guid]::NewGuid().ToString('N')
$staging=Join-Path $Project ('.delivery-staging-'+$buildId)
$package=Join-Path $staging 'GL-WinFS-V2';[void][IO.Directory]::CreateDirectory($package)
$topFiles=@('Start-SOHReport.ps1','Test-SOHPrerequisites.ps1','Verify-SOHPackage.ps1','README_OPERATOR.md','README_DEVELOPER.md','CUSTOMER_ACCEPTANCE.md','CHANGELOG.md','LICENSE','NOTICE.md','VERSION.txt')
foreach($name in $topFiles){[IO.File]::Copy((Join-Path $Project $name),(Join-Path $package $name),$false)}
foreach($folder in @('src','input')){Copy-Item -LiteralPath (Join-Path $Project $folder) -Destination (Join-Path $package $folder) -Recurse}
[void][IO.Directory]::CreateDirectory((Join-Path $package 'reports'))
$reportFiles=@('00_UPSTREAM_REVIEW.md','01_VALIDATE.md','02_COLLECT.md','03_MERGE.md','04_COMPATIBILITY_AND_RELEASE.md','test-results.json','test-results.csv','FINAL_DELIVERY.md')
foreach($name in $reportFiles){[IO.File]::Copy((Join-Path $Project ('reports\'+$name)),(Join-Path $package ('reports\'+$name)),$false)}
function Write-Checksums([string]$Root){
    $lines=@(Get-ChildItem -LiteralPath $Root -Recurse -File | Where-Object Name -ne 'SHA256SUMS.txt' | Sort-Object FullName | ForEach-Object { (Get-FileHash -LiteralPath $_.FullName).Hash+'  '+$_.FullName.Substring($Root.Length+1) })
    Write-SOHAtomicText (Join-Path $Root 'SHA256SUMS.txt') (($lines-join "`r`n")+"`r`n")
}
Write-Checksums $package
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $package 'Verify-SOHPackage.ps1') | Out-Host
if($LASTEXITCODE -ne 0){throw 'Staged package checksum verification failed.'}
$final=Join-Path $releaseRoot 'GL-WinFS-V2'
if(Test-Path -LiteralPath $final){
    $resolved=[IO.Path]::GetFullPath($final)
    if(-not $resolved.StartsWith($Project+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe release move path.'}
    [IO.Directory]::Move($resolved,(Join-Path $staging 'previous-release'))
}
[IO.Directory]::Move($package,$final)
$zip=Join-Path $releaseRoot 'release.zip';$tempZip=Join-Path $staging 'release.zip'
Compress-Archive -LiteralPath $final -DestinationPath $tempZip -CompressionLevel Optimal
if([IO.File]::Exists($zip)){[IO.File]::Replace($tempZip,$zip,[Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($tempZip,$zip)}
Write-SOHAtomicText ($zip+'.sha256') ((Get-FileHash -LiteralPath $zip).Hash+'  release.zip'+"`r`n")
$clean=Join-Path $Project ('test-work\clean-extraction-'+$buildId)
Expand-Archive -LiteralPath $zip -DestinationPath $clean
$extracted=Join-Path $clean 'GL-WinFS-V2'
$checks=New-Object 'Collections.Generic.List[object]'
function Check([string]$Name,[scriptblock]$Body){& $Body;$checks.Add([pscustomobject]@{Name=$Name;Status='PASS'})}
Check 'Every extracted package file SHA256' {
    $output=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $extracted 'Verify-SOHPackage.ps1')
    if($LASTEXITCODE -ne 0){throw 'Extracted checksums failed.'};Write-Host ($output-join ' ')
}
Check 'Clean extraction Windows PowerShell 5.1 parser' {
    foreach($file in Get-ChildItem -LiteralPath $extracted -Recurse -File | Where-Object {$_.Extension -in @('.ps1','.psm1')}){
        $tokens=$null;$errs=$null;[void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errs)
        if(@($errs).Count){throw ($file.Name+': '+($errs|Out-String))}
    }
}
Check 'No runtime developer dependencies or forbidden configuration paths' {
    foreach($name in @('tests','tools','node_modules','package.json','requirements.txt')){if(Test-Path (Join-Path $extracted $name)){throw "Unexpected runtime dependency: $name"}}
    $source=(Get-ChildItem (Join-Path $extracted 'src') -File|ForEach-Object{[IO.File]::ReadAllText($_.FullName)})-join "`n"
    if($source -match '(?i)Install-WindowsFeature|Set-FsrmSetting|New-Fsrm|Get-Dfsn|Register-ScheduledTask'){throw 'Forbidden runtime mutation/discovery path.'}
}
Check 'DryRun from unrelated working directory writes nothing' {
    $ws=Join-Path $clean 'dryrun-no-write'
    Push-Location $env:SystemRoot
    try{$text=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $extracted 'Start-SOHReport.ps1') -Stage All -DryRun -Execute -Workspace $ws;if($LASTEXITCODE -ne 0){throw 'DryRun failed.'}}
    finally{Pop-Location}
    if(Test-Path $ws){throw 'DryRun wrote workspace.'}
    $plan=ConvertFrom-Json -InputObject ($text-join "`n");if(@($plan.Targets).Count -ne 58){throw 'Wrong customer input row count.'}
}
Check 'Offline All without Execute only validates and exits 2' {
    $ws=Join-Path $clean 'offline-workspace'
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $extracted 'Start-SOHReport.ps1') -Stage All -Offline -Workspace $ws | Out-Null
    if($LASTEXITCODE -ne 2){throw 'Expected incomplete validation exit 2.'}
    $map=Read-SOHJson (Join-Path $ws 'input\validated-targets.json')
    if(@($map.Rows).Count -ne 58 -or @($map.Rows|Where-Object Status -ne 'NEEDS_REVIEW').Count -ne 0 -or (Test-Path (Join-Path $ws 'runs'))){throw 'Unsafe offline behavior.'}
}
Check 'Read-only prerequisites local-only and no workspace creation' {
    $ws=Join-Path $clean 'prereq-no-write'
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $extracted 'Test-SOHPrerequisites.ps1') -Workspace $ws | Out-Null
    if($LASTEXITCODE -ne 0 -or (Test-Path $ws)){throw 'Prerequisites local-only smoke failed.'}
}
Check 'Checksum detects altered file then restores exact bytes' {
    $file=Join-Path $extracted 'VERSION.txt';$bytes=[IO.File]::ReadAllBytes($file)
    try{
        [IO.File]::WriteAllText($file,'tampered')
        $psi=New-Object Diagnostics.ProcessStartInfo
        $psi.FileName='powershell.exe';$psi.Arguments='-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $extracted 'Verify-SOHPackage.ps1')+'"'
        $psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
        $proc=[Diagnostics.Process]::Start($psi);$null=$proc.StandardOutput.ReadToEnd();$null=$proc.StandardError.ReadToEnd();$proc.WaitForExit()
        if($proc.ExitCode -eq 0){throw 'Tampered package passed checksums.'};$proc.Dispose()
    }finally{[IO.File]::WriteAllBytes($file,$bytes)}
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $extracted 'Verify-SOHPackage.ps1') | Out-Null
    if($LASTEXITCODE -ne 0){throw 'Restored package did not verify.'}
}
$smoke=[pscustomobject]@{CreatedUtc=[datetime]::UtcNow.ToString('o');PowerShell=$PSVersionTable.PSVersion.ToString();ProductionContact=$false;Package=$final;Zip=$zip;ZipSHA256=(Get-FileHash $zip).Hash;CleanExtraction=$clean;Tests=@($checks.ToArray());Passed=$checks.Count;Failed=0}
Write-SOHJson (Join-Path $Project 'reports\release-smoke.json') $smoke

# Complete development handoff, including the finished portable release, without disposable fixtures.
$handoffRoot=Join-Path $staging 'handoff\GL-WinFS-V2';[void][IO.Directory]::CreateDirectory($handoffRoot)
foreach($file in Get-ChildItem -LiteralPath $Project -File){if($file.Name -notlike '*.zip' -and $file.Name -notlike '*.sha256' -and $file.Name -ne 'SHA256SUMS.txt'){[IO.File]::Copy($file.FullName,(Join-Path $handoffRoot $file.Name),$false)}}
foreach($dir in @('src','input','tests','tools','reference','release')){if(Test-Path (Join-Path $Project $dir)){Copy-Item -LiteralPath (Join-Path $Project $dir) -Destination (Join-Path $handoffRoot $dir) -Recurse}}
[void][IO.Directory]::CreateDirectory((Join-Path $handoffRoot 'reports'))
foreach($report in Get-ChildItem -LiteralPath (Join-Path $Project 'reports') -File | Where-Object Name -ne 'complete-project-smoke.json'){
    [IO.File]::Copy($report.FullName,(Join-Path $handoffRoot ('reports\'+$report.Name)),$false)
}
Write-Checksums $handoffRoot
$handoff=Join-Path $Project 'GL-WinFS-V2-complete-project.zip';$tempHandoff=Join-Path $staging 'complete-project.zip'
Compress-Archive -LiteralPath $handoffRoot -DestinationPath $tempHandoff -CompressionLevel Optimal
if([IO.File]::Exists($handoff)){[IO.File]::Replace($tempHandoff,$handoff,[Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($tempHandoff,$handoff)}
Write-SOHAtomicText ($handoff+'.sha256') ((Get-FileHash $handoff).Hash+'  GL-WinFS-V2-complete-project.zip'+"`r`n")
$completeCheck=Join-Path $clean 'complete-project'
Expand-Archive -LiteralPath $handoff -DestinationPath $completeCheck
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $completeCheck 'GL-WinFS-V2\Verify-SOHPackage.ps1') | Out-Host
if($LASTEXITCODE -ne 0){throw 'Complete project clean extraction failed hashes.'}
Write-SOHJson (Join-Path $Project 'reports\complete-project-smoke.json') ([pscustomobject]@{CreatedUtc=[datetime]::UtcNow.ToString('o');Status='PASS';Archive=$handoff;SHA256=(Get-FileHash $handoff).Hash;CleanExtraction=$completeCheck;ProductionContact=$false})
Write-Host "Release: $zip"
Write-Host "Complete project: $handoff"
