# SOH Storage Chargeback V2 操作说明

版本 2.0.0；目标 Windows Server 2022 / Windows PowerShell 5.1。仅复制文件运行，无安装器、下载、计划任务、FSRM 配置或 DFS 依赖。**当前交付是离线测试通过、客户环境待验证的候选版本，不是已完成生产验收的正式计费系统。**

## 1. 拷贝与核验

可把整个开发项目文件夹复制给客户，但日常运行请使用其中 `release\GL-WinFS-V2`，或解压 `release.zip` 得到同名运行目录。示例复制到 `C:\Temp\GL-WinFS-V2`，后续命令均在客户批准后由客户执行；本地开发机未连接 SOH。

使用已有 `SOH\svc_HPEreport` 身份启动 **Windows PowerShell 5.1**。程序不存储密码、不提供另一套采集凭据；验证/采集/合并使用当前身份。按客户脚本执行策略审批；以下 `-ExecutionPolicy Bypass` 仅用于该进程，不修改系统策略，不覆盖组织 GPO。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\Temp\GL-WinFS-V2\Verify-SOHPackage.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\Temp\GL-WinFS-V2\Test-SOHPrerequisites.ps1
```

校验清单用于检测传输损坏，不是数字签名。建议先核验再修改客户输入；修改 `input\customer-targets.csv` 后该文件校验失败是预期，保留原包和业务审批版本。

默认 CSV 相对脚本定位为 `input\customer-targets.csv`；默认 Workspace 在包旁的 `workspace`（示例 `C:\Temp\workspace`）。建议明确使用 `C:\SOHReporting\workspace`。Workspace 必须是本机盘符路径，不能是 UNC 或 junction。无需从脚本目录启动命令。

## 2. 核对客户输入

实际清单为用户提供的 `SOH Reporting sources.csv`：58 行，源 SHA256 为 `1553B3209190B9F1AAC653200FACFAECBC5998C54034CCD80B747280CDBE5722`。用户已明确同意 **Business Owner → Department**，按顺序分配 `SOH-001` 至 `SOH-058`。原始四列、Tier 和 Host 均保留在 `input\SOH Reporting sources.original.csv` 与 `source-mapping.csv`，路径不修正。输入仅接受 `ID,Department,AbsolutePath` 三列，UTF-8（推荐 BOM）。请勿用 Excel 保存改变原始字符串；含逗号部门应保留 CSV 引号。

需要客户处理的已知事项：

| ID | 待确认内容 |
| --- | --- |
| SOH-001 | `\\sohfs3\ BDM` 的共享名前置空格 |
| SOH-002 | `\\sohf3\BSS Office` 与 Host=sohfs3 不一致 |
| SOH-009 | `\\sohfs3\ Communications` 的共享名前置空格 |
| SOH-012 | Department=`Digital ` 有尾部空格 |
| SOH-043 | `\\sohfs1\D$\*` 全 D 盘审批，并核对与 EmailArchives 的实际重叠 |
| SOH-050 | `\\sohfs4\D$\*` 全 D 盘审批和实际共享重叠 |
| SOH-054 | `Toursim Sales` 是否真实 SMB 共享名，不能自动替换成 Tourism Sales |

另有 `customer-targets.template.csv` 按任务书保留全 `PENDING_CONFIRMATION` 模板，**不是当前运行输入**。`suggested-corrections.csv` 是建议而非审批。所有 NEEDS_REVIEW/INVALID 行阻止整批生产采集，不能悄悄省略行。确认后客户在新的已批准 CSV 中修正；若疑似拼写/首尾空白本来就是合法真实名称，本版保持阻止，需另行审查明确批准规则后发布更新，不应通过直接改 validation JSON 绕过。

## 3. 先离线检查，再客户侧只读验证

```powershell
# 完全离线：不建立网络会话，返回码 2 表示尚未完成远端验证。
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\Temp\GL-WinFS-V2\Start-SOHReport.ps1 -Stage Validate -Offline -Workspace C:\SOHReporting\workspace
# DryRun 只向标准输出打印完整计划；不写文件、不连远端，即使带 -Execute 也不扫描。
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\Temp\GL-WinFS-V2\Start-SOHReport.ps1 -Stage All -DryRun -Workspace C:\SOHReporting\workspace
# 以下两条仅在客户环境且经客户批准后执行；都只读远端。
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\Temp\GL-WinFS-V2\Test-SOHPrerequisites.ps1 -Workspace C:\SOHReporting\workspace -CheckRemote
```

注意：`powershell.exe -File` 对数组参数的传递限制可能把逗号列表当一个字符串。三台代表服务器已经是默认值，推荐直接使用以下命令；若需自定义数组，在 Windows PowerShell 5.1 会话内直接调用脚本：

```powershell
& 'C:\Temp\GL-WinFS-V2\Test-SOHPrerequisites.ps1' -Workspace 'C:\SOHReporting\workspace' -CheckRemote
& 'C:\Temp\GL-WinFS-V2\Start-SOHReport.ps1' -Stage Validate -Workspace 'C:\SOHReporting\workspace'
```

验证生成 Workspace 下 `input\validated-targets.json`、原始 CSV 哈希副本、`output\validation.csv` 和 `validation-summary.txt`。VALID 需真实 Get-SmbShare.Path 与远端字面路径存在；权限不足或 Path 空白是 INVALID，绝不猜测 Synology 或盘符。短名/FQDN 经 DNS 与远端 UUID 确认；CNAME/集群与实际计算机不匹配时停止，交给客户核实。

同一物理目录同部门只扫描一次并关联多个 ID；跨部门重复和所有父子目录重叠阻止执行。当前安全默认不支持保留父子目录后自动分配容量；客户应提交互不重叠的授权目录集合。不能使用文件名前缀裁剪制造排除证明。

## 4. 客户 Gate 5：仅一个已批准小目录灰度

由客户在 `input\pilot-approved.csv` 创建**一行**真实已批准的小子目录（有明确 Department）。不要直接用全量清单或全盘条目做首测。保留该审批 CSV 与 SourceSHA256。

```powershell
& 'C:\Temp\GL-WinFS-V2\Start-SOHReport.ps1' -Stage Validate -CsvPath 'C:\Temp\GL-WinFS-V2\input\pilot-approved.csv' -Workspace 'C:\SOHReporting\pilot'
& 'C:\Temp\GL-WinFS-V2\Start-SOHReport.ps1' -Stage Collect -Execute -CsvPath 'C:\Temp\GL-WinFS-V2\input\pilot-approved.csv' -Workspace 'C:\SOHReporting\pilot' -MaxConcurrency 1 -MaxEntriesPerSecond 50 -MaxDiskQueueLength 2 -TimeoutSeconds 600
```

Collect 再次校验实际 CSV/共享，打印输入数、物理目标和全盘项。必须再输入完整 `COLLECT <RunId> <SourceSHA256>` 确认字符串；空白即取消。可显式给 `-RunId '<UUID>'` 并由授权操作员提供同样的 `-ConfirmationToken`，用于已有审批的非交互运行；不接受笼统的 yes。`-ApproveFullVolume` 在验证和采集都必须提供，仍不能绕过物理重叠检查。所有解析成卷根的共享，即使不含 `*`，也需全盘审批。

客户检查：当前账号正确、共享映射与实际盘符一致、每个 Owner 的 FileCount/LogicalBytes 对得上、无静默漏项、压测负载可接受、源文件及 ACL 未改变、无服务/任务/FSRM 改动。按 `CUSTOMER_ACCEPTANCE.md` 记录环境证据。通过后才审批扩大范围。

## 5. 报表、重试与退出码

每次 UUID 对应 `Workspace\runs\<RunId>\`：`run.json` 是冻结授权快照，`drop` 是本次结果，`output` 包含：

* `folder-report.csv`：每个输入 ID 一行；重复引用 `Counted=False`、容量为 0，并通过 PrimaryID/LinkedIDs 指向一次实际扫描。
* `department-report.csv`、`server-report.csv`：聚合逻辑容量与完整性。
* `owner-detail.csv`：每个物理路径/Owner 一行，可选 AD 字段与业务 Department 分开。
* `errors.csv`：每条实际错误和跳过原因。
* `run-manifest.json`：SHA256、输入/有效/待确认/计划/成功/部分/失败/去重/未覆盖统计及每个报表哈希。

数值均为 **logical namespace bytes**，不是磁盘实际占用。硬链接每个目录项分别计数；跨目录硬链接也按命名空间计量。稀疏文件、压缩、去重、ADS、快照、目录本身占用不在物理容量范围内；AllocatedBytes 为空。扫描并非一致性快照，扫描时变化存在时间窗口；应选稳定业务窗口，不应由管理员同时改共享、junction 或目录结构。

Junction/reparse 不跟随，文件/目录跳过及 ACL 失败均标记 PARTIAL/FAILED，ErrorCount 单独记录。不可读取的目录内部有多少文件不可知，SkippedDirectories 是已知失败入口数；未覆盖行数不等于未知文件数量。可读文件容量在 Owner 不可读时仍保留 UNKNOWN 并标 PARTIAL。

Collect 同时生成完整性报表；Merge 可单独重跑：

```powershell
& 'C:\Temp\GL-WinFS-V2\Start-SOHReport.ps1' -Stage Merge -Execute -Workspace 'C:\SOHReporting\pilot' -RunId '<上一次输出的 UUID>'
# 如已有 AD 模块且获准读取，可再加 -ResolveAD；失败不改变业务 Department。
```

退出码：0=操作完整成功（仍不代表生产验收）；2=校验待确认/无效或报表 INCOMPLETE；1=参数、I/O、确认拒绝、校验格式等致命错误。无 `-Execute` 的任何阶段降级为 Validate。无参菜单默认 Validate，不会自动串起所有阶段。

重试必须使用同一 CSV、相同全盘审批和原 RunId；已完成且哈希正确的物理目标复用，不重复采集。要刷新数据请用新 RunId。若授权或共享映射变化，必须新 RunId。不得手工把历史 CSV 放入预期文件名；未列入当前计划的历史/FSRM CSV 会记录为忽略，预期文件必须符合完整 schema 与本次身份。

取消：在 `Workspace\runs\<RunId>\cancel.request` 创建文件，调度器停止当前作业并写明未启动/中断目标；之后检查远端会话是否确已结束再重试。Ctrl+C/强制终止可能只留下 RUNNING_OR_INTERRUPTED 标记，此时手工 Merge 得到 INCOMPLETE。清除 cancel.request 后才可重试。硬终止时无法保证远端进程立刻停止，由客户核实。

## 6. 权限、负载、升级与回滚

服务账号需 WinRM endpoint 执行权、SMB Path/计算机 UUID/卷文件系统/性能计数器的只读查询权，以及目标树 traverse/list/read attributes/read permissions。需对报告机 Workspace 和远端 `C:\ProgramData\ChargebackOneV2`（可 `-RemoteRoot` 覆盖）有创建/修改自身结果的权限。源数据不需写权限，程序不提升备份权限，不修改 ACL/Owner。上游本地管理员是已记录的基线，最小委派权限、JEA 和 SOH 实际 ACL 尚待客户验证；不需 Domain Admin。可选 AD 仅需用户对象读取。

全局并发默认 1，可 1–4；同一服务器始终串行。每服务器默认最多 200 个目录项/秒；`MaxDiskQueueLength=2` 根据 Win32_PerfFormattedData_PerfDisk_LogicalDisk.CurrentDiskQueueLength 每约 1 秒检查，超限暂停，仍受超时约束。计数器不可用则失败，不忽略；客户明确决定后可设 0 禁用压力门限，速率上限仍在。该门限是近似负载控制，不是存储延迟 SLA。远端操作超时外加 30 秒传输/停止宽限，单次阻塞系统调用仍依赖 WinRM 中止响应。

远端仅创建本次 UUID 的结果文件，不安装/复制常驻采集器、不启动服务，作业是临时 WinRM 作业而非计划任务。报告目录必须在扫描树之外，避免采集自己的输出；全 C 盘需另一盘 RemoteRoot。输出路径也不得经过 junction。

升级：保留原包、校验值、客户 CSV 与整个 Workspace；把新版本复制到新的并列目录，先核验 SHA256，再只读验证/一条灰度。不要覆盖旧目录或删历史运行。回滚：停止新运行并确认远端退出，改回旧版本入口及其原 Workspace。V2 不更改服务器配置，因此没有服务/FSRM 配置回滚步骤。历史结果不跨 RunId 合并；客户按自己的保留政策手动归档远端 UUID 文件夹。本程序不会自动清理客户数据。

## English technical appendix

Runtime is Windows PowerShell 5.1 and built-in .NET/CIM/WinRM/SmbShare. No Git/Python/Node/Pester runtime dependency. Source-to-target contracts and trust boundaries are in README_DEVELOPER.md. Atomic UTF-8 BOM writes use a same-directory temporary file, content verification, File.Replace (PS 5.1 NullString.Value) or File.Move. The workspace lock serializes orchestrators using that workspace; do not run the same RunId simultaneously from different workspaces. Report manifest is committed last and its report hashes must be checked before downstream use.

CSV is the only scope authorization. DNS lookup and cached read-only share enumeration cannot introduce a scan target. Actual share path and host UUID are rechecked immediately before remote collection. Local drive CSV paths are refused because the three-column schema has no server field. Cluster/CNAME endpoint mismatches are deliberately unsupported pending a tested identity policy. Reparse mounts are skipped/blocked, so mounted-volume paths require a separately approved direct share and verified mapping.

Mock tests validate software behavior; they do not certify real remoting serialization, transport cancellation, performance counters, permissions, AD availability or Windows Server 2022 behavior. Local runtime evidence is Windows 11 / Windows PowerShell 5.1. Customer Gate 5 is explicitly PENDING.
