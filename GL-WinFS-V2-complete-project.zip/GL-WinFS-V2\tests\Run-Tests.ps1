#requires -Version 5.1
[CmdletBinding()]
param([string]$Project,[string]$EvidenceName='test-results')
$ErrorActionPreference='Stop'
if(-not $Project){$Project=Split-Path -Parent $PSScriptRoot}
$Project=[IO.Path]::GetFullPath($Project)
foreach($f in @('Common','Validation','Collector','Orchestration','Merge')){. (Join-Path $Project ('src\'+$f+'.ps1'))}
$testRoot=Join-Path $Project ('test-work\'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($testRoot)
$results=New-Object 'Collections.Generic.List[object]'
function Assert($Condition,[string]$Message='Assertion failed'){if(-not $Condition){throw $Message}}
function Equal($Actual,$Expected,[string]$Message='Values differ'){if($Actual -cne $Expected){throw "$Message : expected=[$Expected] actual=[$Actual]"}}
function Throws([scriptblock]$Body,[string]$Pattern='*'){try{& $Body}catch{if($_.Exception.Message -like $Pattern){return};throw};throw 'Expected an exception.'}
function Case([string]$Name,[string]$Gate,[scriptblock]$Body){
    $sw=[Diagnostics.Stopwatch]::StartNew()
    try{& $Body;$results.Add([pscustomobject]@{Name=$Name;Gate=$Gate;Status='PASS';Seconds=$sw.Elapsed.TotalSeconds;Detail=''});Write-Host "PASS $Name"}
    catch{$results.Add([pscustomobject]@{Name=$Name;Gate=$Gate;Status='FAIL';Seconds=$sw.Elapsed.TotalSeconds;Detail=$_.Exception.Message+' AT '+$_.ScriptStackTrace});Write-Host "FAIL $Name : $_"}
}
function Csv([object[]]$Rows){$p=Join-Path $testRoot ([guid]::NewGuid().ToString('N')+'.csv');Write-SOHCsv $p $Rows @('ID','Department','AbsolutePath');return $p}
function Row([string]$ID,[string]$Department,[string]$Path){[pscustomobject]@{ID=$ID;Department=$Department;AbsolutePath=$Path}}
$script:resolveCalls=0
$resolver={param($p,$ctx)
    $script:resolveCalls++
    if($p.Share -eq 'Denied'){throw 'Access denied'}
    if($p.Share -eq 'Empty'){throw 'Get-SmbShare.Path blank'}
    if($p.Share -eq 'Missing'){throw 'The system cannot find the file specified'}
    $server=$p.HostName.Split('.')[0]+'.example.test'
    $root=switch($p.Share){'Alias'{'D:\Data'}'D$'{'D:\'}default{'D:\'+$p.Share}}
    if($p.Suffix){$root=[IO.Path]::Combine($root,$p.Suffix)}
    [pscustomobject]@{Server=$server;HostId='uuid-'+$server;LocalPath=$root;Evidence='MOCK CIM/WinRM SMB Path + existence'}
}
function Validate([object[]]$Rows,[switch]$Approve){Invoke-SOHValidate -CsvPath (Csv $Rows) -Workspace $testRoot -Resolver $resolver -ApproveFullVolume:$Approve -NoWrite}

Case 'Windows PowerShell 5.1 actual runtime' '4' {Equal $PSVersionTable.PSEdition 'Desktop';Equal $PSVersionTable.PSVersion.Major 5;Equal $PSVersionTable.PSVersion.Minor 1}
Case 'All project PowerShell files parse' '4' {
    foreach($f in Get-ChildItem -LiteralPath $Project -Recurse -File | Where-Object {$_.Extension -in @('.ps1','.psm1') -and $_.FullName -notmatch '\\(release|test-work)\\'}){
        $tokens=$null;$parseErrors=$null;[void][Management.Automation.Language.Parser]::ParseFile($f.FullName,[ref]$tokens,[ref]$parseErrors)
        Assert (@($parseErrors).Count -eq 0) ($f.Name+': '+(@($parseErrors | ForEach-Object Message) -join ';'))
    }
}
Case 'No FSRM DFS install service ACL or task mutation commands' '2' {
    $forbidden='^(Install-WindowsFeature|Add-WindowsCapability|Set-Fsrm.*|.*-Fsrm.*|Start-Service|Set-Service|.*-ScheduledTask.*|Set-Acl|Set-Smb.*|New-Smb.*|Get-Dfs.*|Enable-PSRemoting|Invoke-WebRequest|Invoke-RestMethod)$'
    foreach($f in Get-ChildItem (Join-Path $Project 'src') -File){
        $tok=$null;$err=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($f.FullName,[ref]$tok,[ref]$err)
        foreach($c in $ast.FindAll({param($n)$n -is [Management.Automation.Language.CommandAst]},$true)){Assert ($c.GetCommandName() -notmatch $forbidden) ('Forbidden command: '+$c.GetCommandName())}
    }
}
Case 'UNC root and subpath with spaces remain exact' '1' {$m=Validate @((Row a Sales '\\mock\Data\Sub Dir\'));Equal $m.Rows[0].Status 'VALID';Equal $m.Rows[0].LocalPath 'D:\Data\Sub Dir'}
Case 'Strict reject URI local relative device variable traversal wildcard' '1' {
    foreach($p in @('http://x/a','D:\Data','Data','\\?\C:\Data','\\.\D$','\\mock\Data\..\Secret','\\mock\Data\*','\\mock\D$\sub\*','\\mock\C$\*','\\mock\%USERPROFILE%','\\mock\Data\foo?','\\mock\Data\x:y','\\mock\Data\[ab]','\\mock\Data\.','\\mock\Data\x.')){Throws {ConvertTo-SOHParsedPath $p}}
}
Case 'Whitespace and known typos are never silently fixed or resolved' '1' {
    $before=$script:resolveCalls
    $m=Validate @((Row a Sales ' \\mock\Data '),(Row b Sales '\\sohfs3\ BDM'),(Row c Sales '\\sohf3\BSS Office'),(Row d Sales '\\sohfs3\Toursim Sales'))
    Equal @($m.Rows|Where-Object Status -eq 'NEEDS_REVIEW').Count 4;Equal $script:resolveCalls $before;Equal $m.Rows[0].OriginalPath ' \\mock\Data ';Assert $m.Rows[0].SuggestedCorrection
}
Case 'D dollar wildcard requires separate full-volume approval' '1' {
    $m=Validate @((Row a IT '\\mock\D$\*'));Equal $m.Rows[0].Status 'NEEDS_REVIEW';Assert $m.Rows[0].FullVolume
    $m=Validate @((Row a IT '\\mock\D$\*')) -Approve;Equal $m.Rows[0].Status 'VALID';Equal $m.Rows[0].LocalPath 'D:\';Throws {Assert-SOHCollectMap $m -AllowTest} '*Full volume*'
}
Case 'Blank path access denied missing path all errors retained' '1' {
    $m=Validate @((Row a IT '\\mock\Denied'),(Row b IT '\\mock\Empty'),(Row c IT '\\mock\Missing'),(Row d IT '\\mock\Good'))
    Equal @($m.Rows|Where-Object Status -eq 'INVALID').Count 3;Equal $m.Rows[3].Status 'VALID';Assert ($m.Rows[0].Errors -join '' -notmatch 'synology')
}
Case '175 permission failures not phase3-synology; 103 resolved Windows paths' '1' {
    $bad=1..175|ForEach-Object{Row ('a'+$_) Dept '\\mock\Denied'};$m=Validate @($bad);Equal @($m.Rows|Where-Object Status -eq 'INVALID').Count 175
    $good=1..103|ForEach-Object{Row ('a'+$_) Dept ('\\mock\Folder'+$_)};$m=Validate @($good);Equal @($m.Rows|Where-Object Status -eq 'VALID').Count 103
}
Case 'Short FQDN case slash aliases deduplicate SOHFS7 Marketing' '1' {
    $m=Validate @((Row a Marketing '\\SOHFS7\Marketing'),(Row b Marketing '\\sohfs7.example.test\Marketing\'))
    Equal @(Get-SOHPhysicalTargets $m).Count 1;Equal $m.Rows[1].LinkedIDs.Count 2
}
Case 'Different shares mapped to same physical directory scan once' '1' {$m=Validate @((Row a Sales '\\mock\Data'),(Row b Sales '\\mock\Alias'));Equal @(Get-SOHPhysicalTargets $m).Count 1}
Case 'Cross-department same physical path blocks entire collect' '1' {$m=Validate @((Row a Sales '\\mock\Data'),(Row b HR '\\mock\Alias'));Equal @($m.Rows|Where-Object Status -eq 'NEEDS_REVIEW').Count 2;Throws {Assert-SOHCollectMap $m -AllowTest}}
Case 'SOHFS4 AppConfig SketchUp parents block overlapping children' '1' {
    $m=Validate @((Row a IT '\\sohfs4\AppConfig'),(Row b IT '\\sohfs4\AppConfig\Child'),(Row c IT '\\sohfs4\SketchUp'),(Row d IT '\\sohfs4\SketchUp\Child'))
    Equal @($m.Rows|Where-Object Status -eq 'NEEDS_REVIEW').Count 4
}
Case 'D Data is not ancestor of D Data2' '1' {$m=Validate @((Row a IT '\\mock\Data'),(Row b IT '\\mock\Data2'));Equal @($m.Rows|Where-Object Status -eq 'VALID').Count 2}
Case 'Full D volume and nested share conflict even after approval' '1' {$m=Validate @((Row a IT '\\sohfs1\D$\*'),(Row b IT '\\sohfs1\EmailArchives')) -Approve;Equal @($m.Rows|Where-Object Status -eq 'NEEDS_REVIEW').Count 2}
Case 'Duplicate unsafe IDs missing pending or padded Department rejected' '1' {
    $m=Validate @((Row a IT '\\mock\A'),(Row a IT '\\mock\B'),(Row '../bad' '' '\\mock\C'),(Row d PENDING_CONFIRMATION '\\mock\D'),(Row e 'Digital ' '\\mock\E'))
    Equal @($m.Rows|Where-Object Status -ne 'VALID').Count 5
}
Case 'Empty wrong-column extra-cell malformed CSV rejected' '1' {
    foreach($text in @('','ID,Department,AbsolutePath','Host,Department,AbsolutePath'+"`r`na,b,c")){
        $p=Join-Path $testRoot 'dirty.csv';Write-SOHAtomicText $p $text;Throws {Invoke-SOHValidate $p $testRoot -Offline -NoWrite}
    }
    $p=Join-Path $testRoot 'dirty.csv';Write-SOHAtomicText $p "ID,Department,AbsolutePath`r`na,b,\\mock\Data,extra`r`nb,c,\\mock\Good"
    $m=Invoke-SOHValidate $p $testRoot -Resolver $resolver -NoWrite;Equal $m.Rows[0].Status 'INVALID';Equal $m.Rows[1].Status 'VALID'
}
Case 'UTF8 BOM Chinese comma and JSON arrays round-trip in PS51' '1' {
    $dept=[string][char]0x5e02+[char]0x573a+', Sales'
    $p=Csv @((Row a $dept '\\mock\Data'),(Row b Other '\\mock\Other'))
    $m=Invoke-SOHValidate $p $testRoot -Resolver $resolver
    $r=Read-SOHJson (Join-Path $testRoot 'input\validated-targets.json');Equal $r.Rows.Count 2;Equal $r.Rows[0].Department $dept
    $a=ConvertFrom-Json -InputObject '[{"ID":"a"},{"ID":"b"}]';Equal @($a).Count 2
    Equal ([IO.File]::ReadAllBytes($p)[0]) 239
}
Case 'Offline validation never invokes resolver' '1' {$m=Invoke-SOHValidate (Csv @((Row a IT '\\mock\Data'))) $testRoot -Offline -Resolver {throw 'NETWORK SHOULD NOT RUN'} -NoWrite;Equal $m.Rows[0].Status 'NEEDS_REVIEW'}

$fixture=Join-Path $testRoot 'ntfs';[void][IO.Directory]::CreateDirectory($fixture)
[IO.File]::WriteAllBytes((Join-Path $fixture 'a.bin'),(New-Object byte[] 11));[IO.File]::WriteAllBytes((Join-Path $fixture 'b.bin'),(New-Object byte[] 23))
[void][IO.Directory]::CreateDirectory((Join-Path $fixture 'sub'));[IO.File]::WriteAllBytes((Join-Path $fixture 'sub\c.bin'),(New-Object byte[] 7))
Case 'Real NTFS metadata walk owner FileCount and Size exact' '2' {$r=Invoke-SOHNtfsWalk $fixture -MaxEntriesPerSecond 10000;Equal $r.Status 'SUCCESS';Equal $r.FileCount 3;Equal $r.LogicalBytes 41;Equal ($r.Owners|Measure-Object FileCount -Sum).Sum 3;Equal ($r.Owners|Measure-Object LogicalBytes -Sum).Sum 41;Equal $r.ErrorCount 0}
Case 'Missing path does not lose successful sibling target' '2' {$a=Invoke-SOHNtfsWalk (Join-Path $fixture 'missing');$b=Invoke-SOHNtfsWalk $fixture -MaxEntriesPerSecond 10000;Equal $a.Status 'FAILED';Equal $b.Status 'SUCCESS';Equal $b.LogicalBytes 41}
Case 'ACL read failure retains measured bytes and PARTIAL' '2' {$r=Invoke-SOHNtfsWalk $fixture -MaxEntriesPerSecond 10000 -ReadOwner {throw 'Mock Access denied ACL'};Equal $r.Status 'PARTIAL';Equal $r.FileCount 3;Equal $r.LogicalBytes 41;Equal $r.ErrorCount 3;Equal $r.Owners[0].Owner 'UNKNOWN'}
Case 'Directory enumeration denial counted not silently complete' '2' {$r=Invoke-SOHNtfsWalk $fixture -ListDirectory {throw 'Access denied directory'};Equal $r.Status 'PARTIAL';Equal $r.SkippedDirectories 1;Assert ($r.ErrorCount -gt 0)}
Case 'Reparse entries skipped without enumerating outside tree' '2' {
    $r=Invoke-SOHNtfsWalk $fixture -ListDirectory {param($dir)[pscustomobject]@{FullName='D:\outside';Attributes=([IO.FileAttributes]::Directory -bor [IO.FileAttributes]::ReparsePoint)}} -MaxEntriesPerSecond 10000
    Equal $r.SkippedDirectories 1;Equal $r.FileCount 0;Equal $r.Status 'PARTIAL'
}
Case 'Real junction and reparse target ancestors rejected' '2' {
    $outside=Join-Path $testRoot 'outside';[void][IO.Directory]::CreateDirectory($outside);[IO.File]::WriteAllBytes((Join-Path $outside 'secret'),(New-Object byte[] 99))
    $link=Join-Path $fixture 'junction';New-Item -ItemType Junction -Path $link -Target $outside | Out-Null
    try{$r=Invoke-SOHNtfsWalk $fixture -MaxEntriesPerSecond 10000;Equal $r.LogicalBytes 41;Equal $r.Status 'PARTIAL';Equal $r.SkippedDirectories 1;Throws {Assert-SOHNoReparse $link}}finally{[IO.Directory]::Delete($link)}
}
Case 'Real hardlinks count logical namespace entries explicitly' '2' {
    $hard=Join-Path $fixture 'hardlink.bin';New-Item -ItemType HardLink -Path $hard -Target (Join-Path $fixture 'a.bin') | Out-Null
    try{$r=Invoke-SOHNtfsWalk $fixture -MaxEntriesPerSecond 10000;Equal $r.LogicalBytes 52;Equal $r.FileCount 4;Assert ($r.Measurement -like '*hard-link*')}finally{[IO.File]::Delete($hard)}
}
Case 'Walk timeout bounded and explicitly incomplete' '2' {$r=Invoke-SOHNtfsWalk $fixture -TimeoutSeconds 1 -MaxEntriesPerSecond 1;Assert ($r.Status -ne 'SUCCESS');Assert (($r.Errors.Message -join ' ') -like '*TIMEOUT*')}
Case 'I/O pressure gate pauses and resumes when queue drops' '2' {
    $script:pressureCalls=0
    $r=Invoke-SOHNtfsWalk $fixture -TimeoutSeconds 5 -MaxEntriesPerSecond 10000 -MaxDiskQueueLength 2 -PressureProbe {$script:pressureCalls++;if($script:pressureCalls -eq 1){9}else{0}}
    Equal $r.Status 'SUCCESS';Assert ($script:pressureCalls -ge 2);Assert ($r.ElapsedSeconds -ge 0.19)
}
Case 'Metadata rate limiter does not bank burst credit during slow I/O' '2' {
    $script:ownerTimes=New-Object 'Collections.Generic.List[datetime]'
    $r=Invoke-SOHNtfsWalk $fixture -TimeoutSeconds 10 -MaxEntriesPerSecond 10 -ReadOwner {
        $script:ownerTimes.Add([datetime]::UtcNow)
        if($script:ownerTimes.Count -eq 1){Start-Sleep -Milliseconds 500}
        [pscustomobject]@{Owner='MOCK';SID='S-1-5-18'}
    }
    Equal $r.Status 'SUCCESS';Assert (($script:ownerTimes[2]-$script:ownerTimes[1]).TotalMilliseconds -ge 85)
}
Case 'I/O pressure timeout or missing counter cannot report success' '2' {
    $r=Invoke-SOHNtfsWalk $fixture -TimeoutSeconds 1 -MaxDiskQueueLength 2 -PressureProbe {9};Equal $r.Status 'FAILED';Assert (($r.Errors.Message -join '') -like '*TIMEOUT*')
    $r=Invoke-SOHNtfsWalk $fixture -MaxDiskQueueLength 2 -PressureProbe {throw 'Counter unavailable'};Equal $r.Status 'FAILED'
}
Case 'Atomic write retry no extra file and invalid output destination fails' '2' {
    $p=Join-Path $testRoot 'atomic.txt';Write-SOHAtomicText $p 'first';Write-SOHAtomicText $p 'second';Equal ([IO.File]::ReadAllText($p)) 'second'
    Throws {Write-SOHAtomicText (Join-Path $p 'child') 'x'}
    Equal @(Get-ChildItem $testRoot -Filter '*.tmp').Count 0
}
Case 'Real output ACL denial is surfaced' '2' {
    $dir=Join-Path $testRoot 'deny-output';[void][IO.Directory]::CreateDirectory($dir);$original=Get-Acl -LiteralPath $dir
    $denied=Get-Acl -LiteralPath $dir;$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User
    $rule=New-Object Security.AccessControl.FileSystemAccessRule($sid,[Security.AccessControl.FileSystemRights]::Write,[Security.AccessControl.AccessControlType]::Deny)
    $denied.AddAccessRule($rule)
    try{Set-Acl -LiteralPath $dir -AclObject $denied;Throws {Write-SOHAtomicText (Join-Path $dir 'x.txt') 'x'}}finally{Set-Acl -LiteralPath $dir -AclObject $original}
}

# Offline mocks for remote APIs. All data paths point only inside this test fixture.
$script:mockShares=@([pscustomobject]@{Name='Data';Path=$fixture},[pscustomobject]@{Name='Alias';Path=$fixture})
function Get-CimInstance {param($ClassName,$Filter) if($ClassName -eq 'Win32_ComputerSystemProduct'){[pscustomobject]@{UUID='mock-uuid'}}elseif($ClassName -eq 'Win32_LogicalDisk'){[pscustomobject]@{FileSystem='NTFS'}}else{[pscustomobject]@{DNSHostName='mock';PartOfDomain=$true;Domain='example.test'}}}
function Get-SmbShare {param($Name) if($Name){$script:mockShares|Where-Object Name -ieq $Name}else{$script:mockShares}}
$localResolver={param($p,$ctx)[pscustomobject]@{Server='mock.example.test';HostId='mock-uuid';LocalPath=$fixture;Evidence='MOCK remote mapping to isolated local NTFS fixture'}}
$runWorkspace=Join-Path $testRoot 'integration'
$localCsv=Csv @((Row a 'Dept, One' '\\mock\Data'),(Row b 'Dept, One' '\\mock.example.test\Alias'))
$localMap=Invoke-SOHValidate $localCsv $runWorkspace -Resolver $localResolver
$run=New-SOHRun $localMap $runWorkspace ([guid]::NewGuid().ToString('D')) -AllowTest
$remoteRoot=Join-Path $testRoot 'mock-remote'
$packet=$null
Case 'Remote collector writes only RunId target artifacts and retry idempotent' '2' {
    $request=[pscustomobject]@{RunId=$run.RunId;Target=$run.Targets[0];RemoteRoot=$remoteRoot;TimeoutSeconds=60;MaxEntriesPerSecond=10000}
    $script:packet=Invoke-SOHRemoteCollect $request
    $again=Invoke-SOHRemoteCollect $request
    Equal $again.Result.CsvSHA256 $packet.Result.CsvSHA256;Equal $again.Result.StartedUtc $packet.Result.StartedUtc
    Equal @(Get-ChildItem (Join-Path $remoteRoot $run.RunId) -File).Count 2
}
Case 'PS51 serialized request and remote script payload run offline' '2' {
    $request=[pscustomobject]@{RunId=[guid]::NewGuid().ToString('D');Target=$run.Targets[0];RemoteRoot=$remoteRoot;TimeoutSeconds=60;MaxEntriesPerSecond=10000;MaxDiskQueueLength=2}
    $deserialized=[Management.Automation.PSSerializer]::Deserialize([Management.Automation.PSSerializer]::Serialize($request))
    $mockCode=@'
function Get-CimInstance {param($ClassName,$Filter) if($ClassName -eq 'Win32_ComputerSystemProduct'){[pscustomobject]@{UUID=$Request.Target.HostId}}elseif($ClassName -eq 'Win32_LogicalDisk'){[pscustomobject]@{FileSystem='NTFS'}}else{[pscustomobject]@{CurrentDiskQueueLength=0}}}
function Get-SmbShare {param($Name) [pscustomobject]@{Name=$Name;Path=$Request.Target.LocalPath}}
'@
    $body="param(`$Request)`r`n"+$mockCode+"`r`n"
    foreach($n in @('Common','Validation','Collector')){$body += [IO.File]::ReadAllText((Join-Path $Project ('src\'+$n+'.ps1')))+"`r`n"}
    $body += 'Invoke-SOHRemoteCollect $Request'
    $ps=[powershell]::Create()
    try{$output=$ps.AddScript($body).AddArgument($deserialized).Invoke();Assert (-not $ps.HadErrors) ($ps.Streams.Error|Out-String);Equal $output.Count 1;Equal $output[0].Result.Status 'SUCCESS';Equal $output[0].Result.LogicalBytes 41
        $roundTrip=[Management.Automation.PSSerializer]::Deserialize([Management.Automation.PSSerializer]::Serialize($output[0]));Equal $roundTrip.Result.RunId $request.RunId
    }finally{$ps.Dispose()}
}
$drop=Join-Path $runWorkspace ('runs\'+$run.RunId+'\drop')
if($packet){Copy-Item -LiteralPath $packet.CsvPath,$packet.ResultPath -Destination $drop}
Case 'Merge departments deduped with each input ID traceable' '3' {
    $m=Invoke-SOHMerge $run $runWorkspace;Equal $m.Status 'COMPLETE';Equal $m.InputRows 2;Equal $m.DeduplicatedRows 1;Equal $m.SuccessfulTargets 1
    $o=Join-Path $runWorkspace ('runs\'+$run.RunId+'\output')
    $dept=@(Import-Csv (Join-Path $o 'department-report.csv'));Equal $dept[0].LogicalBytes '41';Equal $dept[0].FileCount '3';Equal $dept[0].AllocatedBytes ''
    $folders=@(Import-Csv (Join-Path $o 'folder-report.csv'));Equal $folders.Count 2;Equal $folders[1].LogicalBytes '0';Equal $folders[1].PrimaryID 'a'
}
Case 'Optional AD failure never overwrites CSV Department' '3' {
    $m=Invoke-SOHMerge $run $runWorkspace -ADResolver {throw 'AD unavailable'};Equal $m.Status 'COMPLETE'
    $owner=@(Import-Csv (Join-Path $runWorkspace ('runs\'+$run.RunId+'\output\owner-detail.csv')));Equal $owner[0].Department 'Dept, One';Assert ($owner[0].ADStatus -like 'UNRESOLVED*')
}
Case 'FSRM title and historical CSV ignored with audit list' '3' {
    Write-SOHAtomicText (Join-Path $drop 'Files by Owner Report.csv') "Files by Owner Report`r`nOwner,Size`r`nold,99999"
    Write-SOHAtomicText (Join-Path $drop 'old-run.csv') 'bad,old,data'
    $m=Invoke-SOHMerge $run $runWorkspace;Equal $m.Status 'COMPLETE';Equal $m.IgnoredUnlistedCsv.Count 2
}
Case 'Wrong RunId in exact collector file rejected even valid hash' '3' {
    $path=Join-Path $drop ([IO.Path]::GetFileName($packet.CsvPath));$rpath=Join-Path $drop ([IO.Path]::GetFileName($packet.ResultPath));$original=[IO.File]::ReadAllText($path);$resultOriginal=[IO.File]::ReadAllText($rpath)
    try{$bad=$original.Replace($run.RunId,[guid]::NewGuid().ToString('D'));Write-SOHAtomicText $path $bad;$r=Read-SOHJson $rpath;$r.CsvSHA256=(Get-FileHash $path).Hash;Write-SOHJson $rpath $r;$m=Invoke-SOHMerge $run $runWorkspace;Equal $m.Status 'INCOMPLETE';Equal $m.FailedTargets 1}
    finally{Write-SOHAtomicText $path $original;Write-SOHAtomicText $rpath $resultOriginal}
}
Case 'Dirty negative unit-bearing or duplicate owner data rejected' '3' {
    $path=Join-Path $drop ([IO.Path]::GetFileName($packet.CsvPath));$rp=Join-Path $drop ([IO.Path]::GetFileName($packet.ResultPath));$orig=[IO.File]::ReadAllText($path);$ro=[IO.File]::ReadAllText($rp)
    try{foreach($bad in @('-1','1 GB','1.5')){$data=@(Import-Csv $path);$data[0].LogicalBytes=$bad;Write-SOHCsv $path $data $script:CollectorColumns;$r=Read-SOHJson $rp;$r.CsvSHA256=(Get-FileHash $path).Hash;Write-SOHJson $rp $r;$m=Invoke-SOHMerge $run $runWorkspace;Equal $m.Status 'INCOMPLETE';Write-SOHAtomicText $path $orig;Write-SOHAtomicText $rp $ro}}
    finally{Write-SOHAtomicText $path $orig;Write-SOHAtomicText $rp $ro}
}
Case 'Missing interrupted result incomplete and uncounted' '3' {
    $rp=Join-Path $drop ([IO.Path]::GetFileName($packet.ResultPath));$orig=[IO.File]::ReadAllText($rp)
    try{[IO.File]::Delete($rp);$m=Invoke-SOHMerge $run $runWorkspace;Equal $m.Status 'INCOMPLETE';Equal $m.UncoveredInputRows 2}
    finally{Write-SOHAtomicText $rp $orig}
}
Case 'PARTIAL is never accepted as complete chargeback' '3' {
    $rp=Join-Path $drop ([IO.Path]::GetFileName($packet.ResultPath));$cp=Join-Path $drop ([IO.Path]::GetFileName($packet.CsvPath));$orig=[IO.File]::ReadAllText($rp);$oc=[IO.File]::ReadAllText($cp)
    try{$r=Read-SOHJson $rp;$r.Status='PARTIAL';$r.SkippedFiles=1;$data=@(Import-Csv $cp);foreach($d in $data){$d.Status='PARTIAL'};Write-SOHCsv $cp $data $script:CollectorColumns;$r.CsvSHA256=(Get-FileHash $cp).Hash;Write-SOHJson $rp $r;$m=Invoke-SOHMerge $run $runWorkspace;Equal $m.Status 'INCOMPLETE';Equal $m.PartialTargets 1}
    finally{Write-SOHAtomicText $rp $orig;Write-SOHAtomicText $cp $oc}
}
Case 'Run snapshot immutable checksum and foreign binding rejection' '3' {
    $same=New-SOHRun $localMap $runWorkspace $run.RunId -AllowTest;Equal $same.RunId $run.RunId
    $other=Read-SOHJson (Join-Path $runWorkspace 'input\validated-targets.json');$other.SourceSHA256='different';Throws {New-SOHRun $other $runWorkspace $run.RunId -AllowTest}
    $rf=Join-Path $runWorkspace ('runs\'+$run.RunId+'\run.json');$orig=[IO.File]::ReadAllText($rf)
    try{Write-SOHAtomicText $rf ($orig+' ');Throws {Read-SOHRun $runWorkspace $run.RunId} '*checksum*'}finally{Write-SOHAtomicText $rf $orig}
}
Case 'Source CSV bytes hash retained exactly' '1' {$preserved=Join-Path $runWorkspace ('input\source-'+$localMap.SourceSHA256+'.csv');Equal (Get-FileHash $preserved).Hash (Get-FileHash $localCsv).Hash}

# Cached WinRM/CIM mock path. DNS cache seeded: no DNS calls possible.
$script:opens=0;$script:shareCalls=0
function New-PSSessionOption {param($OpenTimeout,$OperationTimeout) @{}}
function New-PSSession {param($ComputerName,$SessionOption) $script:opens++;[pscustomobject]@{ComputerName=$ComputerName}}
function Remove-PSSession {param($Session)}
function Invoke-Command {param($Session,$ScriptBlock,[object[]]$ArgumentList) & $ScriptBlock @ArgumentList}
Case 'One session and share list cached per short/FQDN host' '1' {
    $ctx=New-SOHRemoteContext;$ctx.DNS['mock']='mock.example.test';$ctx.DNS['mock.example.test']='mock.example.test'
    $before=$script:opens
    $a=Resolve-SOHTarget (ConvertTo-SOHParsedPath '\\mock\Data') $ctx
    $b=Resolve-SOHTarget (ConvertTo-SOHParsedPath '\\mock.example.test\Alias') $ctx
    Equal ($script:opens-$before) 1;Equal $ctx.Hosts.Count 1;Equal $a.HostId $b.HostId;Equal $a.LocalPath $b.LocalPath
}
Case 'Actual resolver rejects empty SMB path without drive guessing' '1' {
    $ctx=New-SOHRemoteContext;$ctx.DNS['mock']='mock.example.test';$saved=$script:mockShares
    try{$script:mockShares=@([pscustomobject]@{Name='Data';Path=''});Throws {Resolve-SOHTarget (ConvertTo-SOHParsedPath '\\mock\Data') $ctx} '*blank*'}finally{$script:mockShares=$saved}
}
Case 'Remote mapping changes blocked before scan or output writes' '2' {
    $saved=$script:mockShares
    try{$script:mockShares=@([pscustomobject]@{Name='Data';Path='D:\Different'});$req=[pscustomobject]@{RunId=[guid]::NewGuid().ToString('D');Target=$run.Targets[0];RemoteRoot=$remoteRoot;TimeoutSeconds=60;MaxEntriesPerSecond=200};Throws {Invoke-SOHRemoteCollect $req} '*mapping changed*'}finally{$script:mockShares=$saved}
}
Case 'DryRun CLI writes nothing and never resolves hosts' '4' {
    $ws=Join-Path $testRoot 'must-not-exist'
    $output=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Project 'Start-SOHReport.ps1') -Stage All -Execute -DryRun -CsvPath $localCsv -Workspace $ws
    Equal $LASTEXITCODE 0;Assert (-not (Test-Path $ws));$plan=ConvertFrom-Json -InputObject ($output -join "`n");Equal $plan.Mode 'DRY_RUN';Equal @($plan.Targets).Count 2
}
Case 'No Execute All CLI validates only with nonzero incomplete exit' '4' {
    $ws=Join-Path $testRoot 'safe-all'
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Project 'Start-SOHReport.ps1') -Stage All -Offline -CsvPath $localCsv -Workspace $ws | Out-Null
    Equal $LASTEXITCODE 2;Assert (Test-Path (Join-Path $ws 'output\validation.csv'));Assert (-not (Test-Path (Join-Path $ws 'runs')))
}
Case 'Merge CLI incomplete returns nonzero and complete returns zero' '4' {
    $rp=Join-Path $drop ([IO.Path]::GetFileName($packet.ResultPath));$orig=[IO.File]::ReadAllText($rp)
    try{[IO.File]::Delete($rp);& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Project 'Start-SOHReport.ps1') -Stage Merge -Execute -Workspace $runWorkspace -RunId $run.RunId | Out-Null;Equal $LASTEXITCODE 2}
    finally{Write-SOHAtomicText $rp $orig}
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Project 'Start-SOHReport.ps1') -Stage Merge -Execute -Workspace $runWorkspace -RunId $run.RunId | Out-Null;Equal $LASTEXITCODE 0
}
Case 'Production CLI cannot collect test-mode or pending inputs' '4' {Throws {Assert-SOHCollectMap $localMap};$m=Validate @((Row a PENDING_CONFIRMATION '\\mock\Data'));Throws {Assert-SOHCollectMap $m -AllowTest}}
Case 'Read-only prerequisites local mode makes no files' '4' {
    $ws=Join-Path $testRoot 'prereq-must-not-exist';$output=& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Project 'Test-SOHPrerequisites.ps1') -Workspace $ws
    Equal $LASTEXITCODE 0;Assert (-not (Test-Path $ws));Assert (($output -join ' ') -like '*NOT_RUN*')
}
Case 'D dollar share root without wildcard cannot bypass approval' '1' {
    $m=Validate @((Row a IT '\\mock\D$'));Equal $m.Rows[0].Status 'NEEDS_REVIEW';Assert $m.Rows[0].FullVolume
}
Case 'FSRM title in expected filename is rejected, never guessed' '3' {
    $cp=Join-Path $drop ([IO.Path]::GetFileName($packet.CsvPath));$rp=Join-Path $drop ([IO.Path]::GetFileName($packet.ResultPath));$oc=[IO.File]::ReadAllText($cp);$orr=[IO.File]::ReadAllText($rp)
    try{Write-SOHAtomicText $cp "Files by Owner Report`r`nOwner Name,File Size`r`nx,1 GB";$r=Read-SOHJson $rp;$r.CsvSHA256=(Get-FileHash $cp).Hash;Write-SOHJson $rp $r;$m=Invoke-SOHMerge $run $runWorkspace;Equal $m.Status 'INCOMPLETE'}finally{Write-SOHAtomicText $cp $oc;Write-SOHAtomicText $rp $orr}
}
Case 'Duplicate owner rows with matched result hash still rejected' '3' {
    $cp=Join-Path $drop ([IO.Path]::GetFileName($packet.CsvPath));$rp=Join-Path $drop ([IO.Path]::GetFileName($packet.ResultPath));$oc=[IO.File]::ReadAllText($cp);$orr=[IO.File]::ReadAllText($rp)
    try{$data=@(Import-Csv $cp);Write-SOHCsv $cp @($data+$data) $script:CollectorColumns;$r=Read-SOHJson $rp;$r.CsvSHA256=(Get-FileHash $cp).Hash;$r.FileCount*=2;$r.LogicalBytes*=2;Write-SOHJson $rp $r;$m=Invoke-SOHMerge $run $runWorkspace;Equal $m.Status 'INCOMPLETE'}finally{Write-SOHAtomicText $cp $oc;Write-SOHAtomicText $rp $orr}
}
Case 'Merge refuses cross-department edited run even with cached targets' '3' {
    $clone=ConvertFrom-Json -InputObject (ConvertTo-Json -InputObject $run -Depth 30);$clone.Validation.Rows[1].Department='Different'
    $m=Invoke-SOHMerge $clone $runWorkspace;Equal $m.Status 'INCOMPLETE';Equal $m.SuccessfulTargets 0
}

# Orchestrator transport/scheduler mocks, isolated from real WinRM and production DNS.
$script:mockActive=@{};$script:maxActive=0;$script:jobCount=0;$script:stops=0
function Get-SOHRemoteHost {param($Context,$HostName)
    $n=$HostName.Split('.')[0]
    if($n -eq 'failconnect'){throw 'WinRM access denied'}
    [pscustomobject]@{Server=$n+'.example.test';HostId='uuid-'+$n+'.example.test';Session=[pscustomobject]@{Name=$n}}
}
function Invoke-Command {param($Session,$ScriptBlock,[object[]]$ArgumentList,[switch]$AsJob)
    if(-not $AsJob){throw 'Unexpected non-job remote invocation in scheduler test.'}
    $q=$ArgumentList[0];$name=$Session.Name
    if($script:mockActive.ContainsKey($name)){throw 'Per-server concurrency exceeded.'}
    $script:mockActive[$name]=$true;$script:jobCount++;$script:maxActive=[Math]::Max($script:maxActive,$script:mockActive.Count)
    $state=switch($name){'failmissing'{'Failed'}'failfile'{'Failed'}'faildisconnect'{'Disconnected'}'failstop'{'Stopped'}'running'{'Running'}default{'Completed'}}
    if($q.Target.OriginalUNC -like '*\Gone'){$state='Failed'}
    $reason=switch($name){'failmissing'{'Path does not exist'}'failfile'{'The system cannot find the file specified'}default{'Mock transport state'}}
    $fakePacket=$null
    if($state -eq 'Completed'){
        $artifact=Get-SOHArtifactName $q.RunId $q.Target;$dir=Join-Path $q.RemoteRoot $q.RunId
        $cp=Join-Path $dir ($artifact+'.csv');$rp=Join-Path $dir ($artifact+'.result.json');$t=$q.Target
        $owner=[pscustomobject]@{SchemaVersion='SOH.Collector.2';RunId=$q.RunId;SourceID=$t.ID;PhysicalKey=$t.PhysicalKey;Department=$t.Department;OriginalUNC=$t.OriginalUNC;Server=$t.Server;LocalPath=$t.LocalPath;Owner='MOCK';OwnerSID='S-1-5-18';FileCount=3;LogicalBytes=41;AllocatedBytes=$null;Status='SUCCESS'}
        Write-SOHCsv $cp @($owner) $script:CollectorColumns
        $r=[pscustomobject]@{SchemaVersion='SOH.Result.2';RunId=$q.RunId;SourceID=$t.ID;PhysicalKey=$t.PhysicalKey;Status='SUCCESS';StartedUtc=[datetime]::UtcNow.ToString('o');EndedUtc=[datetime]::UtcNow.ToString('o');FileCount=3;LogicalBytes=41;SkippedFiles=0;SkippedDirectories=0;ErrorCount=0;Errors=@();CsvSHA256=(Get-FileHash $cp).Hash}
        Write-SOHJson $rp $r
        if($name -eq 'failhash'){$r.CsvSHA256='INVALID_HASH'}
        $fakePacket=[pscustomobject]@{Result=$r;CsvPath=$cp;ResultPath=$rp;ResultSHA256=(Get-FileHash $rp).Hash}
    }
    [pscustomobject]@{State=$state;Session=$Session;Packet=$fakePacket;ChildJobs=@([pscustomobject]@{JobStateInfo=[pscustomobject]@{Reason=$reason}})}
}
function Receive-Job {param($Job) $Job.Packet}
function Stop-Job {param($Job) $script:stops++;$Job.State='Stopped'}
function Remove-Job {param($Job,[switch]$Force) $script:mockActive.Remove($Job.Session.Name)}
function Copy-Item {param($FromSession,[string]$LiteralPath,[string]$Destination)
    if(-not $FromSession){throw 'Unexpected non-remote copy in scheduler test.'}
    if($LiteralPath -ieq $Destination){throw 'Copy onto self prohibited.'}
    [IO.File]::Copy($LiteralPath,$Destination,$false)
}
function MakeTransportRun([object[]]$Rows){
    $ws=Join-Path $testRoot ('transport-'+[guid]::NewGuid().ToString('N'));$map=Invoke-SOHValidate (Csv $Rows) $ws -Resolver $resolver
    [pscustomobject]@{Workspace=$ws;Run=(New-SOHRun $map $ws ([guid]::NewGuid().ToString('D')) -AllowTest)}
}
Case 'Ten-server regression four success six explicit failures' '2' {
    $names=@('good1','good2','good3','good4','failconnect','failmissing','failfile','faildisconnect','failstop','failhash')
    $rows=@(foreach($n in $names){Row $n Dept ('\\'+$n+'\Data')})
    $tr=MakeTransportRun $rows;$script:maxActive=0
    Invoke-SOHCollect $tr.Run $tr.Workspace (New-SOHRemoteContext) (Join-Path $Project 'src') -MaxConcurrency 2 -RemoteRoot (Join-Path $testRoot 'transport-remote')
    $m=Invoke-SOHMerge $tr.Run $tr.Workspace
    Equal $m.SuccessfulTargets 4;Equal $m.FailedTargets 6;Equal $m.Status 'INCOMPLETE';Assert ($script:maxActive -le 2);Equal $script:mockActive.Count 0
}
Case 'Per-server serial queue independent sibling artifacts and retry idempotence' '2' {
    $tr=MakeTransportRun @((Row a Dept '\\good1\Data'),(Row b Dept '\\good1.example.test\Other'),(Row c Dept '\\good2\Data'))
    $script:maxActive=0
    Invoke-SOHCollect $tr.Run $tr.Workspace (New-SOHRemoteContext) (Join-Path $Project 'src') -MaxConcurrency 4 -RemoteRoot (Join-Path $testRoot 'transport-remote')
    $m=Invoke-SOHMerge $tr.Run $tr.Workspace;Equal $m.SuccessfulTargets 3;Assert ($script:maxActive -le 2)
    $count=$script:jobCount
    Invoke-SOHCollect $tr.Run $tr.Workspace (New-SOHRemoteContext) (Join-Path $Project 'src') -MaxConcurrency 4 -RemoteRoot (Join-Path $testRoot 'transport-remote')
    Equal $script:jobCount $count
    $d=Join-Path $tr.Workspace ('runs\'+$tr.Run.RunId+'\drop');Equal @(Get-ChildItem $d -Filter '*.csv').Count 3;Equal @(Get-ChildItem $d -Filter '*.tmp').Count 0
}
Case 'A path disappearing after validation does not fail its server siblings' '2' {
    $tr=MakeTransportRun @((Row a Dept '\\good1\Gone'),(Row b Dept '\\good1\Data'))
    Invoke-SOHCollect $tr.Run $tr.Workspace (New-SOHRemoteContext) (Join-Path $Project 'src') -RemoteRoot (Join-Path $testRoot 'transport-remote')
    $m=Invoke-SOHMerge $tr.Run $tr.Workspace;Equal $m.SuccessfulTargets 1;Equal $m.FailedTargets 1;Equal $m.Status 'INCOMPLETE'
}
Case 'Scheduler timeout stops job marks target incomplete' '2' {
    $tr=MakeTransportRun @((Row a Dept '\\running\Data'));$before=$script:stops
    # Internal deadline seam: -30 offsets the fixed 30s transport grace; public CLI allows only 1..86400.
    Invoke-SOHCollect $tr.Run $tr.Workspace (New-SOHRemoteContext) (Join-Path $Project 'src') -TimeoutSeconds -30 -RemoteRoot (Join-Path $testRoot 'transport-remote')
    Assert ($script:stops -gt $before);$m=Invoke-SOHMerge $tr.Run $tr.Workspace;Equal $m.FailedTargets 1;Equal $m.Status 'INCOMPLETE'
}
Case 'Cancellation persists NOT_STARTED outcomes for all pending targets' '2' {
    $tr=MakeTransportRun @((Row a Dept '\\good1\Data'),(Row b Dept '\\good2\Data'))
    Write-SOHAtomicText (Join-Path $tr.Workspace ('runs\'+$tr.Run.RunId+'\cancel.request')) 'cancel'
    Throws {Invoke-SOHCollect $tr.Run $tr.Workspace (New-SOHRemoteContext) (Join-Path $Project 'src') -RemoteRoot (Join-Path $testRoot 'transport-remote')} '*CANCELLED*'
    $m=Invoke-SOHMerge $tr.Run $tr.Workspace;Equal $m.FailedTargets 2;Equal $m.Status 'INCOMPLETE'
}
$evidence=[pscustomobject]@{CreatedUtc=[datetime]::UtcNow.ToString('o');PowerShell=$PSVersionTable.PSVersion.ToString();Edition=$PSVersionTable.PSEdition;OS=[Environment]::OSVersion.ToString();TestRoot=$testRoot;ProductionContact=$false;Passed=@($results|Where-Object Status -eq 'PASS').Count;Failed=@($results|Where-Object Status -eq 'FAIL').Count;Tests=@($results.ToArray())}
Write-SOHJson (Join-Path $Project ('reports\'+$EvidenceName+'.json')) $evidence
Write-SOHCsv (Join-Path $Project ('reports\'+$EvidenceName+'.csv')) @($results.ToArray()) @('Name','Gate','Status','Seconds','Detail')
Write-Host "PASS=$($evidence.Passed) FAIL=$($evidence.Failed); $testRoot"
if($evidence.Failed){exit 1}
