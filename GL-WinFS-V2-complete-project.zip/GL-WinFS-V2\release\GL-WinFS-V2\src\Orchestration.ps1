function Get-SOHPhysicalTargets($Map) {
    return @($Map.Rows | Where-Object { $_.Status -eq 'VALID' } | Group-Object PhysicalKey | ForEach-Object { $_.Group[0] })
}
function Assert-SOHCollectMap($Map, [switch]$ApproveFullVolume, [switch]$AllowTest) {
    if ($Map.SchemaVersion -ne 'SOH.Validation.2' -or $Map.Offline -or ($Map.TestMode -and -not $AllowTest)) { throw 'Only online validated production targets may be collected.' }
    if (@($Map.Rows).Count -eq 0 -or @($Map.Rows | Where-Object Status -ne 'VALID').Count) { throw 'All input rows must be VALID; resolve every review/invalid row before production collection.' }
    foreach ($r in $Map.Rows) {
        if (-not $r.PhysicalKey -or $r.Department -ieq 'PENDING_CONFIRMATION' -or $r.RequiresApproval) { throw 'Unapproved/empty target.' }
        if ($r.FullVolume -and (-not $r.FullVolumeApproved -or -not $ApproveFullVolume)) { throw 'Full volume requires approval at validation and collection.' }
    }
    # Recompute conflicts even when a saved validation file was edited.
    Set-SOHConflicts @($Map.Rows)
    if (@($Map.Rows | Where-Object Status -ne 'VALID').Count) { throw 'Conflicting physical paths block collection.' }
}
function New-SOHRun($Map,[string]$Workspace,[string]$RunId,[switch]$ApproveFullVolume,[switch]$AllowTest) {
    Assert-SOHRunId $RunId
    Assert-SOHCollectMap $Map -ApproveFullVolume:$ApproveFullVolume -AllowTest:$AllowTest
    $runDir=Join-Path (Join-Path $Workspace 'runs') $RunId
    $runFile=Join-Path $runDir 'run.json'
    if (Test-Path -LiteralPath $runFile) {
        $run=Read-SOHJson $runFile
        if ($run.SourceSHA256 -ne $Map.SourceSHA256 -or (ConvertTo-Json -InputObject $run.Validation.Rows -Depth 20 -Compress) -cne (ConvertTo-Json -InputObject $Map.Rows -Depth 20 -Compress)) { throw 'RunId already bound to a different validation snapshot.' }
        return $run
    }
    [void][IO.Directory]::CreateDirectory((Join-Path $runDir 'drop'))
    $run=[pscustomobject][ordered]@{SchemaVersion='SOH.Run.2';RunId=$RunId;Version=$script:SOHVersion;Identity=Get-SOHIdentity;CreatedUtc=[datetime]::UtcNow.ToString('o');SourceSHA256=$Map.SourceSHA256;Validation=$Map;FullVolumeApproved=[bool]$ApproveFullVolume;Targets=@(Get-SOHPhysicalTargets $Map);Measurement='Logical namespace bytes (hard links counted per directory entry).';ProductionAcceptance='PENDING_CUSTOMER_GATE_5'}
    Write-SOHJson $runFile $run
    Write-SOHAtomicText ($runFile + '.sha256') (Get-FileHash -LiteralPath $runFile).Hash
    return $run
}
function Read-SOHRun([string]$Workspace,[string]$RunId) {
    Assert-SOHRunId $RunId
    $file=Join-Path (Join-Path (Join-Path $Workspace 'runs') $RunId) 'run.json'
    if ((Get-FileHash -LiteralPath $file).Hash -ne ([IO.File]::ReadAllText($file+'.sha256')).Trim()) { throw 'Run snapshot checksum mismatch.' }
    $run=Read-SOHJson $file
    if ($run.SchemaVersion -ne 'SOH.Run.2' -or $run.RunId -ne $RunId) { throw 'Invalid run snapshot.' }
    return $run
}
function Write-SOHFailure($Run,$Target,[string]$Drop,[string]$Message,[string]$Code='COLLECT_FAILED') {
    $name=Get-SOHArtifactName $Run.RunId $Target
    $r=[pscustomobject]@{SchemaVersion='SOH.Result.2';RunId=$Run.RunId;SourceID=$Target.ID;PhysicalKey=$Target.PhysicalKey;Status='FAILED';StartedUtc=[datetime]::UtcNow.ToString('o');EndedUtc=[datetime]::UtcNow.ToString('o');FileCount=0;LogicalBytes=0;AllocatedBytes=$null;SkippedFiles=0;SkippedDirectories=0;ErrorCount=1;EntriesObserved=0;CsvSHA256='';Errors=@([pscustomobject]@{Path=$Target.LocalPath;Code=$Code;Message=$Message})}
    Write-SOHJson (Join-Path $Drop ($name+'.result.json')) $r
}
function Copy-SOHVerifiedRemote($Session,[string]$RemotePath,[string]$Destination,[string]$Hash) {
    $temp=$Destination+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try {
        Copy-Item -FromSession $Session -LiteralPath $RemotePath -Destination $temp -ErrorAction Stop
        if ((Get-FileHash -LiteralPath $temp).Hash -ne $Hash) { throw 'Remote transfer SHA256 mismatch.' }
        if ([IO.File]::Exists($Destination)) { [IO.File]::Replace($temp,$Destination,[System.Management.Automation.Language.NullString]::Value) } else { [IO.File]::Move($temp,$Destination) }
    } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
}
function Invoke-SOHCollect {
    param($Run,[string]$Workspace,$Context,[string]$SourceRoot,[int]$MaxConcurrency=1,[int]$TimeoutSeconds=3600,[int]$MaxEntriesPerSecond=200,[string]$RemoteRoot='C:\ProgramData\ChargebackOneV2',[int]$MaxDiskQueueLength=2)
    $runDir=Join-Path (Join-Path $Workspace 'runs') $Run.RunId; $drop=Join-Path $runDir 'drop'
    $body="param(`$Request)`r`n" + [IO.File]::ReadAllText((Join-Path $SourceRoot 'Common.ps1')) + "`r`n" + [IO.File]::ReadAllText((Join-Path $SourceRoot 'Validation.ps1')) + "`r`n" + [IO.File]::ReadAllText((Join-Path $SourceRoot 'Collector.ps1')) + "`r`nInvoke-SOHRemoteCollect `$Request"
    $block=[scriptblock]::Create($body)
    $pending=New-Object Collections.ArrayList
    foreach ($t in $Run.Targets) { [void]$pending.Add($t) }
    $active=New-Object Collections.ArrayList
    $cancelled=$false
    try {
        while ($pending.Count -or $active.Count) {
            if (Test-Path -LiteralPath (Join-Path $runDir 'cancel.request')) { $cancelled=$true; throw 'CANCELLED: local cancel.request exists.' }
            for ($i=0; $i -lt $pending.Count -and $active.Count -lt $MaxConcurrency; $i++) {
                $t=$pending[$i]
                if (@($active | Where-Object { $_.Target.HostId -eq $t.HostId }).Count) { continue }
                $pending.RemoveAt($i); $i--
                $name=Get-SOHArtifactName $Run.RunId $t
                $resultPath=Join-Path $drop ($name+'.result.json'); $csvPath=Join-Path $drop ($name+'.csv')
                if (Test-Path -LiteralPath $resultPath) {
                    $old=Read-SOHJson $resultPath
                    if ($old.Status -eq 'SUCCESS' -and $old.RunId -eq $Run.RunId -and (Test-Path -LiteralPath $csvPath) -and $old.CsvSHA256 -eq (Get-FileHash -LiteralPath $csvPath).Hash) { continue }
                }
                # A durable marker survives host interruption. Merge reports this target as failed until committed.
                Write-SOHFailure $Run $t $drop 'Collection started; no verified result committed yet.' 'RUNNING_OR_INTERRUPTED'
                try {
                    $p=ConvertTo-SOHParsedPath $t.OriginalUNC
                    $h=Get-SOHRemoteHost $Context $p.HostName
                    if ($h.HostId -ine $t.HostId) { throw 'Host UUID changed since validation.' }
                    $request=[pscustomobject]@{RunId=$Run.RunId;Target=$t;RemoteRoot=$RemoteRoot;TimeoutSeconds=$TimeoutSeconds;MaxEntriesPerSecond=$MaxEntriesPerSecond;MaxDiskQueueLength=$MaxDiskQueueLength}
                    $job=Invoke-Command -Session $h.Session -ScriptBlock $block -ArgumentList $request -AsJob -ErrorAction Stop
                    [void]$active.Add([pscustomobject]@{Target=$t;Job=$job;Session=$h.Session;Started=[datetime]::UtcNow})
                } catch { Write-SOHFailure $Run $t $drop $_.Exception.Message }
            }
            foreach ($a in @($active.ToArray())) {
                $elapsed=([datetime]::UtcNow-$a.Started).TotalSeconds
                Write-Progress -Id ($active.IndexOf($a)+1) -Activity ('Collect '+$a.Target.Server+' / '+$a.Target.ID) -Status ("Elapsed {0:N0}s; remote entry rate cap {1}/s; total size unknown" -f $elapsed,$MaxEntriesPerSecond)
                if ($a.Job.State -in @('Completed','Failed','Stopped','Disconnected') -or $elapsed -ge ($TimeoutSeconds+30)) {
                    try {
                        if ($elapsed -ge ($TimeoutSeconds+30)) { Stop-Job $a.Job -ErrorAction SilentlyContinue; throw 'TIMEOUT: remote invocation exceeded deadline plus 30s transport allowance.' }
                        if ($a.Job.State -ne 'Completed') { throw ('REMOTE_'+$a.Job.State+': '+$a.Job.ChildJobs[0].JobStateInfo.Reason) }
                        $packet=Receive-Job $a.Job -ErrorAction Stop
                        if (@($packet).Count -ne 1 -or $packet.Result.RunId -ne $Run.RunId -or $packet.Result.PhysicalKey -ne $a.Target.PhysicalKey) { throw 'Invalid remote result envelope.' }
                        $name=Get-SOHArtifactName $Run.RunId $a.Target
                        $expectedDir=Join-Path $RemoteRoot $Run.RunId
                        if ($packet.CsvPath -ine (Join-Path $expectedDir ($name+'.csv')) -or $packet.ResultPath -ine (Join-Path $expectedDir ($name+'.result.json'))) { throw 'Remote artifact outside exact expected run path.' }
                        Copy-SOHVerifiedRemote $a.Session $packet.CsvPath (Join-Path $drop ($name+'.csv')) $packet.Result.CsvSHA256
                        # Commit result last, so an interrupted transfer cannot certify a CSV.
                        Copy-SOHVerifiedRemote $a.Session $packet.ResultPath (Join-Path $drop ($name+'.result.json')) $packet.ResultSHA256
                    } catch { Write-SOHFailure $Run $a.Target $drop $_.Exception.Message }
                    finally { Remove-Job $a.Job -Force -ErrorAction SilentlyContinue; $active.Remove($a) }
                }
            }
            if ($active.Count) { Start-Sleep -Milliseconds 200 }
        }
    } finally {
        foreach ($a in @($active.ToArray())) {
            Stop-Job $a.Job -ErrorAction SilentlyContinue; Remove-Job $a.Job -Force -ErrorAction SilentlyContinue
            Write-SOHFailure $Run $a.Target $drop 'Collection cancelled/interrupted; remote stop requested, verify endpoint process state before retry.' 'CANCELLED_OR_INTERRUPTED'
        }
        foreach ($t in @($pending.ToArray())) { Write-SOHFailure $Run $t $drop 'Collection stopped before target started.' 'NOT_STARTED' }
        Write-Progress -Activity 'Collect' -Completed
    }
}
