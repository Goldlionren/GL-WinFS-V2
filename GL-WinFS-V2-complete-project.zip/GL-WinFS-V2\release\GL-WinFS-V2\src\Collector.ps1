function Wait-SOHDiskPressure($Watch,[int]$TimeoutSeconds,[string]$Drive,[int]$MaxDiskQueueLength,[scriptblock]$PressureProbe) {
    if($MaxDiskQueueLength -le 0){return}
    do {
        if($Watch.Elapsed.TotalSeconds -ge $TimeoutSeconds){throw 'TIMEOUT: waiting for disk I/O pressure to fall.'}
        if($PressureProbe){$queue=& $PressureProbe $Drive}
        else{
            $counter=Get-CimInstance -ClassName Win32_PerfFormattedData_PerfDisk_LogicalDisk -Filter ("Name='"+$Drive+"'") -ErrorAction Stop
            if(-not $counter){throw 'Disk queue counter unavailable; cannot enforce I/O pressure limit.'}
            $queue=$counter.CurrentDiskQueueLength
        }
        if($null -eq $queue -or [double]$queue -lt 0){throw 'Invalid disk queue counter.'}
        if([double]$queue -le $MaxDiskQueueLength){return}
        Start-Sleep -Milliseconds 200
    }while($true)
}
function Invoke-SOHNtfsWalk {
    param([string]$LocalPath,[int]$TimeoutSeconds=3600,[int]$MaxEntriesPerSecond=200,[int]$MaxDiskQueueLength=0,[scriptblock]$ListDirectory,[scriptblock]$ReadOwner,[scriptblock]$PressureProbe)
    $started=[datetime]::UtcNow; $watch=[Diagnostics.Stopwatch]::StartNew()
    $owners=@{}; $errors=New-Object 'Collections.Generic.List[object]'
    $skippedFiles=0L; $skippedDirs=0L; $seen=0L; $files=0L; $bytes=0L; $status='SUCCESS'
    try {
        $LocalPath=Assert-SOHLocalPath $LocalPath
        Assert-SOHNoReparse $LocalPath
        if (-not (Test-Path -LiteralPath $LocalPath -PathType Container -ErrorAction Stop)) { throw 'Target is not an existing directory.' }
        Wait-SOHDiskPressure $watch $TimeoutSeconds $LocalPath.Substring(0,2) $MaxDiskQueueLength $PressureProbe
        $nextPressureProbe=$watch.Elapsed.TotalSeconds+1
        $nextEntryDue=$watch.Elapsed.TotalMilliseconds
        $stack=New-Object 'Collections.Generic.Stack[string]'; $stack.Push($LocalPath)
        while ($stack.Count) {
            if ($watch.Elapsed.TotalSeconds -ge $TimeoutSeconds) { throw 'TIMEOUT: metadata walk deadline reached.' }
            $dir=$stack.Pop()
            try {
                Assert-SOHNoReparse $dir
                if ($ListDirectory) { $enumerator=(@(& $ListDirectory $dir)).GetEnumerator() }
                else { $enumerator=(New-Object IO.DirectoryInfo($dir)).EnumerateFileSystemInfos().GetEnumerator() }
                try {
                    while ($enumerator.MoveNext()) {
                        if ($watch.Elapsed.TotalSeconds -ge $TimeoutSeconds) { throw 'TIMEOUT: metadata walk deadline reached.' }
                        if($watch.Elapsed.TotalSeconds -ge $nextPressureProbe){
                            Wait-SOHDiskPressure $watch $TimeoutSeconds $LocalPath.Substring(0,2) $MaxDiskQueueLength $PressureProbe
                            $nextPressureProbe=$watch.Elapsed.TotalSeconds+1
                        }
                        $f=$enumerator.Current; $seen++
                        if ($MaxEntriesPerSecond -gt 0) {
                            $delay=$nextEntryDue - $watch.Elapsed.TotalMilliseconds
                            if ($delay -gt 0) { Start-Sleep -Milliseconds ([int][Math]::Min($delay,1000)) }
                            # Do not accumulate burst credit while waiting on I/O or backpressure.
                            $nextEntryDue=[Math]::Max($watch.Elapsed.TotalMilliseconds,$nextEntryDue)+(1000.0/$MaxEntriesPerSecond)
                        }
                        try {
                            $isDir=($f.Attributes -band [IO.FileAttributes]::Directory) -ne 0
                            if (($f.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                                if($isDir){$skippedDirs++}else{$skippedFiles++}
                                $errors.Add([pscustomobject]@{Path=$f.FullName;Code='REPARSE_SKIPPED';Message='No reparse points followed; excluded subtree size/file count unknown.'}); continue
                            }
                            if ($isDir) { $stack.Push($f.FullName); continue }
                            # Length and owner metadata only. Never open file content.
                            $size=[long]$f.Length; $owner='UNKNOWN'; $sid=''
                            try {
                                if ($ReadOwner) { $security=& $ReadOwner $f; $owner=$security.Owner; $sid=$security.SID }
                                else {
                                    $acl=Get-Acl -LiteralPath $f.FullName -ErrorAction Stop
                                    $sid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
                                    $owner=[string]$acl.Owner
                                }
                            } catch { $errors.Add([pscustomobject]@{Path=$f.FullName;Code='ACL_UNREADABLE';Message=$_.Exception.Message}) }
                            $key=$sid + '|' + $owner
                            if (-not $owners.ContainsKey($key)) { $owners[$key]=[pscustomobject]@{Owner=$owner;OwnerSID=$sid;FileCount=0L;LogicalBytes=0L} }
                            $owners[$key].FileCount++; $owners[$key].LogicalBytes += $size; $files++; $bytes += $size
                        } catch {
                            $skippedFiles++; $errors.Add([pscustomobject]@{Path=$f.FullName;Code='METADATA_UNREADABLE';Message=$_.Exception.Message})
                        }
                    }
                } finally { if ($enumerator -is [IDisposable]) { $enumerator.Dispose() } }
            } catch {
                $skippedDirs++; $errors.Add([pscustomobject]@{Path=$dir;Code='DIRECTORY_UNREADABLE';Message=$_.Exception.Message})
                if ($_.Exception.Message -like '*TIMEOUT:*') { throw }
            }
        }
    } catch {
        $status='FAILED'
        $errors.Add([pscustomobject]@{Path=$LocalPath;Code='WALK_ABORTED';Message=$_.Exception.Message})
    } finally { $watch.Stop() }
    if ($status -eq 'FAILED' -and $seen -gt 0) { $status='PARTIAL' }
    if ($status -eq 'SUCCESS' -and $errors.Count -gt 0) { $status='PARTIAL' }
    [pscustomobject]@{ Status=$status;StartedUtc=$started.ToString('o');EndedUtc=[datetime]::UtcNow.ToString('o');ElapsedSeconds=$watch.Elapsed.TotalSeconds;FileCount=$files;LogicalBytes=$bytes;AllocatedBytes=$null;SkippedFiles=$skippedFiles;SkippedDirectories=$skippedDirs;ErrorCount=$errors.Count;EntriesObserved=$seen;Owners=@($owners.Values | Sort-Object OwnerSID,Owner);Errors=@($errors.ToArray());Measurement='Logical namespace bytes; each hard-link directory entry counted; no allocated/unique-physical-byte claim.' }
}
function Invoke-SOHRemoteCollect($Request) {
    $ErrorActionPreference='Stop'
    $t=$Request.Target
    Assert-SOHRunId $Request.RunId
    $remoteRoot=Assert-SOHLocalPath $Request.RemoteRoot
    # Keep report writes outside the authorized scan tree.
    if ($remoteRoot -ieq $t.LocalPath -or (Test-SOHAncestor $t.LocalPath $remoteRoot)) { throw 'Remote report directory is inside scan tree. Choose a disjoint -RemoteRoot.' }
    $parsed=ConvertTo-SOHParsedPath $t.OriginalUNC
    $cs=Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop
    if ($cs.UUID -ine $t.HostId) { throw 'Remote host UUID changed since validation.' }
    $shares=@(Get-SmbShare -Name $parsed.Share -ErrorAction Stop | Where-Object Name -ieq $parsed.Share)
    if ($shares.Count -ne 1 -or -not $shares[0].Path) { throw 'Share is missing or Path is empty on collection recheck.' }
    $now=Assert-SOHLocalPath ([string]$shares[0].Path)
    if ($parsed.Suffix) { $now=Assert-SOHLocalPath ([IO.Path]::Combine($now,$parsed.Suffix)) }
    if ($now -ine $t.LocalPath) { throw 'Share mapping changed since validation. Revalidate with a new RunId.' }
    $drive=$now.Substring(0,2)
    $volume=Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='"+$drive+"'") -ErrorAction Stop
    if (-not $volume -or $volume.FileSystem -ine 'NTFS') { throw 'Collector requires a confirmed NTFS local volume.' }
    # Existing ancestors of our output path may not be junctions either.
    $ancestor=$remoteRoot
    while (-not (Test-Path -LiteralPath $ancestor)) { $ancestor=Split-Path -Parent $ancestor }
    Assert-SOHNoReparse $ancestor
    $outDir=Join-Path $remoteRoot $Request.RunId
    [void][IO.Directory]::CreateDirectory($outDir)
    Assert-SOHNoReparse $outDir
    $name=Get-SOHArtifactName $Request.RunId $t
    $csvPath=Join-Path $outDir ($name + '.csv'); $resultPath=Join-Path $outDir ($name + '.result.json')
    if (Test-Path -LiteralPath $resultPath) {
        $old=Read-SOHJson $resultPath
        if ($old.RunId -eq $Request.RunId -and $old.PhysicalKey -eq $t.PhysicalKey -and $old.Status -eq 'SUCCESS' -and $old.CsvSHA256 -eq (Get-FileHash -LiteralPath $csvPath).Hash) {
            return [pscustomobject]@{Result=$old;CsvPath=$csvPath;ResultPath=$resultPath;ResultSHA256=(Get-FileHash -LiteralPath $resultPath).Hash}
        }
    }
    $queueLimit=0
    if($Request.PSObject.Properties['MaxDiskQueueLength']){$queueLimit=$Request.MaxDiskQueueLength}
    $walk=Invoke-SOHNtfsWalk -LocalPath $t.LocalPath -TimeoutSeconds $Request.TimeoutSeconds -MaxEntriesPerSecond $Request.MaxEntriesPerSecond -MaxDiskQueueLength $queueLimit
    $rows=@(foreach ($o in $walk.Owners) {
        [pscustomobject][ordered]@{SchemaVersion='SOH.Collector.2';RunId=$Request.RunId;SourceID=$t.ID;PhysicalKey=$t.PhysicalKey;Department=$t.Department;OriginalUNC=$t.OriginalUNC;Server=$t.Server;LocalPath=$t.LocalPath;Owner=$o.Owner;OwnerSID=$o.OwnerSID;FileCount=$o.FileCount;LogicalBytes=$o.LogicalBytes;AllocatedBytes=$null;Status=$walk.Status}
    })
    if (-not $rows.Count) {
        $rows=@([pscustomobject][ordered]@{SchemaVersion='SOH.Collector.2';RunId=$Request.RunId;SourceID=$t.ID;PhysicalKey=$t.PhysicalKey;Department=$t.Department;OriginalUNC=$t.OriginalUNC;Server=$t.Server;LocalPath=$t.LocalPath;Owner='';OwnerSID='';FileCount=0;LogicalBytes=0;AllocatedBytes=$null;Status=$walk.Status})
    }
    Write-SOHCsv $csvPath $rows $script:CollectorColumns
    $result=$walk | Select-Object * -ExcludeProperty Owners
    $result | Add-Member NoteProperty RunId $Request.RunId
    $result | Add-Member NoteProperty SourceID $t.ID
    $result | Add-Member NoteProperty PhysicalKey $t.PhysicalKey
    $result | Add-Member NoteProperty CsvSHA256 (Get-FileHash -LiteralPath $csvPath).Hash
    $result | Add-Member NoteProperty SchemaVersion 'SOH.Result.2'
    Write-SOHJson $resultPath $result
    [pscustomobject]@{Result=$result;CsvPath=$csvPath;ResultPath=$resultPath;ResultSHA256=(Get-FileHash -LiteralPath $resultPath).Hash}
}
