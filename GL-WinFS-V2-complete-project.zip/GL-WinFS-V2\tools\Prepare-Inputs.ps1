# Development-only deterministic import; does not contact listed hosts.
# User confirmed Business Owner -> Department on 2026-11-12.
param([string]$Source='D:\AI\SOH\SOH Reporting sources.csv',[string]$Project=(Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
$inputDir=Join-Path $Project 'input'
$rows=@(Import-Csv -LiteralPath $Source -Encoding UTF8)
if ((@($rows[0].PSObject.Properties.Name)-join ',') -cne 'Host,Business Owner,Host Path,Tier'){throw 'Unexpected customer source format.'}
[IO.File]::WriteAllBytes((Join-Path $inputDir 'SOH Reporting sources.original.csv'),[IO.File]::ReadAllBytes($Source))
$n=0
$converted=@(foreach($r in $rows){$n++;[pscustomobject][ordered]@{ID=('SOH-{0:D3}' -f $n);Department=$r.'Business Owner';AbsolutePath=$r.'Host Path'}})
$converted | Export-Csv -LiteralPath (Join-Path $inputDir 'customer-targets.csv') -NoTypeInformation -Encoding UTF8
$converted | Select-Object ID,@{n='Department';e={'PENDING_CONFIRMATION'}},AbsolutePath | Export-Csv -LiteralPath (Join-Path $inputDir 'customer-targets.template.csv') -NoTypeInformation -Encoding UTF8
$rows.'Host Path' | Set-Content -LiteralPath (Join-Path $inputDir 'customer-paths-original.txt') -Encoding UTF8
$line=0
$evidence=@(foreach($r in $rows){$line++;[pscustomobject]@{ID=('SOH-{0:D3}' -f $line);OriginalHost=$r.Host;OriginalBusinessOwner=$r.'Business Owner';OriginalHostPath=$r.'Host Path';OriginalTier=$r.Tier;Mapping='User approved Business Owner -> Department; Host Path -> AbsolutePath; no trim/correction';SourceSHA256=(Get-FileHash -LiteralPath $Source).Hash}})
$evidence | Export-Csv -LiteralPath (Join-Path $inputDir 'source-mapping.csv') -NoTypeInformation -Encoding UTF8
$suggestions=@(
    [pscustomobject]@{ID='SOH-001';Field='AbsolutePath';Original='\\sohfs3\ BDM';Candidate='\\sohfs3\BDM';Reason='Leading space in share component';Decision='PENDING_CUSTOMER'},
    [pscustomobject]@{ID='SOH-002';Field='AbsolutePath';Original='\\sohf3\BSS Office';Candidate='\\sohfs3\BSS Office';Reason='Host column and UNC disagree';Decision='PENDING_CUSTOMER'},
    [pscustomobject]@{ID='SOH-009';Field='AbsolutePath';Original='\\sohfs3\ Communications';Candidate='\\sohfs3\Communications';Reason='Leading space in share component';Decision='PENDING_CUSTOMER'},
    [pscustomobject]@{ID='SOH-012';Field='Department';Original='Digital ';Candidate='Digital';Reason='Trailing space';Decision='PENDING_CUSTOMER'},
    [pscustomobject]@{ID='SOH-043';Field='AbsolutePath';Original='\\sohfs1\D$\*';Candidate='';Reason='Full D: approval and overlap with EmailArchives required';Decision='PENDING_CUSTOMER'},
    [pscustomobject]@{ID='SOH-050';Field='AbsolutePath';Original='\\sohfs4\D$\*';Candidate='';Reason='Full D: approval and actual share overlap required';Decision='PENDING_CUSTOMER'},
    [pscustomobject]@{ID='SOH-054';Field='AbsolutePath';Original='\\sohfs3\Toursim Sales';Candidate='\\sohfs3\Tourism Sales';Reason='Possible spelling error; verify actual SMB name';Decision='PENDING_CUSTOMER'}
)
$suggestions | Export-Csv -LiteralPath (Join-Path $inputDir 'suggested-corrections.csv') -NoTypeInformation -Encoding UTF8
Write-Output "Imported $($rows.Count) exact source paths; no network access."
