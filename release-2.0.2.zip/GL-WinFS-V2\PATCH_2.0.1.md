# 2.0.1 采集进度与计数器诊断更新

此版本解决“看不到实际文件进度”的诊断缺陷。**尚未确认客户当前长时间等待的根因，也未声称修复了客户环境中的卡顿。** 未连接或操作客户服务器。

## 依据与改动

客户提供的同一 WinRM 宿主进程三次采样：20 秒内 OtherOperationCount 增加 7,453，CPUSeconds 和 ReadOperationCount 不变。只能说明该进程有活动，不能证明文件计数增长。磁盘 D: 计数器在完整实例列表中存在，采样队列 0；先前 WQL Name 过滤查询没有输出。两种现象均不构成采集正常/卡死的充分证据。

新版本在每个目标的远端 RunId 报告目录生成 `.progress.json`，经 PowerShell Progress 流向主控传递并保存在本地 drop。包含 RunId、SourceID、PhysicalKey、远端 PID、已完成 FileCount、LogicalBytes、ObservedEntries、最后完成文件的 UTC 时间、最后观察到的路径/阶段、错误数、磁盘队列和进度更新时间。正常步进通常每 5 秒发布；关键边界可立即发布。总文件数未知，不显示虚假百分比。

阶段包括 STARTING、VALIDATING_ROOT、QUERY_DISK_PRESSURE、WAITING_DISK_PRESSURE、ENUMERATING_DIRECTORY、READING_METADATA、WALK_FINISHED、WRITING_RESULTS、RESULTS_COMMITTED。只有写完正式结果才报告最终状态；心跳本身不是正式完整性证明。

性能计数器读取现在枚举该类的实例，再按 Name 精确匹配盘符。每次查询设置 OperationTimeoutSec，最高 15 秒，并受剩余扫描预算约束。缺失/重复实例、查询异常均明确失败，绝不隐式关闭压力限制。不安装或修复服务器计数器，不修改磁盘/服务配置。

心跳由实际采集线程发布，不是一个持续更新时间的独立定时器。若线程卡在一个文件系统/ACL/CIM 调用内，更新时间会变旧。LastObservedPath 是最近发布的观察点，不保证等于随后阻塞的精确文件。CIM 超时参数也不是对任意底层驱动阻塞的硬实时终止保证。

## 部署与当前运行

2.0.0 保留在原目录。不要在当前作业仍活动时启动另一份采集，不要只覆盖脚本后假定已启动的远端作业会更新。

将新 ZIP 单独解压到例如 `C:\Temp\SOH-V201`，得到 `C:\Temp\SOH-V201\GL-WinFS-V2`。先校验新包。客户输入仍使用之前已修正、已审批的 `C:\SOHReporting\workspace\input\customer-targets.corrected.csv`，不要换回包内原始样本。

```powershell
& 'C:\Temp\SOH-V201\GL-WinFS-V2\Verify-SOHPackage.ps1'
```

仅在旧运行已完成，或由操作员明确停止并核实旧远端执行已退出后，启动新的 RunId。若选择保留当前作业，可等它完成后再升级。不能使用新代码给旧作业补发历史心跳。

```powershell
$runId=[guid]::NewGuid().ToString('D'); Write-Host "RunId: $runId"; & 'C:\Temp\SOH-V201\GL-WinFS-V2\Start-SOHReport.ps1' -Stage All -Execute -ApproveFullVolume -ResolveAD -CsvPath 'C:\SOHReporting\workspace\input\customer-targets.corrected.csv' -Workspace 'C:\SOHReporting\workspace' -RunId $runId -MaxConcurrency 1 -MaxEntriesPerSecond 200 -MaxDiskQueueLength 2 -TimeoutSeconds 86400
```

输入新的完整 COLLECT 确认字符串。在另一个同账号窗口，用本次真实 RunId 查看本地进度（只读，不连服务器）：

```powershell
& 'C:\Temp\SOH-V201\GL-WinFS-V2\Get-SOHRunStatus.ps1' -Workspace 'C:\SOHReporting\workspace' -RunId '<本次UUID>' -TargetID 'SOH-001' | Format-List
```

若主窗口或 WinRM 进度流不更新，可额外显式启用只读远端状态查询：

```powershell
& 'C:\Temp\SOH-V201\GL-WinFS-V2\Get-SOHRunStatus.ps1' -Workspace 'C:\SOHReporting\workspace' -RunId '<本次UUID>' -TargetID 'SOH-001' -CheckRemote | Format-List
```

判断：文件数增长才是文件扫描推进的直接证据；更新时间增长而文件数不变时结合 Phase 和 DiskQueue 判断。更新时间持续变旧表示未收到新的采集线程状态，需看最后阶段及该 PID。缺失心跳显示 UNKNOWN/NO_HEARTBEAT，不伪称为运行中。最终仍以 result/CSV 的哈希、schema 和 Merge manifest 完整性为准。

## 验证边界

新增测试覆盖真实 NTFS 数量/字节心跳、压力等待、阻塞时不制造虚假心跳、CIM 查询超时/缺失实例、PS 5.1 Job 的进度流隔离与清空、旧运行只读状态查询。完整结果见 reports/test-results。真实客户 WinRM 进度流传输、计数器行为和原作业等待原因仍需客户验证。新版本不是对当前故障已恢复的声明。
