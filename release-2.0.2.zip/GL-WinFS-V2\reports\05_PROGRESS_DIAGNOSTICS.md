# 2.0.1 — progress diagnostics evidence

Change prompted by customer-supplied output: one remote wsmprovhost PID showed OtherOperationCount 3,326,810 -> 3,330,562 -> 3,334,263 in 20 seconds, with CPUSeconds 3.88 and ReadOperationCount 260 unchanged. D: appeared in unfiltered logical disk counters with queue 0. Current-run remote directory existed without completed artifacts. These observations do not establish useful scan progress or a root cause.

Implemented same-worker progress snapshots and a separate diagnostic stream, exact instance matching after counter enumeration, bounded CIM query parameters, and read-only run-status inspection. No changes to source-data authorization, Department attribution, report schemas, scan limits, source ACLs or server services. Original 2.0.0 remains unchanged.

Patch iteration 01: 63 PASS / 4 FAIL. The new status CLI was initially invoked inside the harness process and its module import displaced transport mocks; scheduler assertions failed. This was a test-isolation defect. Status CLI now runs in its own child process. Test destinations involved synthetic names only; no SOH hosts contacted. Patch iteration 02: 67 PASS / 0 FAIL. Final current code evidence is test-results.json/csv.

Local tests include a real Windows PowerShell 5.1 background job emitting the same progress payload, drain/parse/identity checks, final output envelope isolation, real NTFS counts, stale progress during a simulated blocked ACL call, and mocked provider timeout. This is not a real WinRM progress delivery test. Customer verification remains pending.

No production run was cancelled, killed, restarted or modified by the development agent. Existing remote jobs cannot be changed by replacing local scripts. Review PATCH_2.0.1.md before switching versions.

Final Windows PowerShell 5.1 regression: 67 PASS / 0 FAIL. First packaging attempt stopped before producing a release because the independent project copy omitted the extensionless LICENSE file. Restored the original MIT LICENSE byte-for-byte from the unchanged 2.0.0 project; packaging was rerun. Final archive checks and extraction smoke evidence are recorded in release-smoke.json and complete-project-smoke.json alongside this report in the development project.
