# Customer environment acceptance — Gate 5 PENDING

本文件由客户在复制交付目录之后填写。Codex 开发机没有客户环境连接，也未执行任何生产验证。

| 项目 | 初始状态 | 客户证据/结果 |
| --- | --- | --- |
| 授权人与变更/灰度窗口 | PENDING | |
| SOHVHPEREPORT01 OS / PSVersionTable | PENDING | |
| SOH\svc_HPEreport 实际身份与委派权限 | PENDING | |
| 原包 SHA256 校验 | PENDING | |
| 所有部门及 7 个已知审批/纠错事项 | PENDING | |
| 代表服务器 WinRM、Get-SmbShare.Path、UUID/DNS | PENDING | |
| NTFS 卷类型与磁盘队列计数器权限 | PENDING | |
| 一条已批准小目录 CSV 的审批和 SHA256 | PENDING | |
| 单目标 Validate 结果及实际 LocalPath | PENDING | |
| 单目标 Collect RunId 与确认记录 | PENDING | |
| 文件数、逻辑字节、Owner 与人工只读基准比对 | PENDING | |
| ACL 拒绝/受保护目录的 PARTIAL 是否符合预期 | PENDING | |
| 同服务器逐路径隔离、服务短名/FQDN 去重 | PENDING | |
| 全盘与共享目录重叠的业务决定（不灰度全盘） | PENDING | |
| 速率、磁盘队列、运行时间、CPU/内存/业务影响 | PENDING | |
| 源文件、ACL、FSRM、服务、任务配置未改动 | PENDING | |
| WinRM 断线/取消后远端进程结束确认（测试目录） | PENDING | |
| Manifest 哈希与所有完整性统计 | PENDING | |
| 可选 AD enrichment | PENDING / OPTIONAL | |
| 升级/回滚演练、归档保留策略 | PENDING | |
| 批准扩容范围与正式 Chargeback 口径 | PENDING | |

请返回脱敏后的 validation-summary、validation.csv、run-manifest、errors.csv、命令、退出码与时间记录。不要提供密码。若需要返回包含 Owner 的明细，先按客户数据政策批准/脱敏。任何 FAILED/PARTIAL/冲突应保留 INCOMPLETE，不能人工改成 COMPLETE。
