﻿# 2.0.2 — 2026-11-12

* Add independent missing-heartbeat and no-counter-progress deadlines, bounded asynchronous stop requests, durable host quarantine, and ten-second console/file progress. Preserve unverified counts as diagnostics and continue other hosts. See PATCH_2.0.2.md for scope and deployment.

# 2.0.1 — 2026-11-12

* Add actual collector progress counts, stages, timestamps, PID, disk queue and stale-state visibility through atomic JSON and PowerShell progress records.
* Enumerate logical-disk performance instances and match the requested drive exactly; bound CIM operation timeout and preserve fail-closed pressure behavior.
* Add read-only Get-SOHRunStatus.ps1, including explicit optional remote state checks.
* Preserve 2.0.0 data contracts and authorization. No confirmed root cause or production recovery claim; see PATCH_2.0.1.md.

# 2.0.0 — 2026-11-12

* Independent PowerShell 5.1 project; upstream baseline and MIT notice retained.
* Import/Validate, NTFS Collect, Department Merge, All and safe menu; no-Execute validation, no-write/no-network DryRun.
* Original 58-row customer CSV archived byte-for-byte; user-approved Business Owner mapping; no silent whitespace or spelling repairs.
* Stable remote UUID/DNS evidence, cached sessions/share list, literal local path checks and strict overlap blocking.
* NTFS owner logical bytes, reparse exclusions, explicit errors/partial coverage, hard-link namespace measurement, concurrency/entry rate/disk queue/timeout limits.
* Current RunId-only CSV and result schema validation; SHA256 transport, atomic writes, idempotent retry, provenance, optional AD enrichment.
* Six output artifacts with input/physical-target coverage and no fabricated allocated bytes.
* Local PS 5.1 integration/regression suite, portable checksummed release and complete project handoff.
* First test iteration exposed PS 5.1 null-string binding for File.Replace; fixed with NullString.Value and regression tested. No production environment tested.
