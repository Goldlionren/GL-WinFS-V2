# SOH GL-WinFS V2 developer handoff

Independent project at `D:\AI\SOH\GL-WinFS-V2`. Upstream is a read-only sibling clone, SHA `8b0c7c92ec385b8e936c548064b51d48c2b005cf`. A pristine upstream source archive and tracked-file hashes are included in the complete development handoff's `reference` directory. Do not modify the upstream clone or publish customer configuration. Runtime has no package manager, third-party module, installer or download dependency.

## Source map

| File | Responsibility |
| --- | --- |
| Start-SOHReport.ps1 | Safe menu/entry, parameter validation, default paths, workspace lock, confirmation and exit codes |
| Test-SOHPrerequisites.ps1 | Read-only identity, built-in commands, optional AD module, ACL inference, explicitly enabled remote checks |
| Verify-SOHPackage.ps1 | Portable SHA256 manifest verification |
| src/Common.ps1 | Strict local paths, reparse ancestry, JSON/CSV, atomic BOM UTF-8 writes, artifact keys |
| src/Validation.ps1 | Strict .NET CSV parsing, no silent corrections, cached DNS/WinRM/CIM/share mapping, conflicts |
| src/Collector.ps1 | Streaming per-directory metadata walk, owner aggregation, pressure/throughput/deadline gates, remote envelope |
| src/Orchestration.ps1 | Frozen run snapshot, exact hashed copies, bounded remote jobs, per-host serial queues, durable interruption states |
| src/Merge.ps1 | Schema/RunId/target/count/hash validation, optional cached AD lookup, six reports and completeness manifest |
| tests/Run-Tests.ps1 | Dependency-free repeatable Windows PowerShell 5.1 mock/integration/regression tests |
| tools/Prepare-Inputs.ps1 | Development-only conversion of user-supplied four-column source, original byte preservation and suggestions |
| tools/Build-Release.ps1 | Explicit runtime allowlist, hashes, ZIP, clean extraction/smoke test and project ZIP |

The runtime package excludes tests and developer tools. The complete project ZIP includes source, tests, tools, evidence, upstream reference, and the standalone runtime package. Local disposable `test-work` and transient `.delivery-staging-*` directories are excluded.

## Contracts and integrity

Input: exactly ID,Department,AbsolutePath. ID is 1–64 safe ASCII identifier characters (alphanumeric, underscore, hyphen); Department is an exact nonempty string. Whitespace, placeholders and known source spelling anomalies block production. UNC is strict SMB DNS-host syntax; local CSV drive paths cannot carry server identity and are refused. Full-volume detection includes the exact special D$ wildcard and any share resolving to a volume root. No DFS namespace enumeration occurs.

Validation schema `SOH.Validation.2` preserves source bytes and SHA256, timestamp, identity, version, OriginalPath, NormalizedPath, SuggestedCorrection, RequiresApproval, FullVolume/approval, server UUID, LocalPath, evidence, LinkedIDs and independent row errors. Source bytes are read once to avoid mismatching the hash and parsed authorization. Canonical DNS resolution is cached; cached read-only remote inventory returns computer UUID and SMB paths. `UUID|casefold(LocalPath)` identifies the physical authorization path. Case-insensitive path comparisons include the separator boundary.

Run schema `SOH.Run.2` freezes the validation snapshot and distinct physical target list. File checksum detects accidental edits. It is not a signature: anyone able to rewrite files and hashes is trusted by the workspace ACL. Use a restricted local workspace. A retry can reuse a RunId only with the same source hash and resolved row snapshot. Global production entry revalidates CSV and live mappings rather than trusting an editable validated-targets.json. Remote collection again checks UUID/share mapping before traversal.

Collector schema `SOH.Collector.2` is fixed, ordered, CSV UTF-8 BOM:

`SchemaVersion,RunId,SourceID,PhysicalKey,Department,OriginalUNC,Server,LocalPath,Owner,OwnerSID,FileCount,LogicalBytes,AllocatedBytes,Status`

Result schema `SOH.Result.2`: RunId/SourceID/PhysicalKey, Status SUCCESS/PARTIAL/FAILED, UTC start/end, observed counts/bytes, skipped-file/directory counts, explicit errors, CSV SHA256. A zero-file target emits a zero aggregate row. ACL failure keeps size under UNKNOWN but makes the target PARTIAL. Directory denial, reparse skip and unknown subtree contents never yield 100% coverage. `AllocatedBytes` stays null. Hard links are counted per namespace entry, not by unique physical file identity. This is a deliberate measurable logical accounting contract, not physical disk chargeback.

Artifacts use `RunId-server-sourceID-physicalKeyHash`. Remote output is under an isolated RunId inside ChargebackOneV2. Exact paths and SHA256 are checked; CSV commits first, result commits last. No glob transport. Same-directory temporary files plus File.Replace/Move publish atomically. PS 5.1 requires `NullString.Value` when no replacement backup path is wanted; `$null` was empirically rejected by its binder. Manifest commits last and hashes each report; consumers must verify hashes rather than reading a partially updated generation.

Merge does not infer schemas from FSRM columns. It processes expected files only; unlisted CSV names are recorded as ignored. Expected wrong schema/run/target/hash/count/noninteger fields become failures. ADDepartment is optional enrichment and cannot replace Department. Same-path aliases get zero counted capacity on secondary folder rows, with PrimaryID/LinkedIDs audit linkage. Numeric aggregation uses exact decimal intermediates; no unit-stripping or fabricated allocated bytes.

## Test and build

Run in **Windows PowerShell 5.1** (the harness deliberately fails its version assertion under PowerShell 7). No Pester dependency:

```powershell
& 'D:\AI\SOH\GL-WinFS-V2\tests\Run-Tests.ps1' -EvidenceName 'test-results'
& 'D:\AI\SOH\GL-WinFS-V2\tools\Build-Release.ps1'
```

The test harness only accesses unique directories under the project `test-work`, creates small synthetic files, a junction, a hard link and a temporary deny ACL, and restores/removes the test ACL/link. It mocks DNS context, CIM, WinRM sessions/jobs/transfers, AD, ACL errors and pressure counters. It also exercises the actual remote script payload in a local isolated PowerShell runspace with serialized request/result objects. This is not a real WinRM connection test.

Tests preserve every iteration in reports. Do not rewrite historical failure evidence. The final suite gates import, collector, merge and CLI; release tests verify ZIP hash identity, clean extraction, every script's parser, no-write DryRun, safe offline All/Validate, read-only prerequisites and checksum tampering detection. `-Project` allows the full harness to target a copied project. Rerun tests on a disposable development/lab location, not customer share trees.

## Operational limits / remaining validation

* Customer Gate 5 is pending. Actual Server 2022 runtime, account rights, remoting transport, counter access, file ACL coverage, performance and operator cancellation must be observed there. Local evidence is Windows 11 / PS 5.1.
* CNAME/cluster mismatch and reparse/mounted-volume roots fail closed; no untested identity override. Parent/child overlaps cannot be retained through automatic exclusion in this version; require disjoint approved CSV scope.
* Whole-tree snapshot consistency, allocated bytes, ADS and unique physical hard-link accounting are outside this contract. Reparse checks limit accidental traversal, but there is a filesystem TOCTOU window if administrators concurrently replace directories. Choose a controlled scan window.
* Synchronous filesystem/CIM calls can block inside one operation. Parent WinRM job timeout adds 30 seconds and requests stop; immediate endpoint termination is not guaranteed. Durable incomplete markers survive interruption. Verify stopped endpoint before retry.
* Disk queue sampling approximates pressure at one-second intervals. 200 entries/sec is the default metadata rate cap. Counter absence fails closed unless the customer explicitly disables the gate with zero.
* Error records are retained in memory for full audit; extremely error-heavy trees may need a future streamed error journal. Directory stack/owner aggregates also grow with directory/owner count, though files are not preloaded recursively.
* One workspace is exclusive-locked. Do not use the same RunId simultaneously from different orchestrators/workspaces. Artifacts/hash lists are not cryptographic authentication; secure directories externally.
* CSV is faithful audit text, including user strings. When opening in a spreadsheet, import fields as text and disable formula interpretation; no spreadsheet automation is performed here.

See reports/00_UPSTREAM_REVIEW.md, phase reports and CUSTOMER_ACCEPTANCE.md. No SOH production filesystem, WinRM endpoint, AD or server configuration was contacted or changed during development.
