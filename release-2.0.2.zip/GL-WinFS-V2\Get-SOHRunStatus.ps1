#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)][string]$RunId,[string]$Workspace,[string]$TargetID,[switch]$CheckRemote,[string]$RemoteRoot='C:\ProgramData\ChargebackOneV2')
$ErrorActionPreference='Stop'
if(-not $Workspace){$Workspace=Join-Path (Split-Path -Parent $PSScriptRoot) 'workspace'}
Import-Module (Join-Path $PSScriptRoot 'src\SOH.psm1') -Force -DisableNameChecking
$run=Read-SOHRun $Workspace $RunId
$targets=@($run.Targets | Where-Object { -not $TargetID -or $_.ID -eq $TargetID })
if(-not $targets.Count){throw 'No target matches the requested ID in this run.'}
$remoteStates=@{}
if($CheckRemote){
    foreach($group in @($targets | Group-Object Server)){
        $session=$null
        try{
            $session=New-PSSession -ComputerName $group.Name -SessionOption (New-PSSessionOption -OpenTimeout 15000 -OperationTimeout 30000) -ErrorAction Stop
            $names=@($group.Group | ForEach-Object { Get-SOHArtifactName $RunId $_ })
            $packets=@(Invoke-Command -Session $session -ArgumentList @((Join-Path $RemoteRoot $RunId),$names) -ErrorAction Stop -ScriptBlock {
                param($dir,$names)
                foreach($name in $names){
                    $progress=Join-Path $dir ($name+'.progress.json');$result=Join-Path $dir ($name+'.result.json')
                    [pscustomobject]@{Name=$name;Progress=$(if(Test-Path -LiteralPath $progress){[IO.File]::ReadAllText($progress)}else{''});Result=$(if(Test-Path -LiteralPath $result){[IO.File]::ReadAllText($result)}else{''});Error=''}
                }
            })
            foreach($packet in $packets){$remoteStates[$packet.Name]=$packet}
        }catch{
            foreach($t in $group.Group){$remoteStates[(Get-SOHArtifactName $RunId $t)]=[pscustomobject]@{Progress='';Result='';Error=$_.Exception.Message}}
        }finally{if($session){Remove-PSSession $session -ErrorAction SilentlyContinue}}
    }
}
foreach($t in $targets){
    $name=Get-SOHArtifactName $RunId $t;$progress=$null;$result=$null;$diagnostic='';$origin='LOCAL'
    if($CheckRemote){
        $origin='REMOTE';$packet=$remoteStates[$name];$diagnostic=$packet.Error
        if($packet.Progress){$progress=ConvertFrom-Json -InputObject $packet.Progress}
        if($packet.Result){$result=ConvertFrom-Json -InputObject $packet.Result}
    }else{
        $drop=Join-Path $Workspace ('runs\'+$RunId+'\drop')
        $pf=Join-Path $drop ($name+'.progress.json');$rf=Join-Path $drop ($name+'.result.json')
        if(Test-Path -LiteralPath $pf){$progress=Read-SOHJson $pf}
        if(Test-Path -LiteralPath $rf){$result=Read-SOHJson $rf}
    }
    foreach($record in @($progress,$result)){
        if($record -and ($record.RunId -ne $RunId -or $record.SourceID -ne $t.ID -or $record.PhysicalKey -ne $t.PhysicalKey)){throw 'Diagnostic artifact identity mismatch.'}
    }
    $status='NO_HEARTBEAT_OR_RESULT';$phase='UNKNOWN';$age=$null;$fileCount=$null;$bytes=$null;$pidValue=$null;$updated='';$lastFile='';$lastPath='';$queue=$null
    if($progress){
        $status=$progress.Status;$phase=$progress.Phase;$fileCount=$progress.FileCount;$bytes=$progress.LogicalBytes;$pidValue=$progress.ProcessId;$updated=$progress.UpdatedUtc;$lastFile=$progress.LastFileUtc;$lastPath=$progress.LastObservedPath;$queue=$progress.DiskQueue
        $age=[Math]::Max(0,([datetime]::UtcNow-[datetime]::Parse($updated).ToUniversalTime()).TotalSeconds)
    }
    if($result){
        if(@($result.Errors | Where-Object Code -eq 'RUNNING_OR_INTERRUPTED').Count){if(-not $progress){$status='RUNNING_OR_INTERRUPTED';$diagnostic='Old/current run has no verified result yet; timer or process activity cannot establish file progress.'}}
        else{$status=$result.Status;$fileCount=$result.FileCount;$bytes=$result.LogicalBytes;$diagnostic=(@($result.Errors | ForEach-Object Message)-join ' | ')}
    }
    if(-not $diagnostic -and -not $progress -and -not $result){$diagnostic='No heartbeat/result available. Version 2.0.0 does not emit progress files.'}
    $blockPath=Get-SOHHostBlockPath $Workspace $t.HostId
    [pscustomobject]@{RunId=$RunId;ID=$t.ID;Server=$t.Server;Origin=$origin;Status=$status;Phase=$phase;ProcessId=$pidValue;FileCount=$fileCount;LogicalBytes=$bytes;ObservedFileCount=$(if($progress){$progress.FileCount}else{$null});ObservedLogicalBytes=$(if($progress){$progress.LogicalBytes}else{$null});DirectoriesVisited=$(if($progress){$progress.DirectoriesVisited}else{$null});UpdatedUtc=$updated;HeartbeatAgeSeconds=$age;LastFileUtc=$lastFile;LastObservedPath=$lastPath;DiskQueue=$queue;HostQuarantined=(Test-Path -LiteralPath $blockPath);HostBlockEvidence=$blockPath;Diagnostic=$diagnostic}
}
