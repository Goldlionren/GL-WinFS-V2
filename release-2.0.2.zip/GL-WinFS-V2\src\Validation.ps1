function ConvertTo-SOHParsedPath([string]$Path) {
    $original = $Path
    $candidate = $Path.Trim()
    $suggestions = New-Object 'Collections.Generic.List[string]'
    if ($candidate -cne $original) { $suggestions.Add('Remove surrounding cell whitespace (customer must edit CSV).') }
    if ($candidate -notmatch '^\\\\([A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?)\\([^\\]+)(?:\\(.*))?$') { throw 'Only explicit SMB UNC \\server\share[\subpath] is supported; local drive paths lack a Server in this three-column contract.' }
    $hostName = $Matches[1]; $share = $Matches[2]; $suffix = [string]$Matches[3]
    if ($hostName.Contains('..') -or $hostName -match '^[0-9.]+$') { throw 'Invalid DNS host; IP addresses are not accepted as stable host identity.' }
    $full = $candidate -match '^\\\\[^\\]+\\D\$\\\*$'
    if ($candidate -match '[\x00-\x1f<>|"%/:?\[\]]' -or ($candidate.Contains('*') -and -not $full)) { throw 'Device, variable, wildcard, URI or invalid path syntax.' }
    foreach ($part in @($share) + @($suffix.TrimEnd('\') -split '\\')) {
        if ($part -in @('.','..') -or $part -match '\.$') { throw 'Dot traversal / trailing-dot components are forbidden.' }
        if ($part -and $part -cne $part.Trim()) { $suggestions.Add('Share/subpath component has whitespace; preserve literal spelling until customer confirms.') }
    }
    if ($suffix -match '\\\\') { throw 'Empty subpath component is forbidden.' }
    if ($hostName -ieq 'sohf3') { $suggestions.Add('Possible server typo sohf3 -> sohfs3; no automatic substitution.') }
    if ($share -ieq 'Toursim Sales') { $suggestions.Add('Possible share typo Toursim Sales -> Tourism Sales; no automatic substitution.') }
    [pscustomobject]@{ HostName=$hostName.ToLowerInvariant(); Share=$share; Suffix=$(if($full){''}else{$suffix.TrimEnd('\')}); FullVolume=[bool]$full; NormalizedPath=$candidate.TrimEnd('\'); Suggestions=@($suggestions.ToArray()) }
}
function New-SOHRemoteContext {
    [pscustomobject]@{ DNS=@{}; Hosts=@{}; Sessions=@{}; Failures=@{} }
}
function Get-SOHRemoteHost($Context, [string]$HostName) {
    $key = $HostName.ToLowerInvariant()
    if (-not $Context.DNS.ContainsKey($key)) {
        $Context.DNS[$key] = [Net.Dns]::GetHostEntry($HostName).HostName.TrimEnd('.').ToLowerInvariant()
    }
    $canonical = $Context.DNS[$key]
    if ($Context.Failures.ContainsKey($canonical)) { throw $Context.Failures[$canonical] }
    if (-not $Context.Hosts.ContainsKey($canonical)) {
        try {
            $opt = New-PSSessionOption -OpenTimeout 30000 -OperationTimeout 60000
            $session = New-PSSession -ComputerName $canonical -SessionOption $opt -ErrorAction Stop
            $Context.Sessions[$canonical] = $session
            $hostData = Invoke-Command -Session $session -ErrorAction Stop -ScriptBlock {
                $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
                $product = Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop
                $name = $cs.DNSHostName.ToLowerInvariant()
                if ($cs.PartOfDomain) { $name += '.' + $cs.Domain.ToLowerInvariant() }
                [pscustomobject]@{ Server=$name; HostId=[string]$product.UUID; Shares=@(Get-SmbShare -ErrorAction Stop | Select-Object Name,Path) }
            }
            if (-not $hostData.HostId -or $hostData.HostId -match '^0+(-0+)*$') { throw 'Host returned no stable hardware UUID.' }
            # Reject cluster/alias identity mismatch rather than guess the physical server.
            if ($canonical.Split('.')[0] -ine $hostData.Server.Split('.')[0]) { throw 'DNS endpoint and remote computer identity differ; cluster/CNAME requires customer review.' }
            $hostData | Add-Member NoteProperty Session $session
            $Context.Hosts[$canonical] = $hostData
        } catch { $Context.Failures[$canonical] = $_.Exception.Message; throw }
    }
    return $Context.Hosts[$canonical]
}
function Close-SOHRemoteContext($Context) {
    foreach ($s in $Context.Sessions.Values) {
        # A timed-out transport must not block report generation again during synchronous disposal.
        if($Context.PSObject.Properties['QuarantinedSessions'] -and $Context.QuarantinedSessions.Contains($s)){continue}
        Remove-PSSession -Session $s -ErrorAction SilentlyContinue
    }
}
function Resolve-SOHTarget($Parsed, $Context) {
    $h = Get-SOHRemoteHost $Context $Parsed.HostName
    $shares = @($h.Shares | Where-Object { $_.Name -ieq $Parsed.Share })
    if ($shares.Count -ne 1 -or [string]::IsNullOrWhiteSpace([string]$shares[0].Path)) { throw 'Share missing, ambiguous or Get-SmbShare.Path blank; no platform inference or drive guess allowed.' }
    $root = Assert-SOHLocalPath ([string]$shares[0].Path)
    $local = $root
    if ($Parsed.Suffix) { $local = Assert-SOHLocalPath ([IO.Path]::Combine($root,$Parsed.Suffix)) }
    if ($Parsed.FullVolume -and $root -ine 'D:\') { throw 'D$ full-volume request did not resolve to D:\.' }
    $check = Invoke-Command -Session $h.Session -ErrorAction Stop -ArgumentList $local -ScriptBlock {
        param($p)
        if (-not (Test-Path -LiteralPath $p -PathType Container -ErrorAction Stop)) { throw "Target directory does not exist: $p" }
        $current = Get-Item -LiteralPath $p -Force -ErrorAction Stop
        while ($null -ne $current) {
            if (($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Target or ancestor is a reparse point.' }
            $current = $current.Parent
        }
        $true
    }
    if (-not $check) { throw 'Remote directory validation failed.' }
    [pscustomobject]@{ Server=$h.Server; HostId=$h.HostId; LocalPath=$local; Evidence=('DNS + remote computer UUID + Get-SmbShare.Path=' + $root + ' + literal suffix + remote Test-Path/reparse ancestors') }
}
function Set-SOHConflicts([object[]]$Rows) {
    $resolved = @($Rows | Where-Object { $_.PhysicalKey })
    foreach ($g in @($resolved | Group-Object PhysicalKey)) {
        $departments = @($g.Group.Department | Select-Object -Unique)
        if ($departments.Count -gt 1) {
            foreach ($r in $g.Group) { $r.Status='NEEDS_REVIEW'; $r.RequiresApproval=$true; $r.Errors += 'Cross-department physical-path conflict.' }
        } else {
            $ids = @($g.Group.ID)
            foreach ($r in $g.Group) { $r.LinkedIDs=$ids; $r.PrimaryID=$ids[0] }
        }
    }
    for ($i=0; $i -lt $resolved.Count; $i++) {
        for ($j=$i+1; $j -lt $resolved.Count; $j++) {
            $a=$resolved[$i]; $b=$resolved[$j]
            if ($a.HostId -ieq $b.HostId -and ((Test-SOHAncestor $a.LocalPath $b.LocalPath) -or (Test-SOHAncestor $b.LocalPath $a.LocalPath))) {
                foreach ($r in @($a,$b)) { $r.Status='NEEDS_REVIEW'; $r.RequiresApproval=$true; $r.Errors += ('Parent/child overlap: ' + $a.ID + ' / ' + $b.ID) }
            }
        }
    }
}
function Invoke-SOHValidate {
    param([string]$CsvPath,[string]$Workspace,[switch]$Offline,[switch]$ApproveFullVolume,[scriptblock]$Resolver,$Context,[switch]$NoWrite)
    # Read once so scope, preserved source and checksum refer to the same bytes.
    $sourceBytes=[IO.File]::ReadAllBytes($CsvPath)
    $sha=[Security.Cryptography.SHA256]::Create()
    try{$hash=([BitConverter]::ToString($sha.ComputeHash($sourceBytes))).Replace('-','')}finally{$sha.Dispose()}
    # Built-in .NET CSV parser catches extra/missing cells that Import-Csv silently drops.
    Add-Type -AssemblyName Microsoft.VisualBasic
    $sourceStream=New-Object IO.MemoryStream(,$sourceBytes)
    $reader=New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($sourceStream,[Text.Encoding]::UTF8,$true)
    $reader.TextFieldType=[Microsoft.VisualBasic.FileIO.FieldType]::Delimited
    $reader.SetDelimiters(',');$reader.HasFieldsEnclosedInQuotes=$true;$reader.TrimWhiteSpace=$false
    $data=New-Object 'Collections.Generic.List[object]'
    try {
        $columns=@($reader.ReadFields())
        if (($columns -join ',') -cne 'ID,Department,AbsolutePath') { throw 'CSV must have exactly ID,Department,AbsolutePath columns in that order.' }
        while(-not $reader.EndOfData){
            try {
                $cells=@($reader.ReadFields())
                $data.Add([pscustomobject]@{ID=$(if($cells.Count -gt 0){$cells[0]}else{''});Department=$(if($cells.Count -gt 1){$cells[1]}else{''});AbsolutePath=$(if($cells.Count -gt 2){$cells[2]}else{''});ShapeError=$(if($cells.Count -ne 3){'CSV row must contain exactly three fields.'}else{''})})
            } catch [Microsoft.VisualBasic.FileIO.MalformedLineException] {
                $data.Add([pscustomobject]@{ID='';Department='';AbsolutePath=$reader.ErrorLine;ShapeError='Malformed CSV quoting on line '+$reader.ErrorLineNumber})
            }
        }
    } finally { $reader.Close();$sourceStream.Dispose() }
    if (-not $data.Count) { throw 'CSV contains no data rows.' }
    $rows = New-Object 'Collections.Generic.List[object]'
    foreach ($d in $data) {
        $r = [pscustomobject][ordered]@{ ID=[string]$d.ID; Department=[string]$d.Department; OriginalPath=[string]$d.AbsolutePath; OriginalUNC=[string]$d.AbsolutePath; NormalizedPath=''; SuggestedCorrection=''; RequiresApproval=$false; FullVolume=$false; FullVolumeApproved=$false; Status='VALID'; Server=''; HostId=''; LocalPath=''; PhysicalKey=''; PrimaryID=[string]$d.ID; LinkedIDs=@([string]$d.ID); MatchEvidence=''; Errors=@() }
        if ($d.ShapeError) { $r.Status='INVALID';$r.Errors += $d.ShapeError }
        if ($r.ID -notmatch '^[A-Za-z0-9_-]{1,64}$') { $r.Status='INVALID'; $r.Errors += 'ID must be 1-64 safe alphanumeric/underscore/hyphen characters.' }
        if ([string]::IsNullOrWhiteSpace($r.Department)) { $r.Status='INVALID'; $r.Errors += 'Department is empty.' }
        elseif ($r.Department -ieq 'PENDING_CONFIRMATION' -or $r.Department -cne $r.Department.Trim()) { $r.RequiresApproval=$true; $r.Errors += 'Department requires customer confirmation/edit.' }
        try {
            $p = ConvertTo-SOHParsedPath $r.OriginalPath
            $r.NormalizedPath=$p.NormalizedPath; $r.FullVolume=$p.FullVolume
            $r.SuggestedCorrection=$p.Suggestions -join ' '
            if ($p.Suggestions.Count) { $r.RequiresApproval=$true; $r.Errors += $p.Suggestions }
            if ($p.FullVolume) {
                $r.FullVolumeApproved=[bool]$ApproveFullVolume
                if (-not $ApproveFullVolume) { $r.RequiresApproval=$true; $r.Errors += 'Explicit -ApproveFullVolume is required.' }
            }
            if ($Offline) { $r.RequiresApproval=$true; $r.Errors += 'OFFLINE: SMB mapping, host identity and existence unverified.' }
            elseif ($p.Suggestions.Count -eq 0) {
                if ($Resolver) { $v = & $Resolver $p $Context } else { $v = Resolve-SOHTarget $p $Context }
                $r.Server=$v.Server; $r.HostId=$v.HostId; $r.LocalPath=Assert-SOHLocalPath $v.LocalPath; $r.MatchEvidence=$v.Evidence
                $r.PhysicalKey=($r.HostId + '|' + $r.LocalPath.TrimEnd('\')).ToLowerInvariant()
                # A normal UNC share can also expose a volume root; never bypass full-volume approval.
                if ($r.LocalPath -match '^[A-Za-z]:\\$') {
                    $r.FullVolume=$true;$r.FullVolumeApproved=[bool]$ApproveFullVolume
                    if (-not $ApproveFullVolume) { $r.RequiresApproval=$true;$r.Errors += 'Resolved share exposes a whole volume; -ApproveFullVolume required.' }
                }
            }
        } catch { $r.Status='INVALID'; $r.Errors += $_.Exception.Message }
        if ($r.Status -eq 'VALID' -and $r.RequiresApproval) { $r.Status='NEEDS_REVIEW' }
        $rows.Add($r)
    }
    foreach ($g in @($rows | Group-Object ID | Where-Object Count -gt 1)) {
        foreach ($r in $g.Group) { $r.Status='INVALID'; $r.Errors += 'Duplicate ID.' }
    }
    Set-SOHConflicts @($rows.ToArray())
    $map = [pscustomobject][ordered]@{ SchemaVersion='SOH.Validation.2'; Version=$script:SOHVersion; CreatedUtc=[datetime]::UtcNow.ToString('o'); Identity=Get-SOHIdentity; SourceCSV=[IO.Path]::GetFullPath($CsvPath); SourceSHA256=$hash; Offline=[bool]$Offline; TestMode=[bool]$Resolver; Rows=@($rows.ToArray()) }
    if (-not $NoWrite) {
        $inputDir=Join-Path $Workspace 'input'; $outDir=Join-Path $Workspace 'output'
        [void][IO.Directory]::CreateDirectory($inputDir)
        $sourceCopy=Join-Path $inputDir ('source-' + $hash + '.csv')
        if (-not [IO.File]::Exists($sourceCopy)) {
            $tempSource=$sourceCopy+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
            try{
                [IO.File]::WriteAllBytes($tempSource,$sourceBytes)
                if((Get-FileHash -LiteralPath $tempSource).Hash -ne $hash){throw 'Source preservation hash mismatch.'}
                [IO.File]::Move($tempSource,$sourceCopy)
            }finally{if([IO.File]::Exists($tempSource)){[IO.File]::Delete($tempSource)}}
        }
        if ((Get-FileHash -LiteralPath $sourceCopy).Hash -ne $hash) { throw 'Preserved CSV hash mismatch.' }
        Write-SOHJson (Join-Path $inputDir 'validated-targets.json') $map
        $csvRows=@($rows | ForEach-Object { $c=$_ | Select-Object *; $c.Errors=$_.Errors -join ' | '; $c.LinkedIDs=$_.LinkedIDs -join ';'; $c })
        Write-SOHCsv (Join-Path $outDir 'validation.csv') $csvRows @($rows[0].PSObject.Properties.Name)
        Write-SOHAtomicText (Join-Path $outDir 'validation-summary.txt') ("Version=$($map.Version)`r`nIdentity=$($map.Identity)`r`nUTC=$($map.CreatedUtc)`r`nSourceSHA256=$hash`r`nTotal=$($rows.Count)`r`nVALID=$(@($rows | Where-Object Status -eq 'VALID').Count)`r`nNEEDS_REVIEW=$(@($rows | Where-Object Status -eq 'NEEDS_REVIEW').Count)`r`nINVALID=$(@($rows | Where-Object Status -eq 'INVALID').Count)`r`nNo scan performed.`r`n")
    }
    return $map
}
