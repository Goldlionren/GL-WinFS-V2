# 2.0.2 文件进度与独立停滞超时

本次更新在 2.0.1 进度诊断之上增加主控 watchdog。原来的扫描总时限依赖扫描线程返回检查；单次目录枚举、文件元数据或 ACL 调用阻塞时，扫描线程不能自救。新版由主控独立检查已启动采集 Job，不需要远端扫描调用先返回。

## 显示内容

每约 5 秒接收真实扫描线程的进度，每约 10 秒在主窗口输出一行，同时追加到 `workspace\runs\<RunId>\collection-progress.log`。包含目标、阶段、Files、Dirs、GiB、Errors、上次收到新心跳后的秒数、计数未增加的秒数、最近观察路径。不会用运行时长或 CPU/I/O 次数冒充文件数。路径是最近发布的观察点，不保证正好是随后阻塞的那个文件；不逐文件落盘，以免显著增加开销。

## 默认超时

| 参数 | 默认 | 行为 |
| --- | --- | --- |
| HeartbeatTimeoutSeconds | 120 秒 | 自启动或最后一个新进度消息起，超过时限仍无新消息，记录 HEARTBEAT_TIMEOUT。初始无心跳也计时。 |
| NoProgressTimeoutSeconds | 300 秒 | 已处理文件数、观察条目数、已访问目录数、字节数都未增长，记录 NO_PROGRESS_TIMEOUT。阶段/路径/心跳时间变化不会重置此时限。目录数量增长可避免大量空目录被误判。 |
| TimeoutSeconds | 3600 秒 | 单目标总时限保留；主控另有 30 秒传输余量。下方全量命令显式设为 86400 秒，但前两种停滞超时仍有效。 |

磁盘压力持续高、长时间无计数进展也会触发停滞超时，错误记录保留最后阶段和队列诊断。真正缓慢但正常的操作也可能触发；可根据客户观察调整前两个参数，最小 30 秒，不能用 0 关闭。实际策略写入当前 RunId 的 watchdog-policy.json。

超时先落盘失败结果、最后心跳与服务器隔离记录，再在独立本地 runspace 请求停止 Job，主控最多等 5 秒。停止调用返回也不能证明远端底层调用已退出，所以不强杀进程，不重启 WinRM，不自动扫描同一服务器下一个目录。该服务器剩余目标标为 HOST_QUARANTINED，其他服务器继续。Merge 输出 INCOMPLETE 与 errors.csv；心跳中的临时计数保留用于诊断，但没有正式已校验 CSV 的数字不纳入计费总数。

隔离记录位于 `workspace\blocked-hosts\<主机标识哈希>.json`，包含旧 RunId、目标、最后远端 PID 和阶段。它跨 RunId 生效。仅在操作员核实旧远端执行已退出后，将对应的一个记录移动到另一个留证目录，再重新运行。不要批量删隔离记录，也不要仅因 StopRequestCompleted=true 就认为远端已退出。

本功能监控已启动的采集 Job；初始在线验证、结果文件传输、操作系统或主控进程自身卡住不在这两个停滞计时器的保证范围内。Windows 控制台选择文本造成主控暂停时，本地主控也不能执行检查；保持运行窗口不处于 Select/选择模式，可在另一个窗口读取日志。CIM 参数超时和 Job 停止都不是强制结束内核 I/O 的保证。

## 部署（全部命令单行）

1. 旧版本正在执行的作业不会热更新。先由操作员停止旧采集并确认远端退出，或等待它结束；保留原 workspace 和所有输出。
2. 把新 release.zip 解压到 `C:\Temp\SOH-V202`，得到 `C:\Temp\SOH-V202\GL-WinFS-V2`。继续以 SOH\svc_HPEreport 身份运行 Windows PowerShell 5.1。
3. 校验包：

```powershell
& 'C:\Temp\SOH-V202\GL-WinFS-V2\Verify-SOHPackage.ps1'
```

4. 使用客户现场已修正的 CSV，不要换回包内原始输入。生成新 RunId，全量运行：

```powershell
$runId=[guid]::NewGuid().ToString('D'); Write-Host "RunId: $runId"; & 'C:\Temp\SOH-V202\GL-WinFS-V2\Start-SOHReport.ps1' -Stage All -Execute -ApproveFullVolume -ResolveAD -CsvPath 'C:\SOHReporting\workspace\input\customer-targets.corrected.csv' -Workspace 'C:\SOHReporting\workspace' -RunId $runId -MaxConcurrency 1 -MaxEntriesPerSecond 200 -MaxDiskQueueLength 2 -TimeoutSeconds 86400 -HeartbeatTimeoutSeconds 120 -NoProgressTimeoutSeconds 300
```

按提示输入新的完整 COLLECT 确认字符串。另开同账号窗口，替换下面的 UUID 查看最近记录；按 Ctrl+C 只会停止这个日志查看命令：

```powershell
Get-Content -LiteralPath 'C:\SOHReporting\workspace\runs\<本次UUID>\collection-progress.log' -Tail 10 -Wait
```

查看目标详情（本地只读）：

```powershell
& 'C:\Temp\SOH-V202\GL-WinFS-V2\Get-SOHRunStatus.ps1' -Workspace 'C:\SOHReporting\workspace' -RunId '<本次UUID>' -TargetID 'SOH-001' | Format-List
```

ObservedFileCount 是最后心跳的临时数量；FileCount 是正式结果数量（超时失败可为 0，不代表目录为空）。HostQuarantined 说明是否仍需核实旧远端执行。

## 测试和未验证项

测试证据见 reports/test-results.json/csv 和 reports/06_STALL_TIMEOUTS.md。覆盖 Windows PowerShell 5.1、本地真实后台 Job、阻塞的 StopJob 模拟、无心跳、有心跳无进展、空目录推进、跨服务器继续、隔离跨 RunId、错误报告和原回归。

未连接客户环境。真实 Server 2022 WinRM 进度流、现场 ACL/存储等待原因、远端停止实际行为和全量性能需客户验证。2.0.2 改善可见性与主控等待行为，不是已证明修复现场根因的声明。原 2.0.0/2.0.1 项目及 ZIP 保持原样。
