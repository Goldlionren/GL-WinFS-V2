#requires -Version 5.1
[CmdletBinding()]
param([string]$PackageRoot)
$ErrorActionPreference='Stop'
if(-not $PackageRoot){$PackageRoot=$PSScriptRoot}
$root=[IO.Path]::GetFullPath($PackageRoot).TrimEnd('\')
$list=Join-Path $root 'SHA256SUMS.txt'
$count=0;$seen=@{}
foreach($line in [IO.File]::ReadAllLines($list)){
    if(-not $line){continue}
    if($line -notmatch '^([A-Fa-f0-9]{64})  (.+)$'){throw 'Invalid checksum line.'}
    $hash=$Matches[1];$relative=$Matches[2]
    if([IO.Path]::IsPathRooted($relative)){throw 'Absolute checksum path forbidden.'}
    $path=[IO.Path]::GetFullPath((Join-Path $root $relative))
    if(-not $path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Checksum traversal forbidden.'}
    if($seen.ContainsKey($relative)){throw 'Duplicate checksum entry.'};$seen[$relative]=$true
    if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine $hash){throw "Checksum mismatch: $relative"}
    $count++
}
if($count -eq 0){throw 'Empty checksum list.'}
Write-Output "PASS: $count package file SHA256 checksums verified."
