﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Validate','Collect','Merge','All')][string]$Stage,
    [string]$CsvPath,
    [string]$Workspace,
    [string]$RunId,
    [switch]$Execute,[switch]$DryRun,[switch]$Offline,[switch]$ApproveFullVolume,[switch]$ResolveAD,
    [ValidateRange(1,4)][int]$MaxConcurrency=1,
    [ValidateRange(1,86400)][int]$TimeoutSeconds=3600,
    [ValidateRange(30,86400)][int]$HeartbeatTimeoutSeconds=120,
    [ValidateRange(30,86400)][int]$NoProgressTimeoutSeconds=300,
    [ValidateRange(1,10000)][int]$MaxEntriesPerSecond=200,
    [ValidateRange(0,1000)][int]$MaxDiskQueueLength=2,
    [string]$RemoteRoot='C:\ProgramData\ChargebackOneV2',
    [string]$ConfirmationToken
)
$ErrorActionPreference='Stop'
if (-not $CsvPath) { $CsvPath=Join-Path $PSScriptRoot 'input\customer-targets.csv' }
if (-not $Workspace) { $Workspace=Join-Path (Split-Path -Parent $PSScriptRoot) 'workspace' }
Import-Module (Join-Path $PSScriptRoot 'src\SOH.psm1') -Force -DisableNameChecking
$context=$null; $lock=$null
try {
    if (-not [IO.Path]::IsPathRooted($Workspace)) { $Workspace=Join-Path $PSScriptRoot $Workspace }
    if (-not [IO.Path]::IsPathRooted($CsvPath)) { $CsvPath=Join-Path $PSScriptRoot $CsvPath }
    $Workspace=Assert-SOHLocalPath ([IO.Path]::GetFullPath($Workspace))
    if (-not $Stage) {
        Write-Host 'SOH V2: [Enter/1] Validate only; [2] Collect; [3] Merge; [4] All; [Q] Quit'
        $choice=Read-Host 'Default is read-only remote validation'
        switch ($choice) { '2'{$Stage='Collect'} '3'{$Stage='Merge'} '4'{$Stage='All'} 'Q'{return} default{$Stage='Validate'} }
    }
    if ($DryRun) {
        # No sessions, file writes or scans, even with -Execute.
        $planMap=Invoke-SOHValidate -CsvPath $CsvPath -Workspace $Workspace -Offline -ApproveFullVolume:$ApproveFullVolume -NoWrite
        $saved=Join-Path $Workspace 'input\validated-targets.json'
        if (Test-Path -LiteralPath $saved) {
            $candidate=Read-SOHJson $saved
            if ($candidate.SourceSHA256 -eq $planMap.SourceSHA256) { $planMap=$candidate }
        }
        [pscustomobject]@{Mode='DRY_RUN';RequestedStage=$Stage;Version='2.0.2';SourceSHA256=$planMap.SourceSHA256;Engine='Ntfs';Identity=Get-SOHIdentity;Workspace=$Workspace;RemoteRoot=$RemoteRoot;MaxConcurrency=$MaxConcurrency;PerServerConcurrency=1;MaxEntriesPerSecond=$MaxEntriesPerSecond;MaxDiskQueueLength=$MaxDiskQueueLength;TimeoutSeconds=$TimeoutSeconds;HeartbeatTimeoutSeconds=$HeartbeatTimeoutSeconds;NoProgressTimeoutSeconds=$NoProgressTimeoutSeconds;FullVolumeTargets=@($planMap.Rows | Where-Object FullVolume | Select-Object ID,OriginalUNC);Targets=$planMap.Rows;ResolutionNote='Unresolved offline rows are not executable; saved mappings are advisory until fresh validation.'} | ConvertTo-Json -Depth 20
        exit 0
    }
    $existing=$Workspace
    while (-not (Test-Path -LiteralPath $existing)) { $existing=Split-Path -Parent $existing }
    Assert-SOHNoReparse $existing
    [void][IO.Directory]::CreateDirectory($Workspace)
    Assert-SOHNoReparse $Workspace
    $lock=[IO.File]::Open((Join-Path $Workspace '.soh.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    if (-not $Execute -and $Stage -ne 'Validate') { Write-Host 'No -Execute: validation only.'; $Stage='Validate' }
    if ($Stage -eq 'Merge') {
        if (-not $RunId) { throw '-RunId is required for Merge.' }
        $run=Read-SOHRun $Workspace $RunId
        $manifest=Invoke-SOHMerge $run $Workspace -ResolveAD:$ResolveAD
        Write-Host ("RunId={0} Status={1} Output={2}" -f $RunId,$manifest.Status,(Join-Path $Workspace "runs\$RunId\output"))
        if ($manifest.Status -ne 'COMPLETE') { exit 2 }; exit 0
    }
    if (-not $Offline) { $context=New-SOHRemoteContext }
    # Every production Collect refreshes authorization from the original CSV and live shares.
    $map=Invoke-SOHValidate -CsvPath $CsvPath -Workspace $Workspace -Offline:$Offline -ApproveFullVolume:$ApproveFullVolume -Context $context
    if ($Stage -eq 'Validate') {
        Write-Host ('Validation output: '+(Join-Path $Workspace 'output\validation.csv'))
        if (@($map.Rows | Where-Object Status -ne 'VALID').Count) { exit 2 }; exit 0
    }
    Assert-SOHCollectMap $map -ApproveFullVolume:$ApproveFullVolume
    if (-not $RunId) { $RunId=[guid]::NewGuid().ToString('D') }
    Assert-SOHRunId $RunId
    $targets=@(Get-SOHPhysicalTargets $map)
    Write-Host ("RunId={0}; input rows={1}; physical targets={2}; full volume={3}" -f $RunId,@($map.Rows).Count,$targets.Count,@($targets | Where-Object FullVolume).Count)
    $targets | Select-Object ID,Department,Server,LocalPath,FullVolume | Format-Table -AutoSize | Out-Host
    $token='COLLECT '+$RunId+' '+$map.SourceSHA256
    Write-Host ('Second confirmation must exactly equal: '+$token)
    if (-not $ConfirmationToken) { $ConfirmationToken=Read-Host 'Type confirmation token (blank cancels)' }
    if ($ConfirmationToken -cne $token) { throw 'Collection not confirmed.' }
    $run=New-SOHRun $map $Workspace $RunId -ApproveFullVolume:$ApproveFullVolume
    try {
        Invoke-SOHCollect -Run $run -Workspace $Workspace -Context $context -SourceRoot (Join-Path $PSScriptRoot 'src') -MaxConcurrency $MaxConcurrency -TimeoutSeconds $TimeoutSeconds -HeartbeatTimeoutSeconds $HeartbeatTimeoutSeconds -NoProgressTimeoutSeconds $NoProgressTimeoutSeconds -MaxEntriesPerSecond $MaxEntriesPerSecond -MaxDiskQueueLength $MaxDiskQueueLength -RemoteRoot $RemoteRoot
    } catch { Write-Warning ('Collection interrupted: '+$_.Exception.Message+'; generating INCOMPLETE reports from durable target states.') }
    # Collect also creates completeness reports; Stage Merge can repeat them offline.
    $manifest=Invoke-SOHMerge $run $Workspace -ResolveAD:$ResolveAD
    Write-Host ("RunId={0} Status={1} Output={2}" -f $RunId,$manifest.Status,(Join-Path $Workspace "runs\$RunId\output"))
    if ($manifest.Status -ne 'COMPLETE') { exit 2 }
} catch { Write-Error $_ -ErrorAction Continue; exit 1 }
finally { if ($context) { Close-SOHRemoteContext $context }; if ($lock) { $lock.Dispose() } }
