# Gate 2 — NTFS collection

Implemented remote local-path metadata/owner walk, read-only host/share/NTFS recheck, per-path statuses, known skips/errors, no reparse following, logical hard-link entry policy, bounded concurrency (per host serial), entry-rate and disk queue gates, timeout/cancel markers, RunId-scoped artifacts and verified exact transport.

Evidence: real local fixture has 3 files / 41 logical bytes. Real hard link changes this to 4 namespace entries / 52 bytes; real junction to a 99-byte outside file is skipped with PARTIAL and leaves the original 41-byte total. ACL failures, directory denial, missing paths, deadlines, I/O pressure gating and a real denied output directory are tested. Remote script body runs locally in a separate runspace with serialized objects and mocked CIM/SMB. Scheduler mocks reproduce 10 groups / 4 successes / 6 independently reported failures, plus same-server siblings after a path disappears, disconnect/stop, checksum mismatch, retries and cancellation.

Static PowerShell AST rejects FSRM/DFS/installation/service/task/ACL mutation commands from runtime source. There is no Auto or experimental FSRM branch, no 45-second fallback and no wildcard report copy. No runtime target writes except this application's explicitly named report artifacts.

Gate 2 offline PASS. Open: real WinRM serialization/transfer/cancellation, endpoint rights, actual NTFS/ACL coverage and performance counters, operational rate/timeout settings. Unit transport mocks do not substitute for these customer tests. Strongly consistent snapshots, unique physical bytes and immediate hard-kill termination are not promised.
