# Gate 1 — import and validation

Implemented strict three-column parser, original byte/hash preservation, per-row tri-state results and reasons, literal UNC parsing, no automatic spelling/whitespace correction, cached remote identity/share resolution, whole-volume approval and physical duplicate/overlap protection.

Actual customer source supplied during development: 58 rows, SHA256 `1553B3209190B9F1AAC653200FACFAECBC5998C54034CCD80B747280CDBE5722`. User explicitly approved Business Owner -> Department. Conversion preserves original values/paths and original four-column file. Seven known review items are enumerated in input/suggested-corrections.csv. Converted input SHA256 is recorded in the customer-offline evidence. Task-brief placeholder template also retained.

Evidence: iteration-01/02/03/04 test CSV/JSON; final test-results supersedes for current code. Named Gate 1 tests cover all required input types, 175 permission failures, 103 valid mock resolutions, alias/short/FQDN dedup, SOHFS4/SOHFS7 overlap incidents, CSV Unicode/commas, bad shape and array parsing. Actual offline customer validation: 58 NEEDS_REVIEW, 0 VALID, 0 INVALID; no host resolution attempted. This is expected, not a production pass.

Gate 1 offline PASS. Open: actual SMB paths and all business review items; DNS/CNAME/cluster policies; least-privilege share Path access. No DFS or target expansion permitted. No production contact.
