# Gate 3 — Department merge

Implemented six reports, strict current-run schema/provenance/hash/count checks, audited ignored historical/FSRM CSVs, per-input traceability and physical-path dedup, Department/server aggregation, optional cached SID->AD enrichment, empty AllocatedBytes and explicit completeness.

Evidence: two input references to the same 3-file / 41-byte fixture emit two folder rows but only one counted physical path; Department totals remain 41 bytes. AD failures leave Department unchanged. Foreign RunId, FSRM title CSV under the expected name, bad numbers, duplicate owner rows, missing results, PARTIAL results and edited conflicting validation all produce INCOMPLETE. CLI completeness failure exits 2. Idempotent Merge and frozen run SHA256 are tested.

Gate 3 offline PASS. Open: customer agreement on logical namespace accounting and treatment of incomplete results; optional live AD lookup. COMPLETE means measured scope satisfied software checks, never customer business acceptance. All manifests retain PENDING_CUSTOMER_GATE_5.
