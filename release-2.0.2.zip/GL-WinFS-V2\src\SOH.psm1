$ErrorActionPreference='Stop'
foreach ($file in @('Common','Validation','Collector','Watchdog','Orchestration','Merge')) { . (Join-Path $PSScriptRoot ($file+'.ps1')) }
Export-ModuleMember -Function *-SOH*
