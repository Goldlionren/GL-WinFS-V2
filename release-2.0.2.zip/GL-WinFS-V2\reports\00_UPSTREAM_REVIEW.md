# Gate 0 — upstream review

Reviewed 2026-11-12 (Australia/Sydney). Baseline cloned from https://github.com/maubhpe/GL-WinFS to `D:\AI\SOH\upstream-GL-WinFS`; commit `8b0c7c92ec385b8e936c548064b51d48c2b005cf`. Initial sandbox network attempt failed; authorized network clone succeeded. No baseline modifications or upstream submissions. MIT copyright (c) 2026 maubhpe preserved verbatim in LICENSE.

Read all tracked executable scripts (four), sample JSON, root README, public/scripts/README.md, and all four docs. `docs/known-limitations.md` does not exist; limitations are in `docs/development.md`. Documentation line references describe an older revision; actual functions were inspected. Repository contains no automated tests or build system.

## Actual implementation and contracts

* `Get-DfsTargetMap.ps1`: `Get-HostFromUnc`, `Get-ShareAndRest`, `Get-LocalPathFromUnc` (91–102) derive local paths from Get-SmbShare.Path; `Test-WindowsCim` (104–112) collapses every exception to false. DFSN folder enumeration and DFSR primary/referral selection (114–238) produce NamespacePath, Server, TargetPath, LocalPath, Role, State. Failed Windows detection becomes phase3-synology, not an access error. CIM queries are per target with no server cache.
* `Invoke-ChargebackWizard.ps1`, `Invoke-CollectStage`: groups authoritative map rows by literal Server, opens PSSession, writes collector under C:\ProgramData\ChargebackOne, sends all paths in one invocation, copies all remote drop CSVs. Server exceptions warn; only all-server failure throws. Credentials optionally differ from Discover/Merge. Local workspace/map configuration is file based.
* `Install-FsrmOwnerReport.ps1`, `Resolve-ExistingPath` (55–82): tries actual path, share-name guesses and C:/D:/E: substitutions. Preflight (154–168) throws for any missing path, losing all valid siblings. `Invoke-NtfsOwnerWalk` (84–147) loads recursive file arrays with SilentlyContinue, obtains owner ACLs, groups Owner|map path and exports Server,Folder,Owner,SID,Size,Files; unreadable items have no coverage accounting. Auto (170–190) selects FSRM on newer servers and unknown builds.
* Collector FSRM branch (192–362): feature installation, service starts, server-wide report settings, report deletion/recreation and Sunday 03:00 schedule; polls CSVs and falls back after 45 seconds without stopping the FSRM job. Copies can target the source file itself. These paths must not be shipped as executable V2 code.
* `Invoke-ChargebackMerge.ps1`: Get-MapObjects uses ConvertFrom-Json -InputObject for 5.1 arrays; allow-set is Server|LocalPath. Reads every CSV, guesses FSRM headings, strips non-digits from sizes, resolves AD per row without cache. Business Department comes from AD; output is not aggregated. AllocatedBytes incorrectly mirrors LogicalBytes. No RunId or provenance checks.

## Permissions and usable concepts

Reuse concepts: current-token WinRM, remote local metadata/ACL walk (no double hop), SMB Path lookup, SID-based optional AD lookup, PS 5.1 JSON loading. V2 is a separate rewrite of the pipeline with attribution; upstream code is not executed. Discover needs readable share Path, Collect needs remoting, traverse/list/read attributes/read permissions plus Modify on its own report directory. Local administrator is the upstream documented baseline, not a demonstrated least-privilege requirement. V2 does not enable backup privilege. Domain Admin, DFS rights, FSRM and AD writes are unnecessary. AD read is optional and must not control CSV Department.

## Concrete V2 changes

1. Strict three-column CSV is the sole authorization boundary. Preserve bytes/hash/original cells, require review for proposed corrections, fail closed for unresolved paths; no DFS enumeration or guessed drive mappings.
2. Cached canonical hosts, read-only SMB resolution and existence/reparse checks. Deduplicate identical physical paths; block cross-department duplicates and every parent/child overlap.
3. NTFS-only per-path outcomes, owner counts, metadata-only enumeration, explicit skips/partial status, bounded throughput and timeouts. Logical namespace bytes count hard-link directory entries; allocated/unique physical bytes are not claimed.
4. Immutable run snapshot, UUID and per-target artifacts, atomic writes and verified exact-file transport; no wildcard historic imports. Merge strictly validates schema, identity, provenance, counts and current run.
5. Portable PS 5.1 scripts, safe entry/menu, read-only prerequisites, offline tests, Chinese operations guide and checksummed ZIP. Production smoke acceptance remains customer Gate 5.

## Gate evidence / open issues

Gate 0 review complete. Baseline four scripts passed local parser inspection; this does not establish runtime correctness. Known deployment incidents in brief become named regression tests. Real SOH identity, DNS aliases/cluster behavior, WinRM, share rights, ACL coverage, performance, approved departments and full-volume overlaps remain PENDING. No production hosts contacted.
