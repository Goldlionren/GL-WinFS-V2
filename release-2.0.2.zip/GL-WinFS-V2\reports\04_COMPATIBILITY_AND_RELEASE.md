# Gate 4 — Windows PowerShell 5.1 and portable release

Local test runtime is actual Windows PowerShell 5.1 Desktop on Windows 11. Exact OS/runtime and per-case results are in test-results.json/csv. All production, test and build PowerShell sources are parser-checked with 5.1; no PS7-only syntax is required. This is not a Windows Server 2022 execution claim.

Development history preserved: iteration-01 had 35 PASS / 12 FAIL. Main real implementation defect was PS 5.1 binding `$null` to an empty string for File.Replace backup-path; corrected with NullString.Value. Two test-harness defects were fixed (empty parser-error property access and scalar ArgumentList splatting). iteration-02: 47/0; iteration-03: 55/0; iteration-04: 59/0. Subsequent final suite is test-results.

Runtime package uses an explicit file allowlist and excludes test/development dependencies. Build generates SHA256SUMS, release.zip and its hash. The clean extraction smoke test invokes only DryRun/offline validation/read-only local prerequisites and verifies every file checksum/parser. Verification results are in release-smoke.json. Full project ZIP is a separate handoff with source, tests, reports, reference archive and release.

Gate 4 status is determined by test-results and release-smoke, not this prose. Customer Windows Server 2022/WinRM/AD tests remain Gate 5 PENDING. No production test performed.
