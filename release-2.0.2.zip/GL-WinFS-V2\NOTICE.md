# Attribution and changes

Based on architectural review of GL-WinFS, https://github.com/maubhpe/GL-WinFS, commit `8b0c7c92ec385b8e936c548064b51d48c2b005cf`, copyright (c) 2026 maubhpe, MIT. Original MIT text is retained in LICENSE. This is an independent, unofficial SOH V2 derivative, not an HPE-supported product.

2026-11-12: replaced DFS discovery and FSRM collection with a customer CSV authorization boundary, read-only SMB mapping, bounded NTFS owner metadata collection, explicit errors, immutable run snapshots and Department reports. Upstream concepts are acknowledged; no original production scripts are invoked. Upstream baseline remains unchanged. See reports/00_UPSTREAM_REVIEW.md and CHANGELOG.md.

Customer-provided configuration files are included for this private handoff at the user's request. Do not publish them in a public repository. No credentials or collected SOH file metadata are included.
