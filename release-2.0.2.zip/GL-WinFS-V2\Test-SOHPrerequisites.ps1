#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$Workspace,
    [string[]]$RepresentativeServers=@('sohfs3','sohfs7','sohfs8.soh.com'),
    [switch]$CheckRemote
)
$ErrorActionPreference='Stop'
if (-not $Workspace) { $Workspace=Join-Path (Split-Path -Parent $PSScriptRoot) 'workspace' }
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$checks=New-Object 'Collections.Generic.List[object]'
$checks.Add([pscustomobject]@{Check='Identity';Status='INFO';Detail=$identity.Name})
$checks.Add([pscustomobject]@{Check='PowerShell';Status=$(if($PSVersionTable.PSVersion -ge [version]'5.1'){'PASS'}else{'FAIL'});Detail=$PSVersionTable.PSVersion.ToString()})
foreach($name in @('New-PSSession','Invoke-Command','Get-FileHash','Get-Acl')) {
    $checks.Add([pscustomobject]@{Check=$name;Status=$(if(Get-Command $name -ErrorAction SilentlyContinue){'PASS'}else{'FAIL'});Detail='Standard command availability; no configuration changed.'})
}
$checks.Add([pscustomobject]@{Check='ActiveDirectory';Status=$(if(Get-Module -ListAvailable ActiveDirectory){'AVAILABLE'}else{'OPTIONAL_ABSENT'});Detail='Only optional SID enrichment needs this module.'})
try {
    $ancestor=[IO.Path]::GetFullPath($Workspace)
    while(-not (Test-Path -LiteralPath $ancestor)){ $ancestor=Split-Path -Parent $ancestor; if(-not $ancestor){throw 'No existing ancestor.'} }
    $acl=Get-Acl -LiteralPath $ancestor -ErrorAction Stop
    $sids=@($identity.User.Value)+@($identity.Groups | ForEach-Object Value)
    $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]) | Where-Object { $sids -contains $_.IdentityReference.Value })
    $allow=0L;$deny=0L
    foreach($r in $rules){if($r.AccessControlType -eq 'Deny'){$deny=$deny -bor [long]$r.FileSystemRights}else{$allow=$allow -bor [long]$r.FileSystemRights}}
    $needed=[long][Security.AccessControl.FileSystemRights]::Modify
    $possible=(($allow -band $needed) -eq $needed -and ($deny -band $needed) -eq 0)
    $checks.Add([pscustomobject]@{Check='Workspace ACL (read only)';Status=$(if($possible){'ACL_SUGGESTS_MODIFY'}else{'REVIEW'});Detail="$ancestor; no file created. Conditional ACEs, token privileges, quotas and actual atomic-write ability require customer execution verification."})
} catch {$checks.Add([pscustomobject]@{Check='Workspace ACL';Status='FAIL';Detail=$_.Exception.Message})}
if($CheckRemote){
    foreach($server in $RepresentativeServers){
        $session=$null
        try{
            $null=Test-WSMan -ComputerName $server -ErrorAction Stop
            $session=New-PSSession -ComputerName $server -SessionOption (New-PSSessionOption -OpenTimeout 30000 -OperationTimeout 60000) -ErrorAction Stop
            $shares=@(Invoke-Command -Session $session -ScriptBlock { Get-SmbShare -ErrorAction Stop | Select-Object Name,Path } -ErrorAction Stop)
            $fileShares=@($shares | Where-Object Name -ine 'IPC$')
            $blank=@($fileShares | Where-Object { [string]::IsNullOrWhiteSpace($_.Path) }).Count
            $checks.Add([pscustomobject]@{Check="WinRM / Get-SmbShare.Path $server";Status=$(if($fileShares.Count -gt 0 -and $blank -eq 0){'PASS'}else{'REVIEW'});Detail=($shares | ConvertTo-Json -Compress)})
        }catch{$checks.Add([pscustomobject]@{Check="Remote $server";Status='FAIL';Detail=$_.Exception.Message})}
        finally{if($session){Remove-PSSession $session -ErrorAction SilentlyContinue}}
    }
}else{$checks.Add([pscustomobject]@{Check='Remote checks';Status='NOT_RUN';Detail='Use -CheckRemote only with customer approval. No remote connections made.'})}
$checks.ToArray()
if(@($checks | Where-Object Status -eq 'FAIL').Count){exit 1}
