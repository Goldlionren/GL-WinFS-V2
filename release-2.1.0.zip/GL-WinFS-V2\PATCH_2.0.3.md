# 2.0.3：8 台服务器并行、每任务每秒最多 1000 个条目

按客户本次指示，把入口 MaxConcurrency 可配置上限从 4 扩展为 8。下方运行命令显式使用 MaxConcurrency=8、MaxEntriesPerSecond=1000。未传参时仍保留低并发默认值；请使用本页完整命令。

这是最多 8 台不同物理服务器同时采集，每台服务器仍串行处理目录。同一台服务器有多个磁盘也不会同时启动多个任务。每个采集任务的速率上限是每秒 1000 个文件或目录条目，不是保证每秒完成 1000 个文件，也不是全局合计 1000。实际并发受剩余服务器数约束；共享底层存储或账号查询资源也可能限制收益。未改变逐条限速算法或 Owner/ACL 读取方式，没有声称已测得生产提速倍数。

磁盘队列阈值 2、120 秒无新心跳超时、300 秒无计数进展超时、停止请求最多等 5 秒、服务器隔离与 INCOMPLETE 报告机制继续生效。当前运行参数会记录到当前 RunId 的 watchdog-policy.json，包括并发、每服务器并发、条目速率与磁盘队列阈值。

## 客户服务器运行

先由操作员结束旧采集并确认旧远端执行退出，再使用新版；替换文件不能改变正在运行的旧作业。保留原 workspace、已修正 CSV、结果和隔离记录。将新 ZIP 解压到 `C:\Temp\SOH-V203`，得到 `C:\Temp\SOH-V203\GL-WinFS-V2`。

在现有 SOH\svc_HPEreport 的 Windows PowerShell 5.1 窗口，先校验：

```powershell
& 'C:\Temp\SOH-V203\GL-WinFS-V2\Verify-SOHPackage.ps1'
```

再运行（单行）：

```powershell
$runId=[guid]::NewGuid().ToString('D'); Write-Host "RunId: $runId"; & 'C:\Temp\SOH-V203\GL-WinFS-V2\Start-SOHReport.ps1' -Stage All -Execute -ApproveFullVolume -ResolveAD -CsvPath 'C:\SOHReporting\workspace\input\customer-targets.corrected.csv' -Workspace 'C:\SOHReporting\workspace' -RunId $runId -MaxConcurrency 8 -MaxEntriesPerSecond 1000 -MaxDiskQueueLength 2 -TimeoutSeconds 86400 -HeartbeatTimeoutSeconds 120 -NoProgressTimeoutSeconds 300
```

按提示输入本次新的完整 COLLECT 确认字符串。不要用 ZIP 内原始输入覆盖客户已修正 CSV。若某服务器出现 HOST_QUARANTINED，先按 2.0.2 说明核实旧执行退出；不要通过换 workspace 或批量删除记录绕过它。

另一个窗口查看日志（替换 UUID）：

```powershell
Get-Content -LiteralPath 'C:\SOHReporting\workspace\runs\<本次UUID>\collection-progress.log' -Tail 20 -Wait
```

观察各服务器文件数增量评估实际收益。报告最终仍按有效结果、校验和与完整性决定，不因提高限速而跳过 Owner、权限失败或未完成目录。

## 测试边界

测试证据见 reports/test-results.json/csv 和 reports/07_EIGHT_SERVER_PROFILE.md。离线调度模拟覆盖 10 台服务器、11 个目标，验证最多同时 8 个任务、同一服务器保持串行，以及每个请求收到 1000 条目/秒设置。真实 8 台服务器并行、共享存储负载和实际加速效果须在客户环境验证；本机未连接 SOH。原 2.0.0、2.0.1、2.0.2 目录及发布包保持原样。
