# 2.1.0：目录与部门容量汇总

客户明确确认：只要授权目录／Department 的文件数量和容量，不采集文件 Owner。此确认替代原任务书中默认逐文件 Owner 审计的要求。

## 采集变化

入口默认 CollectionMode=Summary。在各文件服务器本地枚举授权目录的文件元数据，累计 FileCount 与 LogicalBytes；不打开文件内容，不逐文件调用 Get-Acl、不读取 Owner SID、不解析 Owner 账号、不做 AD 增强。ResolveAD 即使误传，在 Summary 模式也不执行 AD 查询。原有 Owner 模式仅供显式选择和兼容历史运行，当前客户命令不启用。

精确的递归目录数量／大小仍需要枚举条目。汇总输出只有一行并不代表操作系统已经提供这个子目录的完整递归总数。此次省去的是 Owner/ACL、账号解析与逐文件 Owner 分组开销，不是跳过未扫描目录或使用估算值。

Summary 模式使用有界短时间窗口限速，减少逐条 1ms 等待。1000 条目/秒配置下，每个约 100ms 窗口最多处理 100 个条目；每窗口内部可以成批推进，不承诺任意瞬时区间都均匀，长 I/O 等待不积攒额外突发额度。文件和目录都计入条目。单次很长的底层调用仍受主控停滞检测；进度、压力阈值、并发与隔离机制沿用 2.0.2/2.0.3。

不逐文件保存路径清单，只保留目标级数量／字节汇总、错误路径和最近进度路径。计量是逻辑文件长度之和；硬链接按目录条目计数，不计为去重后的物理容量，不跟随 reparse/junction。

## 客户报告

根据客户提供的 chargeback-2026-09-11.csv 的 13 列顺序，生成 `workspace\runs\<RunId>\output\chargeback-YYYY-MM-DD.csv`。每个去重后的物理授权目标一行，重复别名不会重复收费。日期为 RunId 创建时的 UTC 日期，便于跨日重新 Merge 保持同名；实际目标开始／结束时间仍在 folder-report.csv。

| 列 | Summary 模式含义 |
| --- | --- |
| ScanDate | RunId 创建的 UTC 日期 |
| Source | Windows-NTFS-Summary，如实标明本次采集方式 |
| Server | 已验证的服务器身份名称 |
| SharePath | 已验证的服务器本地授权目录，原始 UNC 保留在 folder-report.csv |
| OwnerSID、SamAccountName、DisplayName | 留空：客户明确不采集 Owner |
| Department | 客户 CSV 的 Department（已确认来自 Business Owner） |
| BusinessUnit | 留空：没有独立业务单元映射，不假设等同 Department |
| FileCount | 已核验扫描的文件数；FAILED 留空，真正成功扫描的空目录为 0 |
| LogicalBytes | 已核验的逻辑字节数；FAILED 留空 |
| AllocatedBytes | 留空：未测量实际分配空间，不复制 LogicalBytes 冒充 |
| Unresolved | 成功为空；部分结果为 PARTIAL；失败为 FAILED。这里标记扫描完整性，不表示 AD 账号解析状态 |

同时提供 department-report.csv 的部门合计、server-report.csv、folder-report.csv、errors.csv 和 run-manifest.json。owner-detail.csv 保留兼容表头但没有明细行。PARTIAL 值只是已读部分，不能按完整账单使用；所有失败／部分结果都使 manifest 为 INCOMPLETE。主报表和各辅助 CSV 都列入 manifest SHA256。

客户样例中的 Source=Windows-FSRM-Owner、Owner 账号和 AllocatedBytes=LogicalBytes 仅是历史样例内容，不是本项目可以照抄或推定的事实。

## 升级与运行（单行命令）

先由操作员结束旧采集并确认远端执行退出。保留 workspace、现场已修正 CSV 和已有结果。新版用新 RunId，禁止在同一 RunId 中混用 Summary/Owner 结果；旧 RunId 的 Merge 仍按旧 Owner 口径处理。隔离记录跨 RunId 保留，不要为了重试而绕过退出核实。

将 ZIP 解压到 `C:\Temp\SOH-V210`，得到 `C:\Temp\SOH-V210\GL-WinFS-V2`。在 SOH\svc_HPEreport 的 Windows PowerShell 5.1 窗口校验：

```powershell
& 'C:\Temp\SOH-V210\GL-WinFS-V2\Verify-SOHPackage.ps1'
```

全量运行，明确采用 Summary、8 台服务器并行、每任务 1000 条目/秒：

```powershell
$runId=[guid]::NewGuid().ToString('D'); Write-Host "RunId: $runId"; & 'C:\Temp\SOH-V210\GL-WinFS-V2\Start-SOHReport.ps1' -Stage All -Execute -ApproveFullVolume -CollectionMode Summary -CsvPath 'C:\SOHReporting\workspace\input\customer-targets.corrected.csv' -Workspace 'C:\SOHReporting\workspace' -RunId $runId -MaxConcurrency 8 -MaxEntriesPerSecond 1000 -MaxDiskQueueLength 2 -TimeoutSeconds 86400 -HeartbeatTimeoutSeconds 120 -NoProgressTimeoutSeconds 300
```

输入新的完整 COLLECT 确认字符串。结束后先查看该 RunId 的 output\run-manifest.json 和 errors.csv，再交付 chargeback-日期.csv 与 department-report.csv。不要用包内原始样本替换客户现场已修正清单。

另一个窗口看进度（替换 UUID）：

```powershell
Get-Content -LiteralPath 'C:\SOHReporting\workspace\runs\<本次UUID>\collection-progress.log' -Tail 20 -Wait
```

## 验证边界

开发测试证明 Summary 路径不调用逐文件 Get-Acl/Owner 回调、不执行 AD 增强，计数与逻辑字节和测试目录一致；模板列顺序一致，失败／部分结果不会伪装成完整空目录。证据见 reports/test-results 与 reports/08_SUMMARY_REPORT.md。

未连接客户环境。真实扫描速度、实际 8 台服务器并发负载及长期全量完整性仍待客户验证；不能承诺固定提速倍数。扫描期间源目录可能变化，本报告不是某个瞬间的文件系统快照。原 2.0.x 项目和发布包保留不动。
