﻿# SOH GL-WinFS V2 交付报告

**2.1.0 更新说明：** 当前独立项目位于 `D:\AI\SOH\GL-WinFS-V2-2.1.0`，其 release\release.zip 是新运行包。默认无 Owner 的目录／部门 Summary 汇总，输出客户 13 列报表，见 PATCH_2.1.0.md 与 reports/08_SUMMARY_REPORT.md；当前测试以本目录 test-results 为准。以下为原 2.0.0 基线交付记录，原包仍保留，不代表客户当前运行已恢复。

开发日期：2026-11-12（Australia/Sydney）。上游 SHA：`8b0c7c92ec385b8e936c548064b51d48c2b005cf`；MIT 声明保留。原始上游目录未改动。本机无法连接客户环境，开发未尝试连接 SOH 服务器。

## 交付内容

* 完整独立项目：`D:\AI\SOH\GL-WinFS-V2\`
* 完整项目压缩包：`D:\AI\SOH\GL-WinFS-V2\GL-WinFS-V2-complete-project.zip`
* 可复制运行包：`D:\AI\SOH\GL-WinFS-V2\release\GL-WinFS-V2\`
* 运行包 ZIP：`D:\AI\SOH\GL-WinFS-V2\release\release.zip`
* 每个 ZIP 的 `.sha256` 与包内 `SHA256SUMS.txt`；使用 `Verify-SOHPackage.ps1` 验证。

完整项目含源码、可重复测试、构建脚本、每阶段审查与测试记录、上游原始参考归档及运行包。运行包不需 Codex/Git/Python/Node/Pester。复制到 Windows Server 2022 后按 README_OPERATOR.md 执行；开发测试不能替代客户环境测试。

## 完成功能

CSV 范围授权；严格解析/候选修复保留/批量三态校验；只读共享真实路径与主机标识解析；全盘独立审批；物理路径去重、跨部门与父子冲突阻止；远程本地 NTFS owner 元数据采集；按路径容错和明确覆盖状态；不跟随 reparse；硬链接按逻辑命名空间计量；并发、速率、磁盘队列、超时和取消；RunId 隔离、SHA256 与原子写入；Department 六份报表与可选 AD 审计增强；安全入口/菜单、只读前置检查、重试、升级回滚说明。

实际输入已读取 `SOH Reporting sources.csv`（58 行），按用户确认使用 Business Owner 作为 Department。原文件 SHA256=`1553B3209190B9F1AAC653200FACFAECBC5998C54034CCD80B747280CDBE5722`。三列输入、全占位模板、原路径、逐行映射与建议清单均已生成；不执行建议纠正。

## 测试与边界

Gate 0：上游四份脚本、全部相关文档、数据流与权限审查完成。

Gate 1–3：本机 Windows PowerShell 5.1 测试及 Mock/真实临时 NTFS 测试通过。最终逐项统计见 reports/test-results.json/csv；阶段问题见 01/02/03 报告。覆盖实际旧版故障形态，保留第一次失败记录及修复后的每次结果。

Gate 4：Windows PowerShell 5.1 静态/运行检查和发布包干净目录解压检验，以 reports/release-smoke.json 的实际结果为准。完整项目另有 complete-project-smoke.json（位于本地项目根 reports，生成于最终压缩后）。包内引用的上游只用于审查，不参与执行。

Gate 5：**PENDING，由客户复制后单独批准并执行一条小目录灰度。** Windows Server 2022 实际执行、SOH 服务账号权限、真实 WinRM/SMB/AD、性能计数器、生产数据量与取消后的远端进程终止均未实测，不声称通过。

实际清单离线验证：58 NEEDS_REVIEW，0 VALID；因尚无真实远端验证，此为正确阻止状态。7 个已知业务/纠错事项：SOH-001、002、009、012、043、050、054。其余行仍需客户验证共享路径、目录存在及部门归属。全盘与共享重叠未做假设。

## 客户部署顺序

1. 把完整项目/运行包复制到客户环境，先核验 SHA256；保留原包和原始 CSV。
2. 以 `SOH\svc_HPEreport` 打开 Windows PowerShell 5.1，执行只读前置检查；确认工作目录写权限、WinRM、SMB Path、NTFS 和性能计数器读取。
3. 确认建议纠错、Department 和授权范围；先执行 Validate。不要直接编辑验证 JSON。
4. 客户批准一行小目录 pilot CSV；使用低速率 Collect -Execute，核对目标数并输入 RunId+SourceSHA256 二次确认。
5. 核验六份报表、manifest 哈希、文件数/逻辑字节/Owner、业务负载及未覆盖项。填写 CUSTOMER_ACCEPTANCE.md 后才决定扩大范围。
6. 升级保留旧目录、CSV、workspace；新目录灰度。回滚停止新运行并切回旧入口/原 workspace，无服务器配置迁移。

服务账号不需 Domain Admin；需已批准 WinRM endpoint、CIM/SMB Path/卷/性能计数器读取、源树元数据与 ACL 读取，以及自有报告目录修改权限。最小委派/JEA 仍待客户确认。源数据无写权限要求；无 FSRM/服务/计划任务/Owner/ACL 修改代码。

## 明确限制

不自动保留重叠父子目录并拆分容量；需客户提供非重叠范围。CNAME/集群身份不一致和挂载/reparse 根路径保守拒绝。AllocatedBytes 未测量而留空；硬链接按命名空间项计数，扫描不是一致性快照。特殊真实拼写/前后空白名称目前需规则审查更新，不能绕过 NEEDS_REVIEW。磁盘压力采样是近似负载控制；系统调用或硬取消不保证立即终止。大量错误时内存消耗仍需客户容量测试。所有报告保留“客户验收待完成”状态，不是正式已验收 Chargeback。
