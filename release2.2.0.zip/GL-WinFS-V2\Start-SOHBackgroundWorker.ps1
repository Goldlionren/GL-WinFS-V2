#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)][string]$ConfigPath)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
Import-Module (Join-Path $PSScriptRoot 'src\SOH.psm1') -Force -DisableNameChecking
$config=Read-SOHJson $ConfigPath
if($config.SchemaVersion -ne 'SOH.Launch.1'){throw 'Invalid launch schema.'}
Assert-SOHRunId $config.RunId
$workspacePath=Assert-SOHLocalPath ([IO.Path]::GetFullPath($config.Workspace));Assert-SOHNoReparse $workspacePath
$attempt=[IO.Path]::GetFullPath($config.AttemptDirectory)
$prefix=Join-Path $workspacePath ('runs\'+$config.RunId+'\attempts\')
if(-not $attempt.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFullPath($ConfigPath) -ine (Join-Path $attempt 'launch.json')){throw 'Launch paths escaped run attempts directory.'}
Assert-SOHNoReparse $attempt
$stateFile=Join-Path $attempt 'worker-status.json'
$state=[pscustomobject]@{Status='RUNNING';RunId=$config.RunId;ProcessId=$PID;Version='2.2.0';StartedUtc=[datetime]::UtcNow.ToString('o');EndedUtc='';ExitCode=$null;SuccessfulTargets=$null;PartialTargets=$null;FailedTargets=$null;Output=(Join-Path $workspacePath ('runs\'+$config.RunId+'\output'));Message=''}
Write-SOHJson $stateFile $state
$exitCode=1
try {
    & (Join-Path $PSScriptRoot 'Verify-SOHPackage.ps1') | Out-Host
    $rate=[int]$config.MaxEntriesPerSecond;if($rate -lt 1 -or $rate -gt 10000){throw 'Invalid rate.'}
    $m=Invoke-SOHResumeFailed -Workspace $workspacePath -RunId $config.RunId -CsvPath $config.CsvPath -SourceRoot (Join-Path $PSScriptRoot 'src') -AttemptDirectory $attempt -MaxEntriesPerSecond $rate
    $state.Status=$m.Status;$state.SuccessfulTargets=$m.SuccessfulTargets;$state.PartialTargets=$m.PartialTargets;$state.FailedTargets=$m.FailedTargets
    $exitCode=if($m.Status -eq 'COMPLETE'){0}else{2}
}catch{$state.Status='ERROR';$state.Message=$_.Exception.Message;Write-Error $_ -ErrorAction Continue}
finally{$state.ExitCode=$exitCode;$state.EndedUtc=[datetime]::UtcNow.ToString('o');Write-SOHJson $stateFile $state}
exit $exitCode
