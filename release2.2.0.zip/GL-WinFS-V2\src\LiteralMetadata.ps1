﻿function Initialize-SOHLiteralMetadata {
    if('SOHLiteralV220.Native' -as [type]){return}
    # Built-in .NET compiler and Windows read-only APIs; no downloads or server configuration.
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
namespace SOHLiteralV220 {
    public sealed class Entry {
        public string FullName { get; set; }
        public FileAttributes Attributes { get; set; }
        public long Length { get; set; }
    }
    public sealed class ScanError {
        public string Path { get; set; }
        public string Code { get; set; }
        public string Message { get; set; }
    }
    public sealed class Batch {
        public long Entries, Files, Bytes, SkippedFiles, SkippedDirectories;
        public bool Finished;
        public string LastPath="", EnumerationError="";
        public List<string> Directories=new List<string>();
        public List<ScanError> Errors=new List<ScanError>();
    }
    public sealed class Cursor : IDisposable {
        readonly IEnumerator<Entry> iterator;
        public Cursor(IEnumerator<Entry> value) { iterator=value; }
        public bool MoveNext() { return iterator.MoveNext(); }
        public Entry Current { get { return iterator.Current; } }
        public Batch ReadBatch(int maximum) {
            if(maximum<1 || maximum>4096) throw new ArgumentOutOfRangeException("maximum");
            Batch b=new Batch();
            try {
                while(b.Entries<maximum) {
                    if(!iterator.MoveNext()){b.Finished=true;break;}
                    Entry e=iterator.Current;b.Entries++;b.LastPath=e.FullName;
                    bool directory=(e.Attributes&FileAttributes.Directory)!=0;
                    if((e.Attributes&FileAttributes.ReparsePoint)!=0){
                        if(directory)b.SkippedDirectories++;else b.SkippedFiles++;
                        b.Errors.Add(new ScanError {Path=e.FullName,Code="REPARSE_SKIPPED",Message="No reparse points followed; excluded subtree size/file count unknown."});
                    }else if(directory){b.Directories.Add(e.FullName);}
                    else { checked { b.Bytes+=e.Length;b.Files++; } }
                }
            }catch(Exception ex){b.EnumerationError=ex.Message;b.Finished=true;}
            return b;
        }
        public void Dispose() { iterator.Dispose(); }
    }
    public static class Native {
        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
        struct FindData {
            public uint Attributes;
            public System.Runtime.InteropServices.ComTypes.FILETIME CreationTime;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastAccessTime;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWriteTime;
            public uint SizeHigh, SizeLow, Reserved0, Reserved1;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=260)] public string Name;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=14)] public string AlternateName;
        }
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        static extern IntPtr FindFirstFileExW(string name, int level, out FindData data, int search, IntPtr filter, uint flags);
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)] static extern bool FindNextFileW(IntPtr handle, out FindData data);
        [DllImport("kernel32.dll", SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)] static extern bool FindClose(IntPtr handle);
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        static extern uint GetFileAttributesW(string name);
        public static string ValidateLocalPath(string path) {
            if(path==null || path.Length<3 || !((path[0]>='A'&&path[0]<='Z')||(path[0]>='a'&&path[0]<='z')) || path[1]!=':' || path[2]!='\\')
                throw new ArgumentException("Expected literal local drive path.");
            for(int i=3;i<path.Length;i++) {
                char c=path[i];
                if(c<32 || "*?<>|\":/".IndexOf(c)>=0) throw new ArgumentException("Invalid literal path character.");
            }
            if(path.Length>3) foreach(string part in path.Substring(3).Split('\\'))
                if(part.Length==0 || part=="." || part=="..") throw new ArgumentException("Invalid literal path component.");
            // Preserve %, trailing spaces/dots and Unicode exactly. Never expand variables or normalize.
            return path;
        }
        static string Extended(string path) { return @"\\?\"+ValidateLocalPath(path); }
        public static FileAttributes Attributes(string path) {
            uint value=GetFileAttributesW(Extended(path));
            if(value==0xffffffff) throw new Win32Exception(Marshal.GetLastWin32Error(),"Cannot read literal attributes: "+path);
            return (FileAttributes)value;
        }
        public static Cursor OpenDirectory(string directory) { return new Cursor(Enumerate(directory).GetEnumerator()); }
        public static IEnumerable<Entry> Enumerate(string directory) {
            string prefix=directory.EndsWith("\\",StringComparison.Ordinal)?directory:directory+"\\";
            FindData data;
            IntPtr handle=FindFirstFileExW(Extended(directory)+(directory.EndsWith("\\",StringComparison.Ordinal)?"*":"\\*"),1,out data,0,IntPtr.Zero,2);
            if(handle==new IntPtr(-1)) {
                int error=Marshal.GetLastWin32Error();
                if(error==2) yield break; // Empty directory; other errors must remain visible.
                throw new Win32Exception(error,"Cannot enumerate literal directory: "+directory);
            }
            try {
                while(true) {
                    if(data.Name!="." && data.Name!="..") {
                        if(data.SizeHigh>0x7fffffff) throw new IOException("File length exceeds Int64.");
                        yield return new Entry {FullName=prefix+data.Name,Attributes=(FileAttributes)data.Attributes,Length=((long)data.SizeHigh<<32)|data.SizeLow};
                    }
                    if(!FindNextFileW(handle,out data)) {
                        int error=Marshal.GetLastWin32Error();
                        if(error!=18) throw new Win32Exception(error,"Literal directory enumeration interrupted: "+directory);
                        break;
                    }
                }
            } finally { FindClose(handle); }
        }
    }
}
'@ -ErrorAction Stop
}
function Assert-SOHLiteralScanPath([string]$Path,[string]$AuthorizedRoot) {
    Initialize-SOHLiteralMetadata
    [void][SOHLiteralV220.Native]::ValidateLocalPath($Path)
    if(-not $Path.Equals($AuthorizedRoot,[StringComparison]::OrdinalIgnoreCase) -and -not (Test-SOHAncestor $AuthorizedRoot $Path)){throw 'Enumerated path escaped authorized root.'}
}
function Assert-SOHLiteralNoReparse([string]$Path,[string]$AuthorizedRoot) {
    Assert-SOHLiteralScanPath $Path $AuthorizedRoot
    $current=$Path.Substring(0,3)
    $parts=@('')
    if($Path.Length -gt 3){$parts+=@($Path.Substring(3) -split '\\')}
    foreach($part in $parts){
        if($part){$current=$current.TrimEnd('\')+'\'+$part}
        $attrs=[SOHLiteralV220.Native]::Attributes($current)
        if(($attrs -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw ('Reparse path prohibited: '+$current)}
        if(($attrs -band [IO.FileAttributes]::Directory) -eq 0){throw ('Not a literal directory: '+$current)}
    }
}
