#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)][string]$RunId,[string]$Workspace='C:\SOHReporting\workspace')
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'src\SOH.psm1') -Force -DisableNameChecking
Assert-SOHRunId $RunId
$runDir=Join-Path $Workspace ('runs\'+$RunId)
$launch=Read-SOHJson (Join-Path $runDir 'latest-launch.json')
$state=if(Test-Path -LiteralPath $launch.StatusFile){Read-SOHJson $launch.StatusFile}else{[pscustomobject]@{Status='STARTING';ProcessId=$launch.ProcessId}}
if($state.Status -eq 'RUNNING'){
    $p=Get-Process -Id $state.ProcessId -ErrorAction SilentlyContinue
    if(-not $p -or [Math]::Abs(($p.StartTime.ToUniversalTime()-[datetime]::Parse($state.StartedUtc).ToUniversalTime()).TotalSeconds) -gt 60){$state.Status='WORKER_EXITED_WITHOUT_FINAL_STATUS'}
}
$state | Format-List
$plan=Join-Path $launch.AttemptDirectory 'recovery-plan.json'
if(Test-Path -LiteralPath $plan){$r=Read-SOHJson $plan;foreach($id in $r.TargetIDs){& (Join-Path $PSScriptRoot 'Get-SOHRunStatus.ps1') -Workspace $Workspace -RunId $RunId -TargetID $id | Select-Object ID,Status,Phase,ObservedFileCount,ObservedLogicalBytes,UpdatedUtc,LastObservedPath | Format-List}}
if($state.Status -eq 'ERROR'){Get-Content -LiteralPath (Join-Path $launch.AttemptDirectory 'worker.stderr.log') -Tail 10}
