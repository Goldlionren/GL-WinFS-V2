﻿function New-SOHProgressState([string]$Path,[string]$RunId,$Target) {
    $state=[pscustomobject][ordered]@{SchemaVersion='SOH.Progress.2';Version=$script:SOHVersion;RunId=$RunId;SourceID='';PhysicalKey='';Server=$env:COMPUTERNAME;ProcessId=$PID;Status='RUNNING';ExpectedOutcome='';Phase='STARTING';UpdatedUtc='';LastFileUtc='';ElapsedSeconds=0;ObservedEntries=0L;FileCount=0L;LogicalBytes=0L;DirectoriesVisited=0L;ErrorCount=0;SkippedFiles=0L;SkippedDirectories=0L;LastObservedPath='';DiskQueue=$null;DiskQueueWaitSeconds=0.0;Message=''}
    if($Target){$state.SourceID=$Target.ID;$state.PhysicalKey=$Target.PhysicalKey;$state.Server=$Target.Server;$state.LastObservedPath=$Target.LocalPath}
    [pscustomobject]@{Path=$Path;LastPublishedUtc=[datetime]::MinValue;State=$state}
}
function Publish-SOHProgress($Progress,[string]$Phase,[string]$Path,[switch]$Force) {
    if(-not $Progress){return}
    $Progress.State.Phase=$Phase
    if($Path){$Progress.State.LastObservedPath=$Path}
    $now=[datetime]::UtcNow
    if(-not $Force -and ($now-$Progress.LastPublishedUtc).TotalSeconds -lt 5){return}
    $Progress.State.UpdatedUtc=$now.ToString('o')
    if($Progress.Path){Write-SOHJson $Progress.Path $Progress.State}
    # Progress is a distinct PowerShell stream; never pollute the final result envelope.
    Write-Progress -Id 91 -Activity 'SOH_COLLECTOR_HEARTBEAT' -Status (ConvertTo-Json -InputObject $Progress.State -Compress -Depth 5) -PercentComplete -1
    $Progress.LastPublishedUtc=$now
}
function Wait-SOHDiskPressure($Watch,[int]$TimeoutSeconds,[string]$Drive,[int]$MaxDiskQueueLength,[scriptblock]$PressureProbe,$Progress=$null) {
    if($MaxDiskQueueLength -le 0){return}
    $wasWaiting=$false
    do {
        if($Watch.Elapsed.TotalSeconds -ge $TimeoutSeconds){throw 'TIMEOUT: waiting for disk I/O pressure to fall.'}
        if($Progress){$Progress.State.ElapsedSeconds=$Watch.Elapsed.TotalSeconds}
        Publish-SOHProgress $Progress 'QUERY_DISK_PRESSURE' '' -Force:($Progress -and $null -eq $Progress.State.DiskQueue)
        try {
            if($PressureProbe){$queue=& $PressureProbe $Drive}
            else{
                # Customer observed an empty filtered query although the unfiltered D: instance exists.
                # Enumerate the small counter instance set, then match exactly in PowerShell.
                $queryTimeout=[int][Math]::Max(1,[Math]::Min(15,[Math]::Ceiling($TimeoutSeconds-$Watch.Elapsed.TotalSeconds)))
                $counter=@(Get-CimInstance -ClassName Win32_PerfFormattedData_PerfDisk_LogicalDisk -OperationTimeoutSec $queryTimeout -ErrorAction Stop | Where-Object { $_.Name -ieq $Drive })
                if($counter.Count -ne 1){throw 'Disk queue instance missing/ambiguous; cannot enforce I/O pressure limit.'}
                $queue=$counter[0].CurrentDiskQueueLength
            }
            if($null -eq $queue -or [double]$queue -lt 0){throw 'Invalid disk queue counter.'}
        } catch {throw ('CONTROL_GATE_FAILED: '+$_.Exception.Message)}
        if($Progress){$Progress.State.DiskQueue=[double]$queue}
        if([double]$queue -le $MaxDiskQueueLength){return}
        Publish-SOHProgress $Progress 'WAITING_DISK_PRESSURE' '' -Force:(-not $wasWaiting)
        $wasWaiting=$true
        $waitStart=$Watch.Elapsed.TotalSeconds
        Start-Sleep -Milliseconds 200
        if($Progress){$Progress.State.DiskQueueWaitSeconds += $Watch.Elapsed.TotalSeconds-$waitStart}
    }while($true)
}
function Wait-SOHSummaryRateWindow($Watch,$RateWindow,[int]$MaxEntriesPerSecond) {
    if($MaxEntriesPerSecond -le 0){return}
    $windowMs=[Math]::Max(100.0,1000.0/$MaxEntriesPerSecond)
    $capacity=[int][Math]::Max(1,[Math]::Floor($MaxEntriesPerSecond/10.0))
    $now=$Watch.Elapsed.TotalMilliseconds
    if(($now-$RateWindow.StartedMs) -ge $windowMs){$RateWindow.StartedMs=$now;$RateWindow.Count=0}
    if($RateWindow.Count -ge $capacity){
        $delay=$windowMs-($now-$RateWindow.StartedMs)
        if($delay -gt 0){Start-Sleep -Milliseconds ([int][Math]::Ceiling($delay))}
        # Reset from actual time; long I/O waits cannot accumulate burst credit.
        $RateWindow.StartedMs=$Watch.Elapsed.TotalMilliseconds;$RateWindow.Count=0
    }
    $RateWindow.Count++
}
function Invoke-SOHFastSummary {
    param([string]$LocalPath,[int]$TimeoutSeconds,[int]$MaxEntriesPerSecond,[int]$MaxDiskQueueLength,$Progress)
    $started=[datetime]::UtcNow;$watch=[Diagnostics.Stopwatch]::StartNew()
    $files=0L;$bytes=0L;$seen=0L;$skippedFiles=0L;$skippedDirs=0L;$status='SUCCESS';$batchCalls=0L
    $errors=New-Object 'Collections.Generic.List[object]'
    $batchSize=128
    if($MaxEntriesPerSecond -gt 0){$batchSize=[int][Math]::Max(1,[Math]::Min(128,[Math]::Floor($MaxEntriesPerSecond/10.0)))}
    try {
        $LocalPath=Assert-SOHLocalPath $LocalPath
        Assert-SOHNoReparse $LocalPath
        if(-not (Test-Path -LiteralPath $LocalPath -PathType Container -ErrorAction Stop)){throw 'Target is not an existing directory.'}
        Wait-SOHDiskPressure $watch $TimeoutSeconds $LocalPath.Substring(0,2) $MaxDiskQueueLength $null $Progress
        $nextPressure=$watch.Elapsed.TotalSeconds+5
        $stack=New-Object 'Collections.Generic.Stack[string]';$stack.Push($LocalPath)
        while($stack.Count){
            $dir=$stack.Pop();$cursor=$null
            try {
                if($watch.Elapsed.TotalSeconds -ge $TimeoutSeconds){throw 'TIMEOUT: metadata walk deadline reached.'}
                if($Progress){$Progress.State.DirectoriesVisited++}
                Publish-SOHProgress $Progress 'ENUMERATING_DIRECTORY' $dir
                Assert-SOHLiteralNoReparse $dir $LocalPath
                $cursor=[SOHLiteralV220.Native]::OpenDirectory($dir)
                do {
                    if($watch.Elapsed.TotalSeconds -ge $TimeoutSeconds){throw 'TIMEOUT: metadata walk deadline reached.'}
                    if($watch.Elapsed.TotalSeconds -ge $nextPressure){
                        Wait-SOHDiskPressure $watch $TimeoutSeconds $LocalPath.Substring(0,2) $MaxDiskQueueLength $null $Progress
                        $nextPressure=$watch.Elapsed.TotalSeconds+5
                    }
                    $batchStart=$watch.Elapsed.TotalMilliseconds
                    # All per-file classification/counting stays in compiled code. No file contents or ACLs.
                    $batch=$cursor.ReadBatch($batchSize);$batchCalls++
                    $newBytes=[decimal]$bytes+$batch.Bytes;$newFiles=[decimal]$files+$batch.Files
                    if($newBytes -gt [long]::MaxValue -or $newFiles -gt [long]::MaxValue){throw 'CONTROL_GATE_FAILED: Summary total overflow.'}
                    $bytes=[long]$newBytes;$files=[long]$newFiles;$seen+=$batch.Entries
                    $skippedFiles+=$batch.SkippedFiles;$skippedDirs+=$batch.SkippedDirectories
                    foreach($child in $batch.Directories){$stack.Push($child)}
                    foreach($err in $batch.Errors){$errors.Add([pscustomobject]@{Path=$err.Path;Code=$err.Code;Message=$err.Message})}
                    if($batch.EnumerationError){$skippedDirs++;$errors.Add([pscustomobject]@{Path=$dir;Code='DIRECTORY_UNREADABLE';Message=$batch.EnumerationError})}
                    if($Progress){
                        $Progress.State.FileCount=$files;$Progress.State.LogicalBytes=$bytes;$Progress.State.ObservedEntries=$seen
                        $Progress.State.ErrorCount=$errors.Count;$Progress.State.SkippedFiles=$skippedFiles;$Progress.State.SkippedDirectories=$skippedDirs;$Progress.State.ElapsedSeconds=$watch.Elapsed.TotalSeconds
                        if($batch.Files -gt 0){$Progress.State.LastFileUtc=[datetime]::UtcNow.ToString('o')}
                    }
                    Publish-SOHProgress $Progress 'SCANNING_DIRECTORY' $dir
                    if($MaxEntriesPerSecond -gt 0 -and $batch.Entries -gt 0){
                        $delay=($batch.Entries*1000.0/$MaxEntriesPerSecond)-($watch.Elapsed.TotalMilliseconds-$batchStart)
                        if($delay -gt 0){Start-Sleep -Milliseconds ([int][Math]::Ceiling($delay))}
                    }
                }while(-not $batch.Finished)
            }catch{
                $skippedDirs++;$errors.Add([pscustomobject]@{Path=$dir;Code='DIRECTORY_UNREADABLE';Message=$_.Exception.Message})
                if($_.Exception.Message -match 'TIMEOUT:|CONTROL_GATE_FAILED:'){throw}
            }finally{if($cursor){$cursor.Dispose()}}
        }
    }catch{$status='FAILED';$errors.Add([pscustomobject]@{Path=$LocalPath;Code='WALK_ABORTED';Message=$_.Exception.Message})}
    finally{$watch.Stop()}
    if(($status -eq 'FAILED' -and $seen -gt 0) -or ($status -eq 'SUCCESS' -and $errors.Count -gt 0)){$status='PARTIAL'}
    if($Progress){
        $Progress.State.Status='WALK_FINISHED';$Progress.State.ExpectedOutcome=$status;$Progress.State.ErrorCount=$errors.Count
        $Progress.State.SkippedFiles=$skippedFiles;$Progress.State.SkippedDirectories=$skippedDirs;$Progress.State.ElapsedSeconds=$watch.Elapsed.TotalSeconds
        if($errors.Count){$Progress.State.Message=$errors[$errors.Count-1].Message}
        Publish-SOHProgress $Progress 'WALK_FINISHED' $LocalPath -Force
    }
    $owners=@();if($files -gt 0){$owners=@([pscustomobject]@{Owner='';OwnerSID='';FileCount=$files;LogicalBytes=$bytes})}
    [pscustomobject]@{Status=$status;StartedUtc=$started.ToString('o');EndedUtc=[datetime]::UtcNow.ToString('o');ElapsedSeconds=$watch.Elapsed.TotalSeconds;FileCount=$files;LogicalBytes=$bytes;AllocatedBytes=$null;SkippedFiles=$skippedFiles;SkippedDirectories=$skippedDirs;ErrorCount=$errors.Count;EntriesObserved=$seen;Owners=$owners;Errors=@($errors.ToArray());Engine='NativeBatchSummary';NativeBatchCalls=$batchCalls;Measurement='Logical namespace bytes; each hard-link directory entry counted; no allocated/unique-physical-byte claim.'}
}
function Invoke-SOHNtfsWalk {
    param([string]$LocalPath,[int]$TimeoutSeconds=3600,[int]$MaxEntriesPerSecond=200,[int]$MaxDiskQueueLength=0,[scriptblock]$ListDirectory,[scriptblock]$ReadOwner,[scriptblock]$PressureProbe,$Progress=$null,[switch]$SkipOwner)
    if($SkipOwner -and -not $ListDirectory -and -not $ReadOwner -and -not $PressureProbe){return Invoke-SOHFastSummary $LocalPath $TimeoutSeconds $MaxEntriesPerSecond $MaxDiskQueueLength $Progress}
    $started=[datetime]::UtcNow; $watch=[Diagnostics.Stopwatch]::StartNew()
    $owners=@{}; $errors=New-Object 'Collections.Generic.List[object]'
    $skippedFiles=0L; $skippedDirs=0L; $seen=0L; $files=0L; $bytes=0L; $status='SUCCESS'
    try {
        Publish-SOHProgress $Progress 'VALIDATING_ROOT' $LocalPath -Force
        $LocalPath=Assert-SOHLocalPath $LocalPath
        Assert-SOHNoReparse $LocalPath
        if (-not (Test-Path -LiteralPath $LocalPath -PathType Container -ErrorAction Stop)) { throw 'Target is not an existing directory.' }
        Wait-SOHDiskPressure $watch $TimeoutSeconds $LocalPath.Substring(0,2) $MaxDiskQueueLength $PressureProbe $Progress
        $nextPressureProbe=$watch.Elapsed.TotalSeconds+1
        $nextEntryDue=$watch.Elapsed.TotalMilliseconds
        $rateWindow=[pscustomobject]@{StartedMs=$watch.Elapsed.TotalMilliseconds;Count=0}
        $stack=New-Object 'Collections.Generic.Stack[string]'; $stack.Push($LocalPath)
        while ($stack.Count) {
            if ($watch.Elapsed.TotalSeconds -ge $TimeoutSeconds) { throw 'TIMEOUT: metadata walk deadline reached.' }
            $dir=$stack.Pop()
            try {
                if($Progress){$Progress.State.DirectoriesVisited++;$Progress.State.ElapsedSeconds=$watch.Elapsed.TotalSeconds}
                Publish-SOHProgress $Progress 'ENUMERATING_DIRECTORY' $dir
                if($SkipOwner){Assert-SOHLiteralNoReparse $dir $LocalPath}else{Assert-SOHNoReparse $dir}
                if ($ListDirectory) { $enumerator=(@(& $ListDirectory $dir)).GetEnumerator() }
                elseif($SkipOwner){$enumerator=[SOHLiteralV220.Native]::OpenDirectory($dir)}
                else { $enumerator=(New-Object IO.DirectoryInfo($dir)).EnumerateFileSystemInfos().GetEnumerator() }
                try {
                    while ($enumerator.MoveNext()) {
                        if ($watch.Elapsed.TotalSeconds -ge $TimeoutSeconds) { throw 'TIMEOUT: metadata walk deadline reached.' }
                        if($watch.Elapsed.TotalSeconds -ge $nextPressureProbe){
                            Wait-SOHDiskPressure $watch $TimeoutSeconds $LocalPath.Substring(0,2) $MaxDiskQueueLength $PressureProbe $Progress
                            $nextPressureProbe=$watch.Elapsed.TotalSeconds+1
                        }
                        $f=$enumerator.Current; $seen++
                        if($SkipOwner -and $ListDirectory){Assert-SOHLiteralScanPath $f.FullName $LocalPath}
                        if($Progress){$Progress.State.ObservedEntries=$seen;$Progress.State.ElapsedSeconds=$watch.Elapsed.TotalSeconds;$Progress.State.ErrorCount=$errors.Count;$Progress.State.SkippedFiles=$skippedFiles;$Progress.State.SkippedDirectories=$skippedDirs}
                        Publish-SOHProgress $Progress 'READING_METADATA' $f.FullName
                        if($SkipOwner){Wait-SOHSummaryRateWindow $watch $rateWindow $MaxEntriesPerSecond}
                        elseif ($MaxEntriesPerSecond -gt 0) {
                            $delay=$nextEntryDue - $watch.Elapsed.TotalMilliseconds
                            if ($delay -gt 0) { Start-Sleep -Milliseconds ([int][Math]::Min($delay,1000)) }
                            # Do not accumulate burst credit while waiting on I/O or backpressure.
                            $nextEntryDue=[Math]::Max($watch.Elapsed.TotalMilliseconds,$nextEntryDue)+(1000.0/$MaxEntriesPerSecond)
                        }
                        try {
                            $isDir=($f.Attributes -band [IO.FileAttributes]::Directory) -ne 0
                            if (($f.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                                if($isDir){$skippedDirs++}else{$skippedFiles++}
                                $errors.Add([pscustomobject]@{Path=$f.FullName;Code='REPARSE_SKIPPED';Message='No reparse points followed; excluded subtree size/file count unknown.'}); continue
                            }
                            if ($isDir) { $stack.Push($f.FullName); continue }
                            # Length and owner metadata only. Never open file content.
                            $size=[long]$f.Length; $owner=''; $sid=''
                            if(-not $SkipOwner){
                              $owner='UNKNOWN'
                              try {
                                Publish-SOHProgress $Progress 'READING_OWNER_ACL' $f.FullName
                                if ($ReadOwner) { $security=& $ReadOwner $f; $owner=$security.Owner; $sid=$security.SID }
                                else {
                                    $acl=Get-Acl -LiteralPath $f.FullName -ErrorAction Stop
                                    $sid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
                                    $owner=[string]$acl.Owner
                                }
                              } catch { $errors.Add([pscustomobject]@{Path=$f.FullName;Code='ACL_UNREADABLE';Message=$_.Exception.Message}) }
                            }
                            if(-not $SkipOwner){
                                $key=$sid + '|' + $owner
                                if (-not $owners.ContainsKey($key)) { $owners[$key]=[pscustomobject]@{Owner=$owner;OwnerSID=$sid;FileCount=0L;LogicalBytes=0L} }
                                $owners[$key].FileCount++; $owners[$key].LogicalBytes += $size
                            }
                            $files++; $bytes += $size
                            if($Progress){$Progress.State.FileCount=$files;$Progress.State.LogicalBytes=$bytes;$Progress.State.LastFileUtc=[datetime]::UtcNow.ToString('o')}
                        } catch {
                            $skippedFiles++; $errors.Add([pscustomobject]@{Path=$f.FullName;Code='METADATA_UNREADABLE';Message=$_.Exception.Message})
                        }
                    }
                } finally { if ($enumerator -is [IDisposable]) { $enumerator.Dispose() } }
            } catch {
                $skippedDirs++; $errors.Add([pscustomobject]@{Path=$dir;Code='DIRECTORY_UNREADABLE';Message=$_.Exception.Message})
                if ($_.Exception.Message -match 'TIMEOUT:|CONTROL_GATE_FAILED:') { throw }
            }
        }
    } catch {
        $status='FAILED'
        $errors.Add([pscustomobject]@{Path=$LocalPath;Code='WALK_ABORTED';Message=$_.Exception.Message})
    } finally { $watch.Stop() }
    if ($status -eq 'FAILED' -and $seen -gt 0) { $status='PARTIAL' }
    if ($status -eq 'SUCCESS' -and $errors.Count -gt 0) { $status='PARTIAL' }
    if($SkipOwner -and $files -gt 0){$owners['|']=[pscustomobject]@{Owner='';OwnerSID='';FileCount=$files;LogicalBytes=$bytes}}
    if($Progress){
        $Progress.State.Status='WALK_FINISHED';$Progress.State.ExpectedOutcome=$status;$Progress.State.FileCount=$files;$Progress.State.LogicalBytes=$bytes;$Progress.State.ObservedEntries=$seen;$Progress.State.ErrorCount=$errors.Count;$Progress.State.SkippedFiles=$skippedFiles;$Progress.State.SkippedDirectories=$skippedDirs;$Progress.State.ElapsedSeconds=$watch.Elapsed.TotalSeconds
        if($errors.Count){$Progress.State.Message=$errors[$errors.Count-1].Message}
        Publish-SOHProgress $Progress 'WALK_FINISHED' $LocalPath -Force
    }
    [pscustomobject]@{ Status=$status;StartedUtc=$started.ToString('o');EndedUtc=[datetime]::UtcNow.ToString('o');ElapsedSeconds=$watch.Elapsed.TotalSeconds;FileCount=$files;LogicalBytes=$bytes;AllocatedBytes=$null;SkippedFiles=$skippedFiles;SkippedDirectories=$skippedDirs;ErrorCount=$errors.Count;EntriesObserved=$seen;Owners=@($owners.Values | Sort-Object OwnerSID,Owner);Errors=@($errors.ToArray());Measurement='Logical namespace bytes; each hard-link directory entry counted; no allocated/unique-physical-byte claim.' }
}
function Invoke-SOHRemoteCollect($Request) {
    $ErrorActionPreference='Stop'
    $ProgressPreference='Continue'
    $t=$Request.Target
    $mode=Get-SOHCollectionMode $Request
    $collectorSchema=if($mode -eq 'Summary'){'SOH.Collector.Summary.2'}else{'SOH.Collector.2'}
    Assert-SOHRunId $Request.RunId
    $remoteRoot=Assert-SOHLocalPath $Request.RemoteRoot
    # Keep report writes outside the authorized scan tree.
    if ($remoteRoot -ieq $t.LocalPath -or (Test-SOHAncestor $t.LocalPath $remoteRoot)) { throw 'Remote report directory is inside scan tree. Choose a disjoint -RemoteRoot.' }
    $parsed=ConvertTo-SOHParsedPath $t.OriginalUNC
    $cs=Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop
    if ($cs.UUID -ine $t.HostId) { throw 'Remote host UUID changed since validation.' }
    $shares=@(Get-SmbShare -Name $parsed.Share -ErrorAction Stop | Where-Object Name -ieq $parsed.Share)
    if ($shares.Count -ne 1 -or -not $shares[0].Path) { throw 'Share is missing or Path is empty on collection recheck.' }
    $now=Assert-SOHLocalPath ([string]$shares[0].Path)
    if ($parsed.Suffix) { $now=Assert-SOHLocalPath ([IO.Path]::Combine($now,$parsed.Suffix)) }
    if ($now -ine $t.LocalPath) { throw 'Share mapping changed since validation. Revalidate with a new RunId.' }
    $drive=$now.Substring(0,2)
    $volume=Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='"+$drive+"'") -ErrorAction Stop
    if (-not $volume -or $volume.FileSystem -ine 'NTFS') { throw 'Collector requires a confirmed NTFS local volume.' }
    # Existing ancestors of our output path may not be junctions either.
    $ancestor=$remoteRoot
    while (-not (Test-Path -LiteralPath $ancestor)) { $ancestor=Split-Path -Parent $ancestor }
    Assert-SOHNoReparse $ancestor
    $outDir=Join-Path $remoteRoot $Request.RunId
    [void][IO.Directory]::CreateDirectory($outDir)
    Assert-SOHNoReparse $outDir
    $name=Get-SOHArtifactName $Request.RunId $t
    $csvPath=Join-Path $outDir ($name + '.csv'); $resultPath=Join-Path $outDir ($name + '.result.json')
    $progress=New-SOHProgressState (Join-Path $outDir ($name+'.progress.json')) $Request.RunId $t
    Publish-SOHProgress $progress 'STARTING' $t.LocalPath -Force
    if (Test-Path -LiteralPath $resultPath) {
        $old=Read-SOHJson $resultPath
        if ($old.RunId -eq $Request.RunId -and $old.PhysicalKey -eq $t.PhysicalKey -and (Get-SOHCollectionMode $old) -eq $mode -and $old.Status -eq 'SUCCESS' -and $old.CsvSHA256 -eq (Get-FileHash -LiteralPath $csvPath).Hash) {
            $progress.State.Status='SUCCESS';$progress.State.FileCount=$old.FileCount;$progress.State.LogicalBytes=$old.LogicalBytes
            Publish-SOHProgress $progress 'REUSED_VERIFIED_RESULT' $t.LocalPath -Force
            return [pscustomobject]@{Result=$old;CsvPath=$csvPath;ResultPath=$resultPath;ResultSHA256=(Get-FileHash -LiteralPath $resultPath).Hash}
        }
    }
    $queueLimit=0
    if($Request.PSObject.Properties['MaxDiskQueueLength']){$queueLimit=$Request.MaxDiskQueueLength}
    $walk=Invoke-SOHNtfsWalk -LocalPath $t.LocalPath -TimeoutSeconds $Request.TimeoutSeconds -MaxEntriesPerSecond $Request.MaxEntriesPerSecond -MaxDiskQueueLength $queueLimit -Progress $progress -SkipOwner:($mode -eq 'Summary')
    $progress.State.Status='RUNNING'
    Publish-SOHProgress $progress 'WRITING_RESULTS' $t.LocalPath -Force
    $rows=@(foreach ($o in $walk.Owners) {
        [pscustomobject][ordered]@{SchemaVersion=$collectorSchema;RunId=$Request.RunId;SourceID=$t.ID;PhysicalKey=$t.PhysicalKey;Department=$t.Department;OriginalUNC=$t.OriginalUNC;Server=$t.Server;LocalPath=$t.LocalPath;Owner=$o.Owner;OwnerSID=$o.OwnerSID;FileCount=$o.FileCount;LogicalBytes=$o.LogicalBytes;AllocatedBytes=$null;Status=$walk.Status}
    })
    if (-not $rows.Count) {
        $rows=@([pscustomobject][ordered]@{SchemaVersion=$collectorSchema;RunId=$Request.RunId;SourceID=$t.ID;PhysicalKey=$t.PhysicalKey;Department=$t.Department;OriginalUNC=$t.OriginalUNC;Server=$t.Server;LocalPath=$t.LocalPath;Owner='';OwnerSID='';FileCount=0;LogicalBytes=0;AllocatedBytes=$null;Status=$walk.Status})
    }
    Write-SOHCsv $csvPath $rows $script:CollectorColumns
    $result=$walk | Select-Object * -ExcludeProperty Owners
    $result | Add-Member NoteProperty RunId $Request.RunId
    $result | Add-Member NoteProperty CollectionMode $mode
    $result | Add-Member NoteProperty SourceID $t.ID
    $result | Add-Member NoteProperty PhysicalKey $t.PhysicalKey
    $result | Add-Member NoteProperty CsvSHA256 (Get-FileHash -LiteralPath $csvPath).Hash
    $result | Add-Member NoteProperty SchemaVersion 'SOH.Result.2'
    Write-SOHJson $resultPath $result
    $progress.State.Status=$walk.Status
    Publish-SOHProgress $progress 'RESULTS_COMMITTED' $t.LocalPath -Force
    [pscustomobject]@{Result=$result;CsvPath=$csvPath;ResultPath=$resultPath;ResultSHA256=(Get-FileHash -LiteralPath $resultPath).Hash}
}
