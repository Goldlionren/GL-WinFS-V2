# 2.2.0 客户执行说明

本版面向当前运行 54926249-44a2-4192-8786-9982c75ccc01 的补采。保留全部已有目标结果和修正 CSV；不执行 Reset，不重新全量扫描。客户端正常运行不需要执行测试套件。

## 直接运行

将 release.zip 解压到 C:\Temp\SOH-V220，得到 C:\Temp\SOH-V220\GL-WinFS-V2。使用现有 SOH\svc_HPEreport 身份的 Windows PowerShell 5.1，执行一行：

```powershell
& 'C:\Temp\SOH-V220\GL-WinFS-V2\Start-SOHCustomerRun.ps1' -ResumeRunId '54926249-44a2-4192-8786-9982c75ccc01' -Workspace 'C:\SOHReporting\workspace'
```

入口自动校验运行包及修正 CSV，启动独立后台进程。后台先备份现有 drop/output，再核验并重新合并；仅补采核验后 FAILED 的目标，不重扫 SUCCESS 或 PARTIAL。根据本次完整 ZIP 离线回放，唯一补采目标为 SOH-050，其余 55 SUCCESS 和 2 PARTIAL 原样保留。它不是从第 1785 万个文件续扫，而是只对失败目标从头扫描。

无需再输入 COLLECT token：此入口仅复用已经批准、哈希绑定的 Summary 运行范围，并在采集前重新核对所选目标服务器 UUID、共享路径和目录。不能将输入更改后的清单混入旧 RunId。普通新运行继续使用 Start-SOHReport.ps1 原有显式确认流程。

看到 STARTED 只表示后台进程已启动。查看实际状态：

```powershell
& 'C:\Temp\SOH-V220\GL-WinFS-V2\Get-SOHCustomerStatus.ps1' -RunId '54926249-44a2-4192-8786-9982c75ccc01' -Workspace 'C:\SOHReporting\workspace'
```

可以关闭启动／查看进度的 PowerShell 窗口；RDP 断开通常不终止登录会话。不要注销运行账号或重启报告服务器；后台进程不是服务或计划任务。服务器策略强制注销断开的会话时仍会中断任务。

结果位于 C:\SOHReporting\workspace\runs\54926249-44a2-4192-8786-9982c75ccc01\output。客户使用 department-report.csv 与 chargeback-2026-11-12.csv；folder-report.csv 保留逐目标状态和实际开始／结束时间。补采沿用 RunId 和报告日期，目标采集时间可能跨日，整个报告不是同一瞬间的快照。attempts\<本次启动标识> 下有旧结果备份、recovery-plan.json、worker-status.json、stdout/stderr 日志；latest-launch.json 指向最新尝试。

SOH-050 成功后，如原来两个 reparse 排除仍未处理，预期为 56 SUCCESS、2 PARTIAL、0 FAILED，整体仍为 INCOMPLETE；29 个部门 COMPLETE，EPRG 与 Technology 仍 INCOMPLETE。这不表示补采失败。退出码 0=全完整，2=报告已生成但有不完整目标，1=执行错误。不得把 PARTIAL 当完整计费容量。

## 本版修改

1. Summary 在编译后的 C# 内按批次分类、累加文件数和逻辑字节；最多每 128 个条目跨一次 PowerShell 边界，不逐文件读内容、ACL、Owner 或 AD。保留特殊名称、长路径、硬链接口径和 reparse 不跟随规则。进度显示当前目录，不再逐文件刷新路径。
2. 补采入口默认每任务 5000 条目/秒，上限可调到 10000；保留磁盘队列阈值 2，每 5 秒检查压力，超阈值等待。总超时 86400 秒，心跳 120 秒，无进展 300 秒。只是限速上限，不承诺生产达到该速度。
3. 判定超时先于任何控制台进度输出，判定前再次检查最新心跳。主控轮询间隔超过 30 秒时给予一次 30 秒恢复窗口，绝对总超时不取消。独立后台执行及文件日志避免查看窗口选中文字阻塞主控。
4. 部门／服务器完整性按各自目标判断，不再把全局 INCOMPLETE 填给所有部门。保留全局 manifest 的真实不完整状态。
5. 超时证据保留实际任务开始时间及判定时刻，停止仅限本任务创建的会话，不修改客户服务或终止其他进程。

不混入卷的“总容量减空闲容量”。本轮保持文件逻辑容量口径，与已保留 57 个目标可相加；整卷快速指标或 FSRM 现有用量是另一个口径，需要另行设计及确认。未自动安装、配置或触发 FSRM。

## 测试边界

本地 Windows PowerShell 5.1、真实 NTFS、小规模性能比较、Mock WinRM、暂停恢复、选择性补采、客户运行包离线回放与干净发布包检查由开发方执行，证据在 reports。目标 Windows Server 2022 尚未由开发机连接验证；客户策略、真实负载和全量耗时仍以现场运行结果为准。不需要客户先跑测试套件，但不能把离线通过写成生产验收通过。

取消后台任务（仅在确实要取消时使用）：

```powershell
New-Item -ItemType File -Path 'C:\SOHReporting\workspace\runs\54926249-44a2-4192-8786-9982c75ccc01\cancel.request' -ErrorAction Stop
```

下次恢复前先核实该次停止结果，再移走这一取消请求文件。程序不自动删除用户发出的取消请求。
