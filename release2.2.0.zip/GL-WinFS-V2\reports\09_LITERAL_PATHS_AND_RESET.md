# 09 — 2.1.1 客户结果诊断与修复证据

分析由客户提供的 output.zip，未连接任何生产服务器。RunId=8a59ebec-ab1a-4d98-927f-49e569550892，2.1.0 Summary，58 个目标：9 SUCCESS、9 PARTIAL、40 FAILED。六个 CSV 的 SHA256 与 manifest 一致；目录、部门、服务器和客户模板中的数量及字节合计一致。

310 条错误中：40 HOST_QUARANTINED 均来自历史 SOHFS3 隔离；269 DIRECTORY_UNREADABLE 包括 260 个百分号路径、8 个末尾 ASCII 空格路径和 1 个末尾不换行空格路径；其余 1 个 REPARSE_SKIPPED。前述路径问题由程序校验或标准路径归一化导致，不能归咎于客户。已读总计 27,128,558 文件、214,287,091,754,358 逻辑字节，仅为不完整结果。SOH-050 的 21,959,568 文件耗时 27,995.881 秒，约 784 文件/秒。

用户要求移除持久隔离并重新统计。用户现场通过确切会话 InstanceId 和远端 PID 8932 核对后 Remove-PSSession，返回 OLD_REPORT_SESSION_REMOVED；没有要求停止客户已有 WinRM 服务。此处记录用户提供的执行结果，不声称开发机独立核验远端状态。

## 实现与测试

Summary 原生 Unicode 元数据枚举保留真实名称，公开 Cursor 适配 PowerShell 5.1；检查授权边界并保留 no-follow reparse 策略。枚举 API 不读文件内容。仅 Summary 使用此路径。根授权策略未放宽。

移除跨运行持久阻断；保留同次运行中取消后主机不再启动任务，以及其他主机继续的调度。停止路径只关闭调用方传入的本项目专用 PSSession。Reset 工具仅归档本工具统计目录，前后校验修正 CSV，并拒绝活动工作区。

- literal-iteration-01：Windows PowerShell 5.1 实测 80 PASS / 7 FAIL。PowerShell 不能直接调用 C# 迭代器显式接口 GetEnumerator；失败导致 Summary 及依赖报表测试失败。已保留原始结果，改为公开 Cursor。
- literal-iteration-02：修正后 88 PASS / 0 FAIL，包含真实特殊名称、超过 260 字符路径、原生错误、边界与 junction、仅关闭指定会话、统计归档及全部原回归。
- 最终回归 test-results.json：Windows PowerShell 5.1.26100.6584，89 PASS / 0 FAIL，额外覆盖持锁时 Reset 拒绝移动统计。
- 打包测试以 release-smoke.json、complete-project-smoke.json 为准，包含干净解压、全文件校验、冷 PowerShell 原生编译与百分号目录扫描。

## 遗留与客户验证

未进行 Server 2022 实际生产重跑、真实 WinRM 断线清理测试或性能承诺。Add-Type/原生 API 的客户策略、269 个实际错误路径以及全量完整性需客户验证。一个 reparse 跳过按现有政策保留。若停止未获确认，新 RunId 不再被历史记录强制阻挡，但不能据此推断旧远端执行必然退出。扫描中的文件变化不是快照语义。历史版本与原 HPE 目录未修改。
