﻿# 2.2.0 — 2026-11-13

* Batch Summary aggregation in compiled code, bounded coordinator recovery after host pauses, timeout decisions before console output, per-department completeness, and a hidden background launcher that backs up evidence and retries only FAILED targets.

# 2.1.1 — 2026-11-13

* Use read-only native Unicode metadata enumeration in Summary to preserve literal descendant names and long paths. Keep authorization boundaries and reparse exclusions; retain legacy Owner behavior.
* Remove persistent cross-run host blocking as requested. Restrict timeout cleanup to the explicitly owned session; retain same-run stop protection and honest incomplete status.
* Add locked, local-only statistics reset that archives tool output and preserves the corrected source CSV. Add real NTFS, cleanup ownership, reset and clean-package cold-start regressions. See PATCH_2.1.1.md for current instructions.

# 2.1.0 — 2026-11-12

* Default to Summary mode per confirmed customer requirement: skip per-file Owner/ACL and AD, use bounded-window pacing, bind collection mode to RunId, and emit the customer 13-column chargeback CSV. Keep logical and allocated bytes distinct and incomplete totals explicit. Preserve legacy Owner runs.

# 2.0.3 — 2026-11-12

* Accept MaxConcurrency up to 8, document the requested 8-server / 1000-entry-per-task profile, and persist effective concurrency and rate settings. Keep one task per physical host and existing watchdog behavior. Add CLI and scheduler regressions.

# 2.0.2 — 2026-11-12

* Add independent missing-heartbeat and no-counter-progress deadlines, bounded asynchronous stop requests, durable host quarantine, and ten-second console/file progress. Preserve unverified counts as diagnostics and continue other hosts. See PATCH_2.0.2.md for scope and deployment.

# 2.0.1 — 2026-11-12

* Add actual collector progress counts, stages, timestamps, PID, disk queue and stale-state visibility through atomic JSON and PowerShell progress records.
* Enumerate logical-disk performance instances and match the requested drive exactly; bound CIM operation timeout and preserve fail-closed pressure behavior.
* Add read-only Get-SOHRunStatus.ps1, including explicit optional remote state checks.
* Preserve 2.0.0 data contracts and authorization. No confirmed root cause or production recovery claim; see PATCH_2.0.1.md.

# 2.0.0 — 2026-11-12

* Independent PowerShell 5.1 project; upstream baseline and MIT notice retained.
* Import/Validate, NTFS Collect, Department Merge, All and safe menu; no-Execute validation, no-write/no-network DryRun.
* Original 58-row customer CSV archived byte-for-byte; user-approved Business Owner mapping; no silent whitespace or spelling repairs.
* Stable remote UUID/DNS evidence, cached sessions/share list, literal local path checks and strict overlap blocking.
* NTFS owner logical bytes, reparse exclusions, explicit errors/partial coverage, hard-link namespace measurement, concurrency/entry rate/disk queue/timeout limits.
* Current RunId-only CSV and result schema validation; SHA256 transport, atomic writes, idempotent retry, provenance, optional AD enrichment.
* Six output artifacts with input/physical-target coverage and no fabricated allocated bytes.
* Local PS 5.1 integration/regression suite, portable checksummed release and complete project handoff.
* First test iteration exposed PS 5.1 null-string binding for File.Replace; fixed with NullString.Value and regression tested. No production environment tested.
