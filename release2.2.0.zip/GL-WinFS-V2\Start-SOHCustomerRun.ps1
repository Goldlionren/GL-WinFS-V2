#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)][string]$ResumeRunId,[string]$Workspace='C:\SOHReporting\workspace',[ValidateRange(1,10000)][int]$MaxEntriesPerSecond=5000)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'src\SOH.psm1') -Force -DisableNameChecking
& (Join-Path $PSScriptRoot 'Verify-SOHPackage.ps1') | Out-Host
Assert-SOHRunId $ResumeRunId
$Workspace=Assert-SOHLocalPath ([IO.Path]::GetFullPath($Workspace));Assert-SOHNoReparse $Workspace
$run=Read-SOHRun $Workspace $ResumeRunId
if((Get-SOHCollectionMode $run) -ne 'Summary' -or $run.Validation.TestMode){throw 'This launcher only resumes a production Summary run.'}
$csv=Join-Path $Workspace 'input\customer-targets.corrected.csv'
if((Get-FileHash -LiteralPath $csv).Hash -ne $run.SourceSHA256){throw 'Corrected source CSV changed; no job started.'}
# Verify another coordinator does not already own the workspace.
$probe=[IO.File]::Open((Join-Path $Workspace '.soh.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$probe.Dispose()
$attemptRoot=Join-Path $Workspace ('runs\'+$ResumeRunId+'\attempts')
if(Test-Path -LiteralPath $attemptRoot){Assert-SOHNoReparse $attemptRoot}
$attempt=Join-Path $attemptRoot ([datetime]::UtcNow.ToString('yyyyMMddTHHmmssZ')+'-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($attempt)
$config=Join-Path $attempt 'launch.json'
Write-SOHJson $config ([pscustomobject]@{SchemaVersion='SOH.Launch.1';Version='2.2.0';RunId=$ResumeRunId;Workspace=$Workspace;CsvPath=$csv;AttemptDirectory=$attempt;MaxEntriesPerSecond=$MaxEntriesPerSecond})
$worker=Join-Path $PSScriptRoot 'Start-SOHBackgroundWorker.ps1'
$exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$arguments='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$worker+'" -ConfigPath "'+$config+'"'
$process=Start-Process -FilePath $exe -ArgumentList $arguments -WindowStyle Hidden -WorkingDirectory $PSScriptRoot -RedirectStandardOutput (Join-Path $attempt 'worker.stdout.log') -RedirectStandardError (Join-Path $attempt 'worker.stderr.log') -PassThru
$launch=[pscustomobject]@{Status='STARTED';RunId=$ResumeRunId;ProcessId=$process.Id;StartedUtc=[datetime]::UtcNow.ToString('o');AttemptDirectory=$attempt;StatusFile=(Join-Path $attempt 'worker-status.json');ProgressLog=(Join-Path $Workspace ('runs\'+$ResumeRunId+'\collection-progress.log'));Output=(Join-Path $Workspace ('runs\'+$ResumeRunId+'\output'));Identity=Get-SOHIdentity}
Write-SOHJson (Join-Path $Workspace ('runs\'+$ResumeRunId+'\latest-launch.json')) $launch
$launch | Format-List
Write-Host 'Runs independently of this PowerShell window. RDP disconnect is OK; Windows sign-out/reboot can terminate the process. Read worker-status.json for the final outcome.'
