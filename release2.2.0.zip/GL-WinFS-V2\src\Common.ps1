﻿# SOH V2 rewrite; upstream MIT attribution is in LICENSE and NOTICE.md.
Set-StrictMode -Version 2.0
$script:SOHVersion = '2.2.0'
$script:CollectorColumns = @('SchemaVersion','RunId','SourceID','PhysicalKey','Department','OriginalUNC','Server','LocalPath','Owner','OwnerSID','FileCount','LogicalBytes','AllocatedBytes','Status')
$script:ChargebackColumns = @('ScanDate','Source','Server','SharePath','OwnerSID','SamAccountName','DisplayName','Department','BusinessUnit','FileCount','LogicalBytes','AllocatedBytes','Unresolved')
function Get-SOHCollectionMode($Record) {
    if(-not $Record.PSObject.Properties['CollectionMode']){return 'Owner'}
    if($Record.CollectionMode -notin @('Summary','Owner')){throw 'Invalid collection mode.'}
    return [string]$Record.CollectionMode
}
function Get-SOHHashText([string]$Text) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose() }
}
function Get-SOHIdentity { return [Security.Principal.WindowsIdentity]::GetCurrent().Name }
function Read-SOHJson([string]$Path) { return ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($Path,[Text.Encoding]::UTF8)) }
function Write-SOHAtomicText([string]$Path, [string]$Text) {
    $parent = [IO.Path]::GetDirectoryName($Path)
    [void][IO.Directory]::CreateDirectory($parent)
    $temp = $Path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temp,$Text,(New-Object Text.UTF8Encoding($true)))
        if ([IO.File]::ReadAllText($temp,[Text.Encoding]::UTF8) -cne $Text) { throw 'Atomic write verification failed.' }
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($temp,$Path,[System.Management.Automation.Language.NullString]::Value) } else { [IO.File]::Move($temp,$Path) }
    } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
}
function Write-SOHJson([string]$Path, $Value) { Write-SOHAtomicText $Path (ConvertTo-Json -InputObject $Value -Depth 30) }
function Write-SOHCsv([string]$Path, [object[]]$Rows, [string[]]$Columns) {
    if (@($Rows).Count) { $lines = @($Rows | Select-Object $Columns | ConvertTo-Csv -NoTypeInformation) }
    else { $lines = @(($Columns | ForEach-Object { '"' + $_ + '"' }) -join ',') }
    Write-SOHAtomicText $Path (($lines -join "`r`n") + "`r`n")
}
function Assert-SOHLocalPath([string]$Path) {
    if ($Path -notmatch '^[A-Za-z]:\\' -or $Path -match '[\x00-\x1f*?<>|"%]' -or $Path.Substring(2).Contains(':')) { throw "Not an explicit local filesystem path: $Path" }
    foreach ($part in ($Path.Substring(3).TrimEnd('\') -split '\\')) {
        if ($part -in @('.','..') -or $part -match '[. ]$') { throw "Unsafe local path component: $Path" }
    }
    return [IO.Path]::GetFullPath($Path).TrimEnd('\') + $(if ($Path.TrimEnd('\').Length -eq 2) { '\' } else { '' })
}
function Test-SOHAncestor([string]$Parent, [string]$Child) {
    return $Child.StartsWith(($Parent.TrimEnd('\') + '\'),[StringComparison]::OrdinalIgnoreCase)
}
function Assert-SOHNoReparse([string]$Path) {
    $p = Assert-SOHLocalPath $Path
    $root = [IO.Path]::GetPathRoot($p)
    $current = $root
    foreach ($part in @('') + @($p.Substring($root.Length) -split '\\' | Where-Object { $_ })) {
        if ($part) { $current = [IO.Path]::Combine($current,$part) }
        $item = Get-Item -LiteralPath $current -Force -ErrorAction Stop
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse path prohibited: $current" }
    }
}
function Get-SOHArtifactName($RunId, $Target) {
    return ('{0}-{1}-{2}-{3}' -f $RunId,($Target.Server -replace '[^A-Za-z0-9.-]','_'),$Target.ID,(Get-SOHHashText $Target.PhysicalKey).Substring(0,16))
}
function Assert-SOHRunId([string]$RunId) {
    $g = [guid]::Empty
    if (-not [guid]::TryParseExact($RunId,'D',[ref]$g)) { throw 'RunId must be a UUID in D format.' }
}
