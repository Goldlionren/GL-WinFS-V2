# 2.1.1：路径修复、移除跨运行隔离、重新统计

当前版本以本文为准；PATCH_2.0.x 与 PATCH_2.1.0 保留为历史记录。

## 修复内容

- Summary 模式使用 Windows Unicode 原生目录枚举，准确保留枚举出的子目录名称，包括百分号、末尾空格、末尾点、不换行空格及长路径。不会展开环境变量或把这些目录误当作非法路径。仍只读取元数据、不读取文件内容、不采集 Owner。
- 原有授权根路径校验继续执行；新路径处理只用于该授权根下的枚举。junction/reparse 仍不跟随并明确记录。显式 Owner 模式沿用旧路径处理，未宣称获得本次 Summary 路径修复。
- 不再创建或执行跨 RunId 的持久主机隔离。旧 blocked-hosts JSON 不会阻止新运行。同一次运行中如某台主机超时且停止尚未确认，该主机剩余目标记为 NOT_STARTED_AFTER_STOP，其他主机继续；再次运行可以重试。
- 取消或超时时，限定时间尝试停止本任务并关闭本脚本自己创建的 PSSession；不枚举或终止其他人的会话，不停止 WinRM 服务，不按进程名批量结束进程。停止请求完成不等于独立证明远端退出；不声称新运行自动排除了所有遗留远端任务。
- 新增 Reset-SOHStatistics.ps1：将本工具的 runs、output、blocked-hosts 移到 workspace\history 下，清空当前统计。保留 input\customer-targets.corrected.csv，并校验前后 SHA256。不访问客户文件服务器；持有工作区锁的运行存在时拒绝重置。旧证据可以找回，下一次用新 RunId 从头统计。

## 部署和重跑（每条命令一行）

本次旧报告会话已由操作员通过确切的 Session InstanceId、服务器及远端 PID 核对后移除。将新 ZIP 解压到 C:\Temp\SOH-V211，在服务账号的 Windows PowerShell 5.1 窗口操作：

```powershell
& 'C:\Temp\SOH-V211\GL-WinFS-V2\Verify-SOHPackage.ps1'
```

校验通过、没有其他报告运行时，清空当前统计并保留修正清单：

```powershell
& 'C:\Temp\SOH-V211\GL-WinFS-V2\Reset-SOHStatistics.ps1' -Workspace 'C:\SOHReporting\workspace'
```

返回 STATISTICS_RESET 后启动全量 Summary。并行上限 8，每台服务器同时一个目标，每任务上限 1000 个条目/秒（文件和目录均算条目）：

```powershell
$runId=[guid]::NewGuid().ToString('D'); Write-Host "RunId: $runId"; & 'C:\Temp\SOH-V211\GL-WinFS-V2\Start-SOHReport.ps1' -Stage All -Execute -ApproveFullVolume -CollectionMode Summary -CsvPath 'C:\SOHReporting\workspace\input\customer-targets.corrected.csv' -Workspace 'C:\SOHReporting\workspace' -RunId $runId -MaxConcurrency 8 -MaxEntriesPerSecond 1000 -MaxDiskQueueLength 2 -TimeoutSeconds 86400 -HeartbeatTimeoutSeconds 120 -NoProgressTimeoutSeconds 300
```

输入本次完整 COLLECT 确认字符串。完成后检查该 RunId 的 output\run-manifest.json、folder-report.csv 和 errors.csv。客户报告为 chargeback-YYYY-MM-DD.csv 与 department-report.csv。FAILED 不会伪装为零，PARTIAL 只是已读部分，不应作为完整账单。

## 测试与待验证

本地真实 Windows PowerShell 5.1、NTFS 特殊名称和长路径测试，以及 Mock 调度、错误处理、报表回归见 reports\test-results.json。首次原生迭代器的 PowerShell 调用失败已保留测试证据并修复为公开 Cursor 包装。完整离线发布包另做干净解压校验和冷启动原生编译测试。

原生辅助类通过系统自带 Add-Type 编译，无第三方下载或安装。客户端如限制 Add-Type/原生调用，会如实报错；本包不修改该策略。开发机未连接客户生产环境，Server 2022 实际运行、原 269 个目录错误是否全部解决仍待重跑验证。原报告唯一 reparse 跳过仍需客户确认统计口径；不自动跟随。计量仍为逻辑字节，不是去重/压缩后的物理占用。
