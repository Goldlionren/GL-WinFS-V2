﻿function Get-SOHNonnegativeInt64($Value,[string]$Field) {
    $n=0L
    if ([string]$Value -notmatch '^\d+$' -or -not [long]::TryParse([string]$Value,[ref]$n) -or $n -lt 0) { throw "Invalid nonnegative Int64 $Field : $Value" }
    return $n
}
function Invoke-SOHMerge {
    param($Run,[string]$Workspace,[switch]$ResolveAD,[scriptblock]$ADResolver)
    $runId=$Run.RunId; Assert-SOHRunId $runId
    $runDir=Join-Path (Join-Path $Workspace 'runs') $runId; $drop=Join-Path $runDir 'drop'; $out=Join-Path $runDir 'output'
    $folders=New-Object 'Collections.Generic.List[object]'; $owners=New-Object 'Collections.Generic.List[object]'; $errors=New-Object 'Collections.Generic.List[object]'
    $results=@{}; $expected=@{}; $ignored=New-Object 'Collections.Generic.List[string]'; $adCache=@{}
    $map=$Run.Validation
    $mode=Get-SOHCollectionMode $Run
    $collectorSchema=if($mode -eq 'Summary'){'SOH.Collector.Summary.2'}else{'SOH.Collector.2'}
    $conflict=$false
    try { Assert-SOHCollectMap $map -ApproveFullVolume:$Run.FullVolumeApproved -AllowTest } catch { $conflict=$true; $errors.Add([pscustomobject]@{RunId=$runId;ID='';Server='';LocalPath='';Path='';Code='VALIDATION_BLOCK';Message=$_.Exception.Message}) }
    foreach ($t in $Run.Targets) {
        $name=Get-SOHArtifactName $runId $t; $expected[$name+'.csv']=$true
        $resultFile=Join-Path $drop ($name+'.result.json'); $csvFile=Join-Path $drop ($name+'.csv')
        $status='FAILED'; $fileCount=0L; $bytes=0L; $skippedFiles=0L; $skippedDirs=0L; $errorCount=0L; $started='';$ended=''
        try {
            if ($conflict) { throw 'Validation conflict blocks all totals.' }
            if (-not (Test-Path -LiteralPath $resultFile)) { throw 'Missing result (not started, interrupted, disconnected or cancelled).' }
            $r=Read-SOHJson $resultFile
            if((Get-SOHCollectionMode $r) -ne $mode){throw 'Collector mode differs from immutable run mode.'}
            if ($r.SchemaVersion -ne 'SOH.Result.2' -or $r.RunId -cne $runId -or $r.SourceID -cne $t.ID -or $r.PhysicalKey -cne $t.PhysicalKey -or $r.Status -notin @('SUCCESS','PARTIAL','FAILED')) { throw 'Collector result schema/run/target mismatch.' }
            $started=$r.StartedUtc; $ended=$r.EndedUtc
            $fileCount=Get-SOHNonnegativeInt64 $r.FileCount 'FileCount'; $bytes=Get-SOHNonnegativeInt64 $r.LogicalBytes 'LogicalBytes'
            $skippedFiles=Get-SOHNonnegativeInt64 $r.SkippedFiles 'SkippedFiles'; $skippedDirs=Get-SOHNonnegativeInt64 $r.SkippedDirectories 'SkippedDirectories'; $errorCount=Get-SOHNonnegativeInt64 $r.ErrorCount 'ErrorCount'
            if ($errorCount -ne @($r.Errors).Count) { throw 'Result error count mismatch.' }
            if ($r.Status -eq 'SUCCESS' -and ($errorCount -gt 0 -or $skippedFiles -gt 0 -or $skippedDirs -gt 0)) { throw 'SUCCESS cannot contain skips/errors.' }
            foreach ($e in $r.Errors) { $errors.Add([pscustomobject]@{RunId=$runId;ID=$t.ID;Server=$t.Server;LocalPath=$t.LocalPath;Path=$e.Path;Code=$e.Code;Message=$e.Message}) }
            if ($r.CsvSHA256) {
                if ((Get-FileHash -LiteralPath $csvFile -ErrorAction Stop).Hash -ne $r.CsvSHA256) { throw 'Collector CSV checksum mismatch.' }
                $data=@(Import-Csv -LiteralPath $csvFile -Encoding UTF8 -ErrorAction Stop)
                if (-not $data.Count -or (@($data[0].PSObject.Properties.Name) -join ',') -cne ($script:CollectorColumns -join ',')) { throw 'Not the standard SOH collector schema (FSRM/title/empty CSV forbidden).' }
                if($mode -eq 'Summary' -and $data.Count -ne 1){throw 'Summary collector must contain one target aggregate.'}
                $sumFiles=0L; $sumBytes=0L; $keys=@{}; $validatedOwners=New-Object 'Collections.Generic.List[object]'
                foreach ($d in $data) {
                    if ($d.SchemaVersion -cne $collectorSchema -or $d.RunId -cne $runId -or $d.SourceID -cne $t.ID -or $d.PhysicalKey -cne $t.PhysicalKey -or $d.Server -cne $t.Server -or $d.LocalPath -cne $t.LocalPath -or $d.Department -cne $t.Department -or $d.OriginalUNC -cne $t.OriginalUNC -or $d.Status -cne $r.Status -or $d.AllocatedBytes -ne '') { throw 'Collector row is not bound to this validated run/target/measurement.' }
                    if($mode -eq 'Summary' -and ($d.Owner -ne '' -or $d.OwnerSID -ne '')){throw 'Summary row must not contain invented Owner identities.'}
                    $nf=Get-SOHNonnegativeInt64 $d.FileCount 'FileCount'; $nb=Get-SOHNonnegativeInt64 $d.LogicalBytes 'LogicalBytes'
                    $key=$d.OwnerSID+'|'+$d.Owner
                    if($keys.ContainsKey($key)){throw 'Duplicate owner aggregate row.'};$keys[$key]=$true
                    # Decimal arithmetic avoids silent Int64 overflow / double rounding.
                    $sf=[decimal]$sumFiles+$nf; $sb=[decimal]$sumBytes+$nb
                    if($sf -gt [long]::MaxValue -or $sb -gt [long]::MaxValue){throw 'Collector total overflow.'}
                    $sumFiles=[long]$sf;$sumBytes=[long]$sb
                    $sam='';$display='';$adDepartment='';$adStatus='NOT_REQUESTED'
                    if ($mode -eq 'Owner' -and ($ResolveAD -or $ADResolver)) {
                        if (-not $adCache.ContainsKey($d.OwnerSID)) {
                            try {
                                if ($d.OwnerSID -notmatch '^S-1-\d+(-\d+)+$') { throw 'No usable SID.' }
                                if ($ADResolver) { $ad=& $ADResolver $d.OwnerSID } else { $ad=Get-ADUser -Identity $d.OwnerSID -Properties DisplayName,Department,SamAccountName -ErrorAction Stop }
                                if (-not $ad) { throw 'SID not found in AD.' }
                                $adCache[$d.OwnerSID]=[pscustomobject]@{Status='RESOLVED';Sam=$ad.SamAccountName;Display=$ad.DisplayName;Department=$ad.Department}
                            } catch { $adCache[$d.OwnerSID]=[pscustomobject]@{Status='UNRESOLVED: '+$_.Exception.Message;Sam='';Display='';Department=''} }
                        }
                        $a=$adCache[$d.OwnerSID];$sam=$a.Sam;$display=$a.Display;$adDepartment=$a.Department;$adStatus=$a.Status
                    }
                    $validatedOwners.Add([pscustomobject][ordered]@{RunId=$runId;ID=$t.ID;LinkedIDs=$t.LinkedIDs -join ';';Department=$t.Department;OriginalUNC=$t.OriginalUNC;Server=$t.Server;LocalPath=$t.LocalPath;PhysicalKey=$t.PhysicalKey;Owner=$d.Owner;OwnerSID=$d.OwnerSID;FileCount=$nf;LogicalBytes=$nb;AllocatedBytes=$null;Status=$r.Status;SamAccountName=$sam;DisplayName=$display;ADDepartment=$adDepartment;ADStatus=$adStatus})
                }
                if ($sumFiles -ne $fileCount -or $sumBytes -ne $bytes) { throw 'CSV and result totals differ.' }
                if($mode -eq 'Owner'){foreach ($o in $validatedOwners) { $owners.Add($o) }}
            } elseif ($r.Status -ne 'FAILED' -or $fileCount -ne 0 -or $bytes -ne 0) { throw 'Missing CSV for nonempty/successful result.' }
            $status=$r.Status
        } catch {
            $status='FAILED';$bytes=0L;$fileCount=0L;$errorCount++
            $errors.Add([pscustomobject]@{RunId=$runId;ID=$t.ID;Server=$t.Server;LocalPath=$t.LocalPath;Path=$csvFile;Code='RESULT_REJECTED';Message=$_.Exception.Message})
        }
        $results[$t.PhysicalKey]=[pscustomobject]@{Status=$status;FileCount=$fileCount;LogicalBytes=$bytes;SkippedFiles=$skippedFiles;SkippedDirectories=$skippedDirs;ErrorCount=$errorCount;StartedUtc=$started;EndedUtc=$ended;PrimaryID=$t.ID}
    }
    foreach ($f in @(Get-ChildItem -LiteralPath $drop -Filter '*.csv' -File -ErrorAction Stop)) {
        if (-not $expected.ContainsKey($f.Name)) { $ignored.Add($f.Name) }
    }
    foreach ($t in $map.Rows) {
        $r=$null; if ($results.ContainsKey($t.PhysicalKey)) { $r=$results[$t.PhysicalKey] }
        $counted=($null -ne $r -and $t.ID -eq $r.PrimaryID)
        $folders.Add([pscustomobject][ordered]@{RunId=$runId;ID=$t.ID;Department=$t.Department;OriginalUNC=$t.OriginalUNC;Server=$t.Server;LocalPath=$t.LocalPath;PhysicalKey=$t.PhysicalKey;PrimaryID=$t.PrimaryID;LinkedIDs=$t.LinkedIDs -join ';';Counted=$counted;FileCount=$(if($counted){$r.FileCount}else{0});LogicalBytes=$(if($counted){$r.LogicalBytes}else{0});AllocatedBytes=$null;Status=$(if($r){$r.Status}else{'FAILED'});SkippedFiles=$(if($r){$r.SkippedFiles}else{0});SkippedDirectories=$(if($r){$r.SkippedDirectories}else{0});ErrorCount=$(if($r){$r.ErrorCount}else{1});StartedUtc=$(if($r){$r.StartedUtc}else{''});EndedUtc=$(if($r){$r.EndedUtc}else{''})})
    }
    $success=@($results.Values | Where-Object Status -eq 'SUCCESS').Count; $partial=@($results.Values | Where-Object Status -eq 'PARTIAL').Count; $failed=@($results.Values | Where-Object Status -eq 'FAILED').Count
    $uncovered=@($folders | Where-Object Status -ne 'SUCCESS').Count
    $complete=($uncovered -eq 0 -and -not $conflict -and $success -eq @($Run.Targets).Count -and $success -gt 0)
    $overall=if($complete){'COMPLETE'}else{'INCOMPLETE'}
    $columns=@('RunId','ID','Department','OriginalUNC','Server','LocalPath','PhysicalKey','PrimaryID','LinkedIDs','Counted','FileCount','LogicalBytes','AllocatedBytes','Status','SkippedFiles','SkippedDirectories','ErrorCount','StartedUtc','EndedUtc')
    Write-SOHCsv (Join-Path $out 'folder-report.csv') @($folders.ToArray()) $columns
    foreach ($dimension in @('Department','Server')) {
        $aggregate=@(foreach ($g in @($folders | Group-Object $dimension)) {
            $sumB=[decimal]0;$sumF=[decimal]0
            foreach($row in $g.Group){$sumB += [decimal]$row.LogicalBytes;$sumF += [decimal]$row.FileCount}
            [pscustomobject][ordered]@{RunId=$runId;ID=(@($g.Group.ID)-join ';');Department=$(if($dimension -eq 'Department'){$g.Name}else{@($g.Group.Department | Select-Object -Unique)-join ';'});OriginalUNC=@($g.Group.OriginalUNC)-join ';';Server=$(if($dimension -eq 'Server'){$g.Name}else{@($g.Group.Server | Select-Object -Unique)-join ';'});LocalPath=@($g.Group.LocalPath | Select-Object -Unique)-join ';';FileCount=$sumF;LogicalBytes=$sumB;AllocatedBytes=$null;Status=$(if(-not $conflict -and @($g.Group | Where-Object Status -ne 'SUCCESS').Count -eq 0){'COMPLETE'}else{'INCOMPLETE'});PhysicalTargets=@($g.Group | Where-Object Counted).Count}
        })
        Write-SOHCsv (Join-Path $out ($dimension.ToLowerInvariant()+'-report.csv')) $aggregate @('RunId','ID','Department','OriginalUNC','Server','LocalPath','FileCount','LogicalBytes','AllocatedBytes','Status','PhysicalTargets')
    }
    Write-SOHCsv (Join-Path $out 'owner-detail.csv') @($owners.ToArray()) @('RunId','ID','LinkedIDs','Department','OriginalUNC','Server','LocalPath','PhysicalKey','Owner','OwnerSID','FileCount','LogicalBytes','AllocatedBytes','Status','SamAccountName','DisplayName','ADDepartment','ADStatus')
    Write-SOHCsv (Join-Path $out 'errors.csv') @($errors.ToArray()) @('RunId','ID','Server','LocalPath','Path','Code','Message')
    if($mode -eq 'Summary'){
        # Customer's 13-column layout, one row per deduplicated physical target.
        # Run UTC date is stable across repeat Merge calls; actual per-target times remain in folder-report.
        $scanDate=[datetime]::Parse($Run.CreatedUtc).ToUniversalTime().ToString('yyyy-MM-dd')
        $chargeback=@(foreach($t in $Run.Targets){
            $r=$results[$t.PhysicalKey]
            [pscustomobject][ordered]@{ScanDate=$scanDate;Source='Windows-NTFS-Summary';Server=$t.Server;SharePath=$t.LocalPath;OwnerSID='';SamAccountName='';DisplayName='';Department=$t.Department;BusinessUnit='';FileCount=$(if($r.Status -eq 'FAILED'){$null}else{$r.FileCount});LogicalBytes=$(if($r.Status -eq 'FAILED'){$null}else{$r.LogicalBytes});AllocatedBytes=$null;Unresolved=$(if($r.Status -eq 'SUCCESS'){''}else{$r.Status})}
        })
        Write-SOHCsv (Join-Path $out ('chargeback-'+$scanDate+'.csv')) $chargeback $script:ChargebackColumns
    }
    $manifest=[pscustomobject][ordered]@{SchemaVersion='SOH.Manifest.2';CollectionMode=$mode;OwnerCollected=($mode -eq 'Owner');RunId=$runId;Version=$script:SOHVersion;Identity=Get-SOHIdentity;CreatedUtc=[datetime]::UtcNow.ToString('o');Status=$overall;ProductionAcceptance='PENDING_CUSTOMER_GATE_5';SourceSHA256=$Run.SourceSHA256;InputRows=@($map.Rows).Count;ValidRows=@($map.Rows|Where-Object Status -eq 'VALID').Count;ReviewRows=@($map.Rows|Where-Object Status -eq 'NEEDS_REVIEW').Count;InvalidRows=@($map.Rows|Where-Object Status -eq 'INVALID').Count;PlannedPhysicalTargets=@($Run.Targets).Count;DeduplicatedRows=@($map.Rows).Count-@($Run.Targets).Count;SuccessfulTargets=$success;PartialTargets=$partial;FailedTargets=$failed;UncoveredInputRows=$uncovered;IgnoredUnlistedCsv=@($ignored.ToArray());TestMode=$map.TestMode;Measurement=$Run.Measurement;AllocatedBytes=$null;Reports=@()}
    $manifest.Reports=@(Get-ChildItem -LiteralPath $out -Filter '*.csv' -File | ForEach-Object { [pscustomobject]@{Name=$_.Name;SHA256=(Get-FileHash -LiteralPath $_.FullName).Hash} })
    # Manifest commits a consistent generation; consumers must verify these report hashes.
    Write-SOHJson (Join-Path $out 'run-manifest.json') $manifest
    return $manifest
}
