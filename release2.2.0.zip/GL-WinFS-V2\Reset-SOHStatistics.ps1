#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)][string]$Workspace)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'src\SOH.psm1') -Force -DisableNameChecking
$workspacePath=Assert-SOHLocalPath ([IO.Path]::GetFullPath($Workspace))
if($workspacePath.Length -le 3){throw 'Workspace cannot be a drive root.'}
Assert-SOHNoReparse $workspacePath
$inputFile=Join-Path $workspacePath 'input\customer-targets.corrected.csv'
Assert-SOHNoReparse (Split-Path -Parent $inputFile)
if(-not (Test-Path -LiteralPath $inputFile -PathType Leaf)){throw 'Corrected customer input is missing; nothing reset.'}
$inputHash=(Get-FileHash -LiteralPath $inputFile -Algorithm SHA256).Hash
$lock=$null
$archive=$null
$completed=New-Object 'Collections.Generic.List[object]'
try {
    # An active run owns this exclusive lock. Never reset its artifacts underneath it.
    $lock=[IO.File]::Open((Join-Path $workspacePath '.soh.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $history=Join-Path $workspacePath 'history'
    if(Test-Path -LiteralPath $history){Assert-SOHNoReparse $history}
    $archive=[IO.Path]::GetFullPath((Join-Path $history ('reset-'+[datetime]::UtcNow.ToString('yyyyMMddTHHmmssZ')+'-'+[guid]::NewGuid().ToString('N'))))
    if(-not $archive.StartsWith($workspacePath.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Archive escaped workspace.'}
    $moves=@(foreach($name in @('runs','output','blocked-hosts')){
        $source=[IO.Path]::GetFullPath((Join-Path $workspacePath $name));$destination=[IO.Path]::GetFullPath((Join-Path $archive $name))
        if(-not $source.StartsWith($workspacePath.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase) -or -not $destination.StartsWith($archive+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe reset path.'}
        if(Test-Path -LiteralPath $source){Assert-SOHNoReparse $source;[pscustomobject]@{Source=$source;Destination=$destination}}
    })
    [void][IO.Directory]::CreateDirectory($archive)
    foreach($move in $moves){Move-Item -LiteralPath $move.Source -Destination $move.Destination -ErrorAction Stop;$completed.Add($move)}
    if((Get-FileHash -LiteralPath $inputFile -Algorithm SHA256).Hash -ne $inputHash){throw 'Input changed during reset; inspect before running.'}
    $result=[pscustomobject]@{Status='STATISTICS_RESET';Workspace=$workspacePath;Archive=$archive;PreservedInput=$inputFile;SourceSHA256=$inputHash;Moved=@($completed.ToArray());RemoteOperations=$false}
    Write-SOHJson (Join-Path $archive 'reset-receipt.json') $result
    $result | Format-List
}catch{
    if($archive -and (Test-Path -LiteralPath $archive)){
        Write-SOHJson (Join-Path $archive 'reset-failure.json') ([pscustomobject]@{Status='RESET_INCOMPLETE';Message=$_.Exception.Message;Moved=@($completed.ToArray());PreservedInput=$inputFile})
    }
    throw
}finally{if($lock){$lock.Dispose()}}
