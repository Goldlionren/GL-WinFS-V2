# Independent coordinator deadlines: no dependency on a blocked collector returning.
function New-SOHWatchdog {
    [pscustomobject]@{Clock=[Diagnostics.Stopwatch]::StartNew();LastHeartbeat=0.0;LastAdvance=0.0;LastPoll=0.0;ResumeGraceUntil=0.0;CoordinatorPauses=0;SeenUpdatedUtc=[datetime]::MinValue;Files=0L;Entries=0L;Directories=0L;Bytes=0L}
}
function Update-SOHCoordinatorPoll($Monitor) {
    $now=$Monitor.Clock.Elapsed.TotalSeconds
    if(($now-$Monitor.LastPoll) -gt 30){$Monitor.ResumeGraceUntil=$now+30;$Monitor.CoordinatorPauses++}
    $Monitor.LastPoll=$now
}
function Update-SOHWatchdog($Monitor,$Heartbeat) {
    if(-not $Heartbeat){return $false}
    try {
        $stamp=[datetime]::Parse($Heartbeat.UpdatedUtc).ToUniversalTime()
        if($stamp -le $Monitor.SeenUpdatedUtc){return $false}
        $values=@([long]$Heartbeat.FileCount,[long]$Heartbeat.ObservedEntries,[long]$Heartbeat.DirectoriesVisited,[long]$Heartbeat.LogicalBytes)
        if(@($values | Where-Object {$_ -lt 0}).Count){return $false}
    }catch{return $false}
    $now=$Monitor.Clock.Elapsed.TotalSeconds
    $Monitor.SeenUpdatedUtc=$stamp;$Monitor.LastHeartbeat=$now
    # Phase/path/timestamp/CPU changes alone do not constitute scan progress.
    if($values[0] -gt $Monitor.Files -or $values[1] -gt $Monitor.Entries -or $values[2] -gt $Monitor.Directories -or $values[3] -gt $Monitor.Bytes){$Monitor.LastAdvance=$now}
    $Monitor.Files=[Math]::Max($Monitor.Files,$values[0]);$Monitor.Entries=[Math]::Max($Monitor.Entries,$values[1]);$Monitor.Directories=[Math]::Max($Monitor.Directories,$values[2]);$Monitor.Bytes=[Math]::Max($Monitor.Bytes,$values[3])
    return $true
}
function Get-SOHWatchdogReason($Monitor,[double]$TimeoutSeconds,[double]$HeartbeatTimeoutSeconds,[double]$NoProgressTimeoutSeconds) {
    $now=$Monitor.Clock.Elapsed.TotalSeconds
    if($now -ge ($TimeoutSeconds+30)){return 'TARGET_TIMEOUT'}
    if($Monitor.PSObject.Properties['ResumeGraceUntil'] -and $now -lt $Monitor.ResumeGraceUntil){return ''}
    if(($now-$Monitor.LastHeartbeat) -ge $HeartbeatTimeoutSeconds){return 'HEARTBEAT_TIMEOUT'}
    if(($now-$Monitor.LastAdvance) -ge $NoProgressTimeoutSeconds){return 'NO_PROGRESS_TIMEOUT'}
    return ''
}
function Stop-SOHJobBounded($Job,[int]$WaitMilliseconds=5000,$Session=$null) {
    # Stop-Job / Job.StopJob can themselves wait on transport. Run that request on a separate
    # local runspace and never synchronously Dispose a pipeline that is still blocked.
    $ps=[PowerShell]::Create()
    [void]$ps.AddScript('param($job,$session) $ErrorActionPreference="Stop"; try { $job.StopJob() } finally { if($session){$session.Runspace.Close()} }').AddArgument($Job).AddArgument($Session)
    $handle=$ps.BeginInvoke()
    $completed=$handle.AsyncWaitHandle.WaitOne($WaitMilliseconds)
    $errorText=''
    if($completed){
        try{$null=$ps.EndInvoke($handle);if($ps.HadErrors){$errorText=($ps.Streams.Error | Out-String)}}catch{$errorText=$_.Exception.Message}
        $ps.Dispose()
    }else{
        if(-not (Get-Variable -Name SOHPendingStops -Scope Script -ErrorAction SilentlyContinue)){$script:SOHPendingStops=New-Object Collections.ArrayList}
        [void]$script:SOHPendingStops.Add([pscustomobject]@{Pipeline=$ps;Handle=$handle})
    }
    [pscustomobject]@{StopRequestCompleted=$completed;OwnedSessionCloseCompleted=([bool]$Session -and $completed -and -not $errorText);RemoteExitVerified=$false;Message=$errorText}
}
function Get-SOHHostBlockPath([string]$Workspace,[string]$HostId) {
    Join-Path (Join-Path $Workspace 'blocked-hosts') ((Get-SOHHashText $HostId.ToLowerInvariant())+'.json')
}
function Register-SOHStopPending($Active,$Context) {
    # In-memory cleanup tracking only. Never create/read persistent host gates.
    if(-not $Context.PSObject.Properties['UnconfirmedStopSessions']){$Context | Add-Member NoteProperty UnconfirmedStopSessions (New-Object Collections.ArrayList)}
    [void]$Context.UnconfirmedStopSessions.Add($Active.Session)
}
