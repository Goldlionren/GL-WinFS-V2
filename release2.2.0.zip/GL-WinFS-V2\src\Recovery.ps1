function Get-SOHFailedTargetIds($Run,[string]$Workspace) {
    $file=Join-Path $Workspace ('runs\'+$Run.RunId+'\output\folder-report.csv')
    $rows=@(Import-Csv -LiteralPath $file -Encoding UTF8 -ErrorAction Stop)
    if(@($rows).Count -ne @($Run.Validation.Rows).Count -or @($rows | Where-Object RunId -cne $Run.RunId).Count){throw 'Recovery report does not match immutable run.'}
    # PARTIAL is intentional evidence of exclusions, not a request to rescan that target.
    @($rows | Where-Object { $_.Status -eq 'FAILED' -and $_.Counted -eq 'True' } | ForEach-Object { $_.PrimaryID } | Select-Object -Unique)
}
function Invoke-SOHResumeFailed {
    param([string]$Workspace,[string]$RunId,[string]$CsvPath,[string]$SourceRoot,[string]$AttemptDirectory,[int]$MaxEntriesPerSecond=5000)
    $lock=$null;$context=$null
    try {
        $Workspace=Assert-SOHLocalPath ([IO.Path]::GetFullPath($Workspace));Assert-SOHNoReparse $Workspace
        $lock=[IO.File]::Open((Join-Path $Workspace '.soh.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        $run=Read-SOHRun $Workspace $RunId
        if((Get-SOHCollectionMode $run) -ne 'Summary' -or $run.Validation.TestMode){throw 'Resume requires a production Summary run.'}
        Assert-SOHCollectMap $run.Validation -ApproveFullVolume:$run.FullVolumeApproved
        if((Get-FileHash -LiteralPath $CsvPath -Algorithm SHA256).Hash -ne $run.SourceSHA256){throw 'Corrected CSV differs from original run. Nothing collected.'}
        $runDir=Join-Path $Workspace ('runs\'+$RunId)
        Assert-SOHNoReparse $runDir
        $attemptPath=[IO.Path]::GetFullPath($AttemptDirectory)
        if(-not $attemptPath.StartsWith((Join-Path $runDir 'attempts')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Backup destination must be a unique attempt inside this run.'}
        Assert-SOHNoReparse $attemptPath
        foreach($name in @('drop','output')){
            $source=Join-Path $runDir $name
            if(Test-Path -LiteralPath $source){Assert-SOHNoReparse $source;Copy-Item -LiteralPath $source -Destination (Join-Path $AttemptDirectory $name) -Recurse -ErrorAction Stop}
        }
        $manifest=Invoke-SOHMerge $run $Workspace
        $selected=@(Get-SOHFailedTargetIds $run $Workspace)
        Write-SOHJson (Join-Path $AttemptDirectory 'recovery-plan.json') ([pscustomobject]@{RunId=$RunId;TargetIDs=$selected;RetainedSuccess=$manifest.SuccessfulTargets;RetainedPartial=$manifest.PartialTargets;RatePerTask=$MaxEntriesPerSecond;Measurement=$run.Measurement;SourceSHA256=$run.SourceSHA256})
        if(-not $selected.Count){return $manifest}
        $context=New-SOHRemoteContext
        # Revalidate only the exact targets being retried against their saved authorization.
        # Existing completed targets stay bound to their original run snapshot and timestamps.
        foreach($t in @($run.Targets | Where-Object { $_.ID -cin $selected })){
            $current=Resolve-SOHTarget (ConvertTo-SOHParsedPath $t.OriginalUNC) $context
            if($current.HostId -ine $t.HostId -or $current.LocalPath -ine $t.LocalPath -or $current.Server -ine $t.Server){throw ('Remote identity/path changed for '+$t.ID+'; new authorization required.')}
            $rp=Join-Path $runDir ('drop\'+(Get-SOHArtifactName $RunId $t)+'.result.json')
            if(Test-Path -LiteralPath $rp){$old=Read-SOHJson $rp;if($old.Status -eq 'SUCCESS'){throw ('Previously marked SUCCESS but rejected by Merge: '+$t.ID+'. Inspect integrity before retry.')}}
        }
        try {
            Invoke-SOHCollect -Run $run -Workspace $Workspace -Context $context -SourceRoot $SourceRoot -TargetID $selected -MaxConcurrency 8 -MaxEntriesPerSecond $MaxEntriesPerSecond -TimeoutSeconds 86400 -HeartbeatTimeoutSeconds 120 -NoProgressTimeoutSeconds 300 -MaxDiskQueueLength 2
        }catch{Write-Warning ('Recovery interrupted: '+$_.Exception.Message)}
        Invoke-SOHMerge $run $Workspace
    }finally{if($context){Close-SOHRemoteContext $context};if($lock){$lock.Dispose()}}
}
