﻿$ErrorActionPreference='Stop'
foreach ($file in @('Common','LiteralMetadata','Validation','Collector','Watchdog','Orchestration','Merge','Recovery')) { . (Join-Path $PSScriptRoot ($file+'.ps1')) }
Export-ModuleMember -Function *-SOH*
